package com.example.data

import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GitHubUserDto(
    val login: String,
    val name: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubCodespacesResponseDto(
    @Json(name = "total_count") val totalCount: Int = 0,
    val codespaces: List<GitHubCodespaceDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class GitHubCodespaceDto(
    val id: Long,
    val name: String,
    @Json(name = "display_name") val displayName: String? = null,
    val state: String? = null,
    val location: String? = null,
    @Json(name = "last_used_at") val lastUsedAt: String? = null,
    val repository: GitHubRepoDto? = null,
    val machine: GitHubMachineDto? = null,
    @Json(name = "git_status") val gitStatus: GitHubGitStatusDto? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubRepoDto(
    @Json(name = "full_name") val fullName: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubMachineDto(
    @Json(name = "display_name") val displayName: String? = null,
    val cpus: Int? = null,
    @Json(name = "memory_in_bytes") val memoryInBytes: Long? = null,
    @Json(name = "storage_in_bytes") val storageInBytes: Long? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubGitStatusDto(
    val ref: String? = null,
)

interface GitHubRestApi {
    @GET("user")
    suspend fun getAuthenticatedUser(
        @Header("Authorization") authorization: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubUserDto>

    @GET("user/codespaces")
    suspend fun listCodespaces(
        @Header("Authorization") authorization: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespacesResponseDto>

    @POST("user/codespaces/{codespace_name}/start")
    suspend fun startCodespace(
        @Header("Authorization") authorization: String,
        @Path("codespace_name") codespaceName: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespaceDto>

    @POST("user/codespaces/{codespace_name}/stop")
    suspend fun stopCodespace(
        @Header("Authorization") authorization: String,
        @Path("codespace_name") codespaceName: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespaceDto>
}

class GitHubCodespacesRepository {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Intentionally omits HTTP body/header logging so user PATs are never written to Logcat.
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val api: GitHubRestApi = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GitHubRestApi::class.java)

    suspend fun verifyPat(rawPat: String): Result<GitHubUserDto> = runCatching {
        val token = rawPat.trim()
        require(token.isNotBlank()) { "Please enter a valid GitHub Personal Access Token." }
        val response = api.getAuthenticatedUser("Bearer $token")
        if (!response.isSuccessful) {
            val detail = when (response.code()) {
                401 -> "Invalid or expired token (HTTP 401)."
                403 -> "Token lacks required permissions or rate limit exceeded (HTTP 403)."
                else -> "GitHub API returned HTTP ${response.code()}."
            }
            error(detail)
        }
        response.body() ?: error("Empty response from GitHub API.")
    }

    suspend fun fetchCodespaces(rawPat: String): Result<List<CodespaceInfo>> = runCatching {
        val token = rawPat.trim()
        val response = api.listCodespaces("Bearer $token")
        if (!response.isSuccessful) {
            val detail = when (response.code()) {
                401 -> "Unauthorized. Please check your GitHub PAT."
                403 -> "Missing 'codespace' scope on your GitHub PAT (HTTP 403)."
                else -> "Failed to load Codespaces (HTTP ${response.code()})."
            }
            error(detail)
        }
        val items = response.body()?.codespaces.orEmpty()
        items.map { it.toDomain() }
    }

    suspend fun startCodespace(rawPat: String, codespaceName: String): Result<CodespaceInfo> = runCatching {
        val response = api.startCodespace("Bearer ${rawPat.trim()}", codespaceName)
        if (!response.isSuccessful) {
            error("Unable to start Codespace (HTTP ${response.code()}).")
        }
        response.body()?.toDomain() ?: error("Empty response when starting Codespace.")
    }

    suspend fun stopCodespace(rawPat: String, codespaceName: String): Result<CodespaceInfo> = runCatching {
        val response = api.stopCodespace("Bearer ${rawPat.trim()}", codespaceName)
        if (!response.isSuccessful) {
            error("Unable to stop Codespace (HTTP ${response.code()}).")
        }
        response.body()?.toDomain() ?: error("Empty response when stopping Codespace.")
    }

    private fun GitHubCodespaceDto.toDomain(): CodespaceInfo {
        val cores = machine?.cpus ?: 4
        val ramGb = ((machine?.memoryInBytes ?: (16L * 1024 * 1024 * 1024)) / (1024L * 1024 * 1024)).coerceAtLeast(2)
        val storageGb = ((machine?.storageInBytes ?: (32L * 1024 * 1024 * 1024)) / (1024L * 1024 * 1024)).coerceAtLeast(16)
        val specs = machine?.displayName?.takeIf { it.isNotBlank() }
            ?: "$cores-core • ${ramGb} GB RAM • ${storageGb} GB storage"

        val mappedStatus = when (state?.lowercase()) {
            "available" -> CodespaceStatus.Available
            "starting", "queued", "provisioning", "awaiting" -> CodespaceStatus.Starting
            "rebuilding" -> CodespaceStatus.Rebuilding
            else -> CodespaceStatus.Shutdown
        }

        return CodespaceInfo(
            id = id.toString(),
            name = name,
            displayName = displayName?.takeIf { it.isNotBlank() } ?: name,
            repoFullName = repository?.fullName ?: "unknown/repository",
            branch = gitStatus?.ref?.takeIf { it.isNotBlank() } ?: "main",
            machineSpecs = specs,
            region = location?.takeIf { it.isNotBlank() } ?: "EastUs",
            lastUsed = formatIsoTimestamp(lastUsedAt),
            status = mappedStatus,
            isDemo = false,
        )
    }

    private fun formatIsoTimestamp(iso: String?): String {
        if (iso.isNullOrBlank()) return "Recently"
        return iso.replace("T", " ").removeSuffix("Z").take(16) + " UTC"
    }
}
