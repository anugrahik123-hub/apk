package com.example.data

import com.example.model.AgentTask
import com.example.model.AgentTaskStatus
import com.example.model.AiModelOption
import com.example.model.AnsiColorRole
import com.example.model.AnsiSegment
import com.example.model.AttachmentType
import com.example.model.BridgeConfig
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.DiffLine
import com.example.model.DiffLineType
import com.example.model.FccModelSlots
import com.example.model.FccProviderConfig
import com.example.model.FccRequestLog
import com.example.model.FileDiffEntry
import com.example.model.FileNode
import com.example.model.MessageRole
import com.example.model.ModelProviderGroup
import com.example.model.TerminalLine
import com.example.model.TerminalTabSession
import com.example.model.ToolCallBlock
import com.example.model.ToolCallStatus
import com.example.model.ToolType

object DemoDataFactory {

    val defaultModels: List<AiModelOption> = listOf(
        AiModelOption(
            id = "claude-fable-5-2",
            displayName = "Claude Fable 5.2",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            tags = listOf("Frontier", "Adaptive Thinking", "Ultracode"),
            contextWindowK = 1000,
            fccSlot = "fable",
        ),
        AiModelOption(
            id = "claude-opus-4-6",
            displayName = "Claude Opus 4.6",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            tags = listOf("Reasoning", "Deep Agent"),
            contextWindowK = 200,
            fccSlot = "opus",
        ),
        AiModelOption(
            id = "claude-sonnet-4-6",
            displayName = "Claude Sonnet 4.6",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            tags = listOf("Balanced", "Coding"),
            contextWindowK = 200,
            fccSlot = "sonnet",
        ),
        AiModelOption(
            id = "claude-haiku-4-5",
            displayName = "Claude Haiku 4.5",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            tags = listOf("Fast", "Low Latency"),
            contextWindowK = 200,
            fccSlot = "haiku",
        ),
        AiModelOption(
            id = "nvidia/deepseek-r1",
            displayName = "DeepSeek R1",
            provider = "NVIDIA NIM",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Reasoning", "Free via FCC"),
            contextWindowK = 128,
            fccSlot = "opus",
        ),
        AiModelOption(
            id = "openrouter/qwen-3-coder-480b",
            displayName = "Qwen 3 Coder 480B",
            provider = "OpenRouter",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Coding", "Free via FCC"),
            contextWindowK = 256,
            fccSlot = "sonnet",
        ),
        AiModelOption(
            id = "openrouter/kimi-k2",
            displayName = "Kimi K2 Instruct",
            provider = "OpenRouter",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Agentic", "Free via FCC"),
            contextWindowK = 128,
            fccSlot = "sonnet",
        ),
        AiModelOption(
            id = "openrouter/glm-4.5-air",
            displayName = "GLM 4.5 Air",
            provider = "OpenRouter",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Fast", "Free via FCC"),
            contextWindowK = 128,
            fccSlot = "haiku",
        ),
        AiModelOption(
            id = "groq/llama-3.3-70b-versatile",
            displayName = "Llama 3.3 70B",
            provider = "Groq",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Ultra-Fast", "Free via FCC"),
            contextWindowK = 128,
            fccSlot = "haiku",
        ),
        AiModelOption(
            id = "ollama/qwen2.5-coder:32b",
            displayName = "Qwen 2.5 Coder 32B",
            provider = "Ollama Local",
            group = ModelProviderGroup.FccCustom,
            tags = listOf("Local", "Free via FCC"),
            contextWindowK = 64,
            fccSlot = "sonnet",
        ),
    )

    val demoCodespaces: List<CodespaceInfo> = listOf(
        CodespaceInfo(
            id = "cs-fcc-primary",
            name = "silver-orbit-fcc-9x4q",
            displayName = "FCC Proxy & Studio Core",
            repoFullName = "alishahryar1/free-claude-code",
            branch = "main",
            machineSpecs = "4-core • 16 GB RAM • 32 GB storage",
            region = "EastUs",
            lastUsed = "2 mins ago",
            status = CodespaceStatus.Available,
            isDemo = true,
        ),
        CodespaceInfo(
            id = "cs-fullstack-app",
            name = "warm-terracotta-api-7v2m",
            displayName = "SaaS Billing & Edge API",
            repoFullName = "devstudio/edge-billing-platform",
            branch = "feat/streaming-webhooks",
            machineSpecs = "8-core • 32 GB RAM • 64 GB storage",
            region = "WestEurope",
            lastUsed = "Yesterday",
            status = CodespaceStatus.Shutdown,
            isDemo = true,
        ),
        CodespaceInfo(
            id = "cs-ml-eval",
            name = "quiet-horizon-bench-3k9p",
            displayName = "Agent Tool-Call Eval Harness",
            repoFullName = "alishahryar1/fcc-eval-suite",
            branch = "exp/deepseek-r1-tools",
            machineSpecs = "4-core • 16 GB RAM • 32 GB storage",
            region = "SoutheastAsia",
            lastUsed = "4 days ago",
            status = CodespaceStatus.Shutdown,
            isDemo = true,
        ),
    )

    fun defaultBridgeConfig(codespaceName: String): BridgeConfig = BridgeConfig(
        codespaceName = codespaceName,
        wsUrl = "wss://$codespaceName-8765.app.github.dev",
        fccServerUrl = "https://$codespaceName-8082.app.github.dev",
        bearerSecret = "",
    )

    fun createDemoFileTree(): List<FileNode> = listOf(
        FileNode(
            path = "src",
            name = "src",
            isDirectory = true,
            children = listOf(
                FileNode(
                    path = "src/fcc_server",
                    name = "fcc_server",
                    isDirectory = true,
                    children = listOf(
                        FileNode(
                            path = "src/fcc_server/router.py",
                            name = "router.py",
                            isDirectory = false,
                            gitStatus = "M",
                            content = """from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import StreamingResponse
from .providers import ProviderRegistry
from .schemas import AnthropicMessagesRequest

router = APIRouter(prefix="/v1")

@router.post("/messages")
async def proxy_messages(payload: AnthropicMessagesRequest, request: Request):
    \"\"\"Translate Anthropic Messages API requests to configured FCC providers.\"\"\"
    slot = resolve_model_slot(payload.model)
    provider = ProviderRegistry.get_for_slot(slot)
    if not provider.is_healthy():
        raise HTTPException(status_code=503, detail=f"Provider {provider.name} unavailable")

    if payload.stream:
        return StreamingResponse(
            provider.stream_anthropic_sse(payload),
            media_type="text/event-stream",
            headers={"X-FCC-Slot": slot, "X-FCC-Target": provider.target_model},
        )
    return await provider.complete_messages(payload)

def resolve_model_slot(model_id: str) -> str:
    lower = model_id.lower()
    if "fable" in lower:
        return "fable"
    if "opus" in lower:
        return "opus"
    if "haiku" in lower:
        return "haiku"
    return "sonnet"
""",
                        ),
                        FileNode(
                            path = "src/fcc_server/providers.py",
                            name = "providers.py",
                            isDirectory = false,
                            gitStatus = "M",
                            content = """import os
from dataclasses import dataclass
from typing import Dict

@dataclass
class ProviderEndpoint:
    name: str
    base_url: str
    api_key_env: str
    target_model: str
    timeout_sec: float = 90.0

    def is_healthy(self) -> bool:
        return bool(os.getenv(self.api_key_env)) or self.name == "ollama"

class ProviderRegistry:
    _slots: Dict[str, ProviderEndpoint] = {
        "fable": ProviderEndpoint(
            name="nvidia-nim",
            base_url="https://integrate.api.nvidia.com/v1",
            api_key_env="NVIDIA_API_KEY",
            target_model="deepseek-ai/deepseek-r1",
        ),
        "opus": ProviderEndpoint(
            name="nvidia-nim",
            base_url="https://integrate.api.nvidia.com/v1",
            api_key_env="NVIDIA_API_KEY",
            target_model="deepseek-ai/deepseek-r1",
        ),
        "sonnet": ProviderEndpoint(
            name="openrouter",
            base_url="https://openrouter.ai/api/v1",
            api_key_env="OPENROUTER_API_KEY",
            target_model="qwen/qwen3-coder-480b-a35b:free",
        ),
        "haiku": ProviderEndpoint(
            name="groq",
            base_url="https://api.groq.com/openai/v1",
            api_key_env="GROQ_API_KEY",
            target_model="llama-3.3-70b-versatile",
        ),
    }

    @classmethod
    def get_for_slot(cls, slot: str) -> ProviderEndpoint:
        return cls._slots.get(slot, cls._slots["sonnet"])
""",
                        ),
                        FileNode(
                            path = "src/fcc_server/stream_adapter.py",
                            name = "stream_adapter.py",
                            isDirectory = false,
                            gitStatus = "A",
                            content = """import json
from typing import AsyncIterator

async def openai_chunks_to_anthropic_sse(chunks: AsyncIterator[dict]) -> AsyncIterator[str]:
    \"\"\"Convert OpenAI-compatible delta chunks (including reasoning_content) into Anthropic SSE.\"\"\"
    yield f"event: message_start\\ndata: {json.dumps({'type': 'message_start'})}\\n\\n"
    async for chunk in chunks:
        delta = chunk.get("choices", [{}])[0].get("delta", {})
        if reasoning := delta.get("reasoning_content"):
            payload = {"type": "content_block_delta", "delta": {"type": "thinking_delta", "thinking": reasoning}}
            yield f"event: content_block_delta\\ndata: {json.dumps(payload)}\\n\\n"
        if text := delta.get("content"):
            payload = {"type": "content_block_delta", "delta": {"type": "text_delta", "text": text}}
            yield f"event: content_block_delta\\ndata: {json.dumps(payload)}\\n\\n"
    yield f"event: message_stop\\ndata: {json.dumps({'type': 'message_stop'})}\\n\\n"
""",
                        ),
                    ),
                ),
                FileNode(
                    path = "src/cli",
                    name = "cli",
                    isDirectory = true,
                    children = listOf(
                        FileNode(
                            path = "src/cli/fcc_claude.py",
                            name = "fcc_claude.py",
                            isDirectory = false,
                            content = """import os
import subprocess
import sys

def main() -> int:
    env = os.environ.copy()
    env.setdefault("ANTHROPIC_BASE_URL", "http://127.0.0.1:8082")
    env.setdefault("ANTHROPIC_API_KEY", "fcc-local-proxy-key")
    cmd = ["claude", *sys.argv[1:]]
    return subprocess.call(cmd, env=env)

if __name__ == "__main__":
    raise SystemExit(main())
""",
                        ),
                        FileNode(
                            path = "src/cli/bridge_agent.py",
                            name = "bridge_agent.py",
                            isDirectory = false,
                            gitStatus = "U",
                            content = """\"\"\"Lightweight WebSocket bridge for Claude Code Studio on port 8765.\"\"\"
import asyncio
import json
import websockets

async def handle_client(ws):
    async for raw in ws:
        msg = json.loads(raw)
        if msg.get("type") == "ping":
            await ws.send(json.dumps({"type": "pong"}))
""",
                        ),
                    ),
                ),
            ),
        ),
        FileNode(
            path = "tests",
            name = "tests",
            isDirectory = true,
            children = listOf(
                FileNode(
                    path = "tests/test_router.py",
                    name = "test_router.py",
                    isDirectory = false,
                    content = """import pytest
from src.fcc_server.router import resolve_model_slot

@pytest.mark.parametrize("model_id,expected", [
    ("claude-fable-5-2", "fable"),
    ("claude-opus-4-6", "opus"),
    ("claude-sonnet-4-6", "sonnet"),
    ("claude-haiku-4-5", "haiku"),
])
def test_resolve_model_slot(model_id: str, expected: str):
    assert resolve_model_slot(model_id) == expected
""",
                ),
            ),
        ),
        FileNode(
            path = "pyproject.toml",
            name = "pyproject.toml",
            isDirectory = false,
            content = """[project]
name = "free-claude-code"
version = "0.8.4"
requires-python = ">=3.11"

[project.scripts]
fcc-server = "fcc_server.main:run"
fcc-claude = "cli.fcc_claude:main"
""",
        ),
        FileNode(
            path = "README.md",
            name = "README.md",
            isDirectory = false,
            content = """# free-claude-code

Run Claude Code (`fcc-claude`) against free & custom OpenAI-compatible providers via `fcc-server`.

## Quick Start
1. Start the local proxy & admin UI: `fcc-server` (listens on `:8082`)
2. Launch Claude Code routed through FCC: `fcc-claude`
""",
        ),
    )

    fun flattenFiles(nodes: List<FileNode>): List<FileNode> {
        val result = mutableListOf<FileNode>()
        fun walk(list: List<FileNode>) {
            for (node in list) {
                if (!node.isDirectory) {
                    result += node
                }
                if (node.children.isNotEmpty()) {
                    walk(node.children)
                }
            }
        }
        walk(nodes)
        return result
    }

    fun createDemoFccProviders(): List<FccProviderConfig> = listOf(
        FccProviderConfig(
            id = "nvidia",
            name = "NVIDIA NIM",
            endpoint = "https://integrate.api.nvidia.com/v1",
            apiKeyConfigured = true,
            enabled = true,
            models = listOf("nvidia/deepseek-r1", "nvidia/llama-3.3-nemotron-super-49b"),
        ),
        FccProviderConfig(
            id = "openrouter",
            name = "OpenRouter",
            endpoint = "https://openrouter.ai/api/v1",
            apiKeyConfigured = true,
            enabled = true,
            models = listOf("openrouter/qwen-3-coder-480b", "openrouter/kimi-k2", "openrouter/glm-4.5-air"),
        ),
        FccProviderConfig(
            id = "groq",
            name = "Groq Cloud",
            endpoint = "https://api.groq.com/openai/v1",
            apiKeyConfigured = true,
            enabled = true,
            models = listOf("groq/llama-3.3-70b-versatile", "groq/qwen-qwq-32b"),
        ),
        FccProviderConfig(
            id = "cerebras",
            name = "Cerebras Inference",
            endpoint = "https://api.cerebras.ai/v1",
            apiKeyConfigured = false,
            enabled = false,
            models = listOf("cerebras/llama-3.3-70b"),
        ),
        FccProviderConfig(
            id = "ollama",
            name = "Ollama (Codespace Local)",
            endpoint = "http://127.0.0.1:11434/v1",
            apiKeyConfigured = true,
            enabled = true,
            models = listOf("ollama/qwen2.5-coder:32b"),
        ),
    )

    fun createDemoFccSlots(): FccModelSlots = FccModelSlots()

    fun createDemoFccLogs(): List<FccRequestLog> = listOf(
        FccRequestLog("log-1", "21:29:44", "POST /v1/messages", "sonnet", "openrouter/qwen-3-coder-480b", 200, 642, 3_412),
        FccRequestLog("log-2", "21:28:19", "POST /v1/messages", "opus", "nvidia/deepseek-r1", 200, 1_284, 5_190),
        FccRequestLog("log-3", "21:26:03", "POST /v1/messages", "haiku", "groq/llama-3.3-70b-versatile", 200, 218, 940),
        FccRequestLog("log-4", "21:21:55", "GET /v1/models", "admin", "fcc-registry", 200, 14, 0),
    )

    fun createDemoSessions(): List<ChatSession> {
        val now = System.currentTimeMillis()
        val initialDiff = listOf(
            DiffLine(DiffLineType.Context, 12, 12, "    if not provider.is_healthy():"),
            DiffLine(DiffLineType.Removed, 13, null, "        raise HTTPException(status_code=503, detail=f\"Provider {provider.name} unavailable\")"),
            DiffLine(DiffLineType.Added, null, 13, "        provider = ProviderRegistry.get_fallback(slot)"),
            DiffLine(DiffLineType.Added, null, 14, "        if provider is None:"),
            DiffLine(DiffLineType.Added, null, 15, "            raise HTTPException(status_code=503, detail=\"No healthy FCC providers configured\")"),
            DiffLine(DiffLineType.Context, 14, 16, ""),
            DiffLine(DiffLineType.Context, 15, 17, "    if payload.stream:"),
        )

        return listOf(
            ChatSession(
                id = "sess-today-1",
                title = "Add automatic provider failover in fcc-server",
                group = "Today",
                modelId = "claude-sonnet-4-6",
                isPinned = true,
                updatedAtMs = now - 120_000,
                messages = listOf(
                    ChatMessage(
                        id = "msg-1",
                        role = MessageRole.User,
                        text = "Inspect @src/fcc_server/router.py and add automatic fallback routing when the primary provider returns 503 or lacks an API key.",
                        timestampMs = now - 180_000,
                        attachments = listOf(
                            ContextAttachment(
                                id = "att-1",
                                type = AttachmentType.File,
                                label = "router.py",
                                pathOrUri = "src/fcc_server/router.py",
                            ),
                        ),
                    ),
                    ChatMessage(
                        id = "msg-2",
                        role = MessageRole.Assistant,
                        text = """I inspected `src/fcc_server/router.py` and `src/fcc_server/providers.py`. Right now `proxy_messages` immediately raises an HTTP `503` if the slot's primary provider fails `is_healthy()`.

### Recommended Failover Strategy
- Keep the primary slot routing (`opus` / `sonnet` / `haiku`) as the fast path.
- Fall back to the next healthy provider registered in `ProviderRegistry` before returning `503`.
- Emit `X-FCC-Failover: true` in the SSE response headers so the Admin UI logs can highlight fallback events.

```python
# src/fcc_server/router.py
if not provider.is_healthy():
    provider = ProviderRegistry.get_fallback(slot)
    if provider is None:
        raise HTTPException(status_code=503, detail="No healthy FCC providers configured")
```

I have staged the proposed edit below and updated the session diff inspector.""",
                        timestampMs = now - 150_000,
                        thinkingText = "Checking router.py line 12: proxy_messages checks provider.is_healthy() and immediately raises HTTPException(503). If NVIDIA NIM is rate-limited or missing a key, falling back to OpenRouter or Ollama keeps fcc-claude responsive without interrupting tool-call loops.",
                        thinkingDurationMs = 3_400L,
                        isThinkingComplete = true,
                        isThinkingExpanded = false,
                        toolCalls = listOf(
                            ToolCallBlock(
                                id = "tc-read-1",
                                toolType = ToolType.ReadFile,
                                actionLabel = "Read File",
                                targetPathOrCommand = "src/fcc_server/router.py",
                                status = ToolCallStatus.Executed,
                                stdoutOutput = "Read 29 lines from src/fcc_server/router.py (1.1 KB)",
                            ),
                            ToolCallBlock(
                                id = "tc-edit-1",
                                toolType = ToolType.EditFile,
                                actionLabel = "Edit File",
                                targetPathOrCommand = "src/fcc_server/router.py",
                                diffLines = initialDiff,
                                status = ToolCallStatus.Executed,
                                stdoutOutput = "Applied 1 hunk (+3 -1) to src/fcc_server/router.py",
                            ),
                        ),
                        inputTokens = 2_840,
                        outputTokens = 612,
                        latencyMs = 2_410L,
                    ),
                ),
                contextBreakdown = ContextBreakdown(
                    systemTokens = 4_200,
                    filesTokens = 9_800,
                    messagesTokens = 14_200,
                    toolOutputTokens = 6_400,
                    maxTokens = 200_000,
                ),
                tasks = listOf(
                    AgentTask("t1", "Audit router.py & providers.py health checks", AgentTaskStatus.Completed),
                    AgentTask("t2", "Add fallback provider resolution to proxy_messages", AgentTaskStatus.Completed),
                    AgentTask("t3", "Add unit tests for 503 failover in tests/test_router.py", AgentTaskStatus.InProgress),
                    AgentTask("t4", "Verify SSE streaming headers with fcc-server", AgentTaskStatus.Pending),
                ),
                fileChanges = listOf(
                    FileDiffEntry(
                        path = "src/fcc_server/router.py",
                        addedCount = 3,
                        removedCount = 1,
                        isStaged = false,
                        diffLines = initialDiff,
                    ),
                ),
            ),
            ChatSession(
                id = "sess-yesterday-1",
                title = "Fix thinking_delta SSE framing for DeepSeek R1",
                group = "Yesterday",
                modelId = "nvidia/deepseek-r1",
                isPinned = false,
                updatedAtMs = now - 86_400_000L,
                messages = listOf(
                    ChatMessage(
                        id = "msg-y1",
                        role = MessageRole.User,
                        text = "DeepSeek R1 streams reasoning_content chunks. Map them cleanly to Anthropic thinking_delta SSE events.",
                        timestampMs = now - 86_500_000L,
                    ),
                    ChatMessage(
                        id = "msg-y2",
                        role = MessageRole.Assistant,
                        text = "Added `openai_chunks_to_anthropic_sse` in `src/fcc_server/stream_adapter.py` so `reasoning_content` streams directly into Claude Code's Thinking accordion.",
                        timestampMs = now - 86_400_000L,
                        thinkingText = "Anthropic's Messages SSE protocol emits content_block_delta with delta.type='thinking_delta'. Mapping OpenAI's reasoning_content field preserves live elapsed thinking UI.",
                        thinkingDurationMs = 2_100L,
                        inputTokens = 1_920,
                        outputTokens = 380,
                        latencyMs = 1_850L,
                    ),
                ),
                contextBreakdown = ContextBreakdown(
                    systemTokens = 4_200,
                    filesTokens = 5_100,
                    messagesTokens = 8_900,
                    toolOutputTokens = 2_400,
                    maxTokens = 128_000,
                ),
                tasks = listOf(
                    AgentTask("ty1", "Map reasoning_content to thinking_delta SSE", AgentTaskStatus.Completed),
                ),
            ),
            ChatSession(
                id = "sess-week-1",
                title = "Benchmark Qwen 3 Coder vs Haiku tool latency",
                group = "Previous 7 Days",
                modelId = "openrouter/qwen-3-coder-480b",
                isPinned = false,
                updatedAtMs = now - 345_600_000L,
                messages = listOf(
                    ChatMessage(
                        id = "msg-w1",
                        role = MessageRole.User,
                        text = "Compare median TTFT across OpenRouter Qwen 3 Coder and Groq Llama 3.3 for quick grep + edit loops.",
                        timestampMs = now - 345_700_000L,
                    ),
                    ChatMessage(
                        id = "msg-w2",
                        role = MessageRole.Assistant,
                        text = "| Provider Slot | Model | Median TTFT | Tool Accuracy |\n|---|---|---|---|\n| Sonnet | Qwen 3 Coder 480B | 540 ms | 96.4% |\n| Haiku | Llama 3.3 70B (Groq) | 195 ms | 91.2% |\n\nRecommendation: keep **Groq Llama 3.3** on the `haiku` slot for instant sub-agent searches and **Qwen 3 Coder** on `sonnet` for multi-file edits.",
                        timestampMs = now - 345_600_000L,
                        inputTokens = 1_450,
                        outputTokens = 290,
                        latencyMs = 1_420L,
                    ),
                ),
                contextBreakdown = ContextBreakdown(
                    systemTokens = 4_200,
                    filesTokens = 2_000,
                    messagesTokens = 4_800,
                    toolOutputTokens = 1_100,
                    maxTokens = 256_000,
                ),
            ),
        )
    }

    fun createInitialTerminalTabs(): List<TerminalTabSession> = listOf(
        TerminalTabSession(
            id = "term-bash-1",
            title = "bash 1",
            cwd = "/workspaces/free-claude-code",
            lines = listOf(
                TerminalLine(
                    id = "l1",
                    segments = listOf(
                        AnsiSegment("codespace", AnsiColorRole.Green),
                        AnsiSegment(" ➜ ", AnsiColorRole.Muted),
                        AnsiSegment("/workspaces/free-claude-code", AnsiColorRole.Blue),
                        AnsiSegment(" (main)", AnsiColorRole.Accent),
                        AnsiSegment(" $ fcc-claude --version", AnsiColorRole.Default),
                    ),
                ),
                TerminalLine(
                    id = "l2",
                    segments = listOf(
                        AnsiSegment("free-claude-code v0.8.4 (Claude Code CLI wrapper • proxy http://127.0.0.1:8082)", AnsiColorRole.Muted),
                    ),
                ),
                TerminalLine(
                    id = "l3",
                    segments = listOf(
                        AnsiSegment("Bridge active: ", AnsiColorRole.Green),
                        AnsiSegment("GUI controls silently sync /model, /effort, /compact, and tool approvals.", AnsiColorRole.Default),
                    ),
                ),
            ),
            commandHistory = listOf("fcc-claude --version", "git status"),
        ),
        TerminalTabSession(
            id = "term-fcc-server",
            title = "fcc-server",
            cwd = "/workspaces/free-claude-code",
            lines = listOf(
                TerminalLine(
                    id = "fs1",
                    segments = listOf(
                        AnsiSegment("[fcc-server] ", AnsiColorRole.Accent),
                        AnsiSegment("Uvicorn running on ", AnsiColorRole.Default),
                        AnsiSegment("http://0.0.0.0:8082", AnsiColorRole.Blue),
                        AnsiSegment(" (Press CTRL+C to quit)", AnsiColorRole.Muted),
                    ),
                ),
                TerminalLine(
                    id = "fs2",
                    segments = listOf(
                        AnsiSegment("[fcc-server] ", AnsiColorRole.Accent),
                        AnsiSegment("Loaded slots: ", AnsiColorRole.Muted),
                        AnsiSegment("opus→nvidia/deepseek-r1  sonnet→openrouter/qwen-3-coder-480b  haiku→groq/llama-3.3-70b", AnsiColorRole.Green),
                    ),
                ),
                TerminalLine(
                    id = "fs3",
                    segments = listOf(
                        AnsiSegment("INFO:     ", AnsiColorRole.Green),
                        AnsiSegment("127.0.0.1:51402 - \"POST /v1/messages HTTP/1.1\" ", AnsiColorRole.Default),
                        AnsiSegment("200 OK", AnsiColorRole.Green),
                        AnsiSegment(" (642ms • src/fcc_server/router.py)", AnsiColorRole.Muted, clickableFilePath = "src/fcc_server/router.py"),
                    ),
                ),
            ),
            commandHistory = listOf("fcc-server"),
        ),
    )
}
