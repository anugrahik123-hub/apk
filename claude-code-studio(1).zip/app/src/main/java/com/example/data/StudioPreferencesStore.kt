package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.BridgeConfig
import com.example.model.ChatSession
import com.example.model.StudioSettings
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.first

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "claude_code_studio_prefs",
)

data class PersistedStudioData(
    val githubPat: String = "",
    val githubUserLogin: String = "",
    val settings: StudioSettings = StudioSettings(),
    val bridgeConfigs: Map<String, BridgeConfig> = emptyMap(),
    val savedSessions: List<ChatSession> = emptyList(),
)

class StudioPreferencesStore(private val context: Context) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val settingsAdapter = moshi.adapter(StudioSettings::class.java)
    private val bridgeMapType = Types.newParameterizedType(
        Map::class.java,
        String::class.java,
        BridgeConfig::class.java,
    )
    private val bridgeMapAdapter = moshi.adapter<Map<String, BridgeConfig>>(bridgeMapType)

    private val sessionListType = Types.newParameterizedType(
        List::class.java,
        ChatSession::class.java,
    )
    private val sessionListAdapter = moshi.adapter<List<ChatSession>>(sessionListType)

    private object Keys {
        val GITHUB_PAT = stringPreferencesKey("github_pat")
        val GITHUB_USER_LOGIN = stringPreferencesKey("github_user_login")
        val SETTINGS_JSON = stringPreferencesKey("studio_settings_json")
        val BRIDGE_CONFIGS_JSON = stringPreferencesKey("bridge_configs_json")
        val SESSIONS_JSON = stringPreferencesKey("demo_sessions_json")
    }

    suspend fun loadAll(): PersistedStudioData {
        val prefs = context.studioDataStore.data.first()
        val settings = prefs[Keys.SETTINGS_JSON]?.let { json ->
            runCatching { settingsAdapter.fromJson(json) }.getOrNull()
        } ?: StudioSettings()

        val bridges = prefs[Keys.BRIDGE_CONFIGS_JSON]?.let { json ->
            runCatching { bridgeMapAdapter.fromJson(json) }.getOrNull()
        } ?: emptyMap()

        val sessions = prefs[Keys.SESSIONS_JSON]?.let { json ->
            runCatching { sessionListAdapter.fromJson(json) }.getOrNull()
        } ?: emptyList()

        return PersistedStudioData(
            githubPat = prefs[Keys.GITHUB_PAT].orEmpty(),
            githubUserLogin = prefs[Keys.GITHUB_USER_LOGIN].orEmpty(),
            settings = settings,
            bridgeConfigs = bridges,
            savedSessions = sessions,
        )
    }

    suspend fun saveGitHubAuth(pat: String, userLogin: String) {
        context.studioDataStore.edit { prefs ->
            prefs[Keys.GITHUB_PAT] = pat
            prefs[Keys.GITHUB_USER_LOGIN] = userLogin
        }
    }

    suspend fun clearGitHubAuth() {
        context.studioDataStore.edit { prefs ->
            prefs.remove(Keys.GITHUB_PAT)
            prefs.remove(Keys.GITHUB_USER_LOGIN)
        }
    }

    suspend fun saveSettings(settings: StudioSettings) {
        val encoded = settingsAdapter.toJson(settings)
        context.studioDataStore.edit { prefs ->
            prefs[Keys.SETTINGS_JSON] = encoded
        }
    }

    suspend fun saveBridgeConfigs(configs: Map<String, BridgeConfig>) {
        val encoded = bridgeMapAdapter.toJson(configs)
        context.studioDataStore.edit { prefs ->
            prefs[Keys.BRIDGE_CONFIGS_JSON] = encoded
        }
    }

    suspend fun saveSessions(sessions: List<ChatSession>) {
        val encoded = sessionListAdapter.toJson(sessions.take(25))
        context.studioDataStore.edit { prefs ->
            prefs[Keys.SESSIONS_JSON] = encoded
        }
    }
}
