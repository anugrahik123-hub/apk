package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DemoDataFactory
import com.example.model.AppScreen
import com.example.ui.screens.BridgeConfigurationDialog
import com.example.ui.screens.CodespacesDashboardScreen
import com.example.ui.screens.CommandPaletteDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SettingsModalDialog
import com.example.ui.screens.WorkspaceShellScreen
import com.example.ui.theme.ClaudeCodeStudioTheme
import com.example.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {
    private val studioViewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClaudeCodeStudioApp(viewModel = studioViewModel)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && (event.isCtrlPressed || event.isMetaPressed)) {
            val state = studioViewModel.uiState.value
            if (state.currentScreen == AppScreen.Workspace) {
                when {
                    event.keyCode == KeyEvent.KEYCODE_K -> {
                        studioViewModel.setShowCommandPalette(!state.showCommandPalette)
                        return true
                    }
                    event.keyCode == KeyEvent.KEYCODE_B -> {
                        studioViewModel.toggleLeftSidebar()
                        return true
                    }
                    event.keyCode == KeyEvent.KEYCODE_J -> {
                        studioViewModel.toggleBottomTerminal()
                        return true
                    }
                    event.keyCode == KeyEvent.KEYCODE_BACKSLASH -> {
                        studioViewModel.toggleRightInspector()
                        return true
                    }
                    event.keyCode == KeyEvent.KEYCODE_N && event.isShiftPressed -> {
                        studioViewModel.createNewSession()
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
}

@Composable
fun ClaudeCodeStudioApp(
    viewModel: StudioViewModel,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    ClaudeCodeStudioTheme(
        darkTheme = state.settings.darkMode,
        useSerifProse = state.settings.useSerifProse,
        codeFontSizeSp = state.settings.codeFontSizeSp,
    ) {
        when (state.currentScreen) {
            AppScreen.Login -> {
                LoginScreen(
                    initialPat = state.githubPat,
                    isLoading = state.authLoading,
                    errorMessage = state.authError,
                    isDarkMode = state.settings.darkMode,
                    onConnectGitHub = viewModel::connectWithGitHubPat,
                    onEnterDemoMode = viewModel::enterDemoMode,
                    onToggleTheme = viewModel::toggleDarkMode,
                )
            }

            AppScreen.Dashboard -> {
                CodespacesDashboardScreen(
                    codespaces = state.codespaces,
                    bridgeConfigs = state.bridgeConfigs,
                    isDemoMode = state.isDemoMode,
                    githubUserLogin = state.githubUserLogin,
                    isLoading = state.codespacesLoading,
                    errorMessage = state.codespacesError,
                    isDarkMode = state.settings.darkMode,
                    onRefresh = viewModel::refreshCodespaces,
                    onConnect = viewModel::connectToCodespace,
                    onStart = viewModel::startCodespace,
                    onStop = viewModel::stopCodespace,
                    onConfigureBridge = viewModel::openBridgeConfigModal,
                    onToggleTheme = viewModel::toggleDarkMode,
                    onOpenSettings = { viewModel.setShowSettingsModal(true) },
                    onLogout = viewModel::logoutGitHub,
                )
            }

            AppScreen.Workspace -> {
                WorkspaceShellScreen(
                    state = state,
                    viewModel = viewModel,
                )
            }
        }

        // Global Modals & Overlays
        state.bridgeModalCodespace?.let { cs ->
            val currentCfg = state.bridgeConfigs[cs.name] ?: DemoDataFactory.defaultBridgeConfig(cs.name)
            BridgeConfigurationDialog(
                codespace = cs,
                initialConfig = currentCfg,
                isTesting = state.bridgeTesting,
                testResult = state.bridgeTestResult,
                onDismiss = viewModel::dismissBridgeConfigModal,
                onSave = viewModel::saveBridgeConfig,
                onTest = viewModel::testBridgeConnection,
            )
        }

        if (state.showSettingsModal) {
            SettingsModalDialog(
                settings = state.settings,
                isDemoMode = state.isDemoMode,
                githubUserLogin = state.githubUserLogin,
                availableModels = state.availableModels,
                onUpdateSettings = viewModel::updateSettings,
                onLogout = viewModel::logoutGitHub,
                onDismiss = { viewModel.setShowSettingsModal(false) },
            )
        }

        if (state.showCommandPalette) {
            CommandPaletteDialog(
                codespaces = state.codespaces,
                models = state.availableModels,
                sessions = state.sessions,
                onSelectTab = viewModel::selectWorkspaceTab,
                onSelectCodespace = viewModel::connectToCodespace,
                onSelectModel = viewModel::selectModel,
                onSelectEffort = viewModel::selectEffort,
                onSelectSession = viewModel::selectSession,
                onNewSession = viewModel::createNewSession,
                onOpenSettings = { viewModel.setShowSettingsModal(true) },
                onDismiss = { viewModel.setShowCommandPalette(false) },
            )
        }
    }
}
