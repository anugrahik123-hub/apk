package com.example.model

import com.squareup.moshi.JsonClass

enum class AppScreen {
    Login,
    Dashboard,
    Workspace,
}

enum class WorkspaceTab(val label: String) {
    ClaudeCode("Claude Code"),
    FccAdmin("FCC Admin"),
    Terminal("Terminal"),
}

enum class SidebarTab(val label: String) {
    Sessions("Sessions"),
    Files("Files"),
}

enum class InspectorTab(val label: String) {
    Changes("Changes"),
    FileViewer("File Viewer"),
    Plan("Plan"),
}

enum class CodespaceStatus(val label: String) {
    Available("Available"),
    Starting("Starting"),
    Shutdown("Shutdown"),
    Rebuilding("Rebuilding"),
}

enum class ConnectionState(val label: String) {
    Disconnected("Disconnected"),
    Connecting("Connecting"),
    Connected("Connected"),
    Reconnecting("Reconnecting"),
    DemoMode("Demo Mode"),
}

@JsonClass(generateAdapter = true)
data class CodespaceInfo(
    val id: String,
    val name: String,
    val displayName: String,
    val repoFullName: String,
    val branch: String,
    val machineSpecs: String,
    val region: String,
    val lastUsed: String,
    val status: CodespaceStatus,
    val isDemo: Boolean = false,
)

@JsonClass(generateAdapter = true)
data class BridgeConfig(
    val codespaceName: String,
    val wsUrl: String,
    val fccServerUrl: String,
    val bearerSecret: String = "",
)

data class BridgeTestResult(
    val success: Boolean,
    val wsLatencyMs: Long?,
    val fccLatencyMs: Long?,
    val diagnostics: String,
)

enum class ModelProviderGroup(val label: String) {
    Claude("Anthropic Claude"),
    FccCustom("Free & Custom via fcc-server"),
}

data class AiModelOption(
    val id: String,
    val displayName: String,
    val provider: String,
    val group: ModelProviderGroup,
    val tags: List<String>,
    val contextWindowK: Int,
    val fccSlot: String? = null,
)

enum class EffortLevel(
    val cliValue: String,
    val label: String,
    val bars: Int,
    val subtitle: String? = null,
) {
    Low("low", "Low", 1),
    Medium("medium", "Medium", 2),
    High("high", "High", 3),
    Max("max", "Max", 4),
    Ultracode("ultracode", "Ultracode", 5, "Multi-agent orchestration"),
}

enum class PermissionMode(
    val cliFlag: String,
    val label: String,
    val shortLabel: String,
    val description: String,
) {
    AskBeforeEdits(
        cliFlag = "default",
        label = "Ask Before Edits",
        shortLabel = "Ask Edits",
        description = "Prompts approval cards before editing files or running bash commands.",
    ),
    AutoAcceptEdits(
        cliFlag = "acceptEdits",
        label = "Auto-Accept Edits",
        shortLabel = "Auto Edits",
        description = "Applies file edits automatically; prompts approval before bash commands.",
    ),
    PlanMode(
        cliFlag = "plan",
        label = "Plan Mode",
        shortLabel = "Plan Only",
        description = "Read-only codebase analysis and step-by-step architecture planning.",
    ),
    FullAuto(
        cliFlag = "bypassPermissions",
        label = "Full Auto (YOLO)",
        shortLabel = "Full Auto",
        description = "Automatically approves file edits and safe shell commands without pausing.",
    ),
}

enum class ToolType(val label: String) {
    ReadFile("Read File"),
    EditFile("Edit File"),
    WriteFile("Write File"),
    RunBash("Run Bash Command"),
    SearchGrep("Search / Grep"),
    Glob("Glob Files"),
}

enum class ToolCallStatus {
    PendingApproval,
    Running,
    Executed,
    Rejected,
}

enum class DiffLineType {
    Context,
    Added,
    Removed,
}

@JsonClass(generateAdapter = true)
data class DiffLine(
    val type: DiffLineType,
    val oldLine: Int?,
    val newLine: Int?,
    val text: String,
)

@JsonClass(generateAdapter = true)
data class ToolCallBlock(
    val id: String,
    val toolType: ToolType,
    val actionLabel: String,
    val targetPathOrCommand: String,
    val diffLines: List<DiffLine> = emptyList(),
    val status: ToolCallStatus = ToolCallStatus.PendingApproval,
    val stdoutOutput: String = "",
    val rejectionFeedback: String? = null,
    val isOutputExpanded: Boolean = false,
)

enum class AttachmentType {
    File,
    Image,
    Snippet,
}

@JsonClass(generateAdapter = true)
data class ContextAttachment(
    val id: String,
    val type: AttachmentType,
    val label: String,
    val pathOrUri: String,
    val previewContent: String = "",
)

enum class MessageRole {
    User,
    Assistant,
}

@JsonClass(generateAdapter = true)
data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val text: String,
    val timestampMs: Long,
    val attachments: List<ContextAttachment> = emptyList(),
    val thinkingText: String = "",
    val thinkingDurationMs: Long = 0L,
    val isThinkingComplete: Boolean = true,
    val isThinkingExpanded: Boolean = false,
    val isStreaming: Boolean = false,
    val toolCalls: List<ToolCallBlock> = emptyList(),
    val inputTokens: Int = 0,
    val outputTokens: Int = 0,
    val latencyMs: Long = 0L,
)

@JsonClass(generateAdapter = true)
data class ContextBreakdown(
    val systemTokens: Int = 4_200,
    val filesTokens: Int = 8_400,
    val messagesTokens: Int = 11_600,
    val toolOutputTokens: Int = 5_100,
    val maxTokens: Int = 200_000,
) {
    val totalTokens: Int
        get() = systemTokens + filesTokens + messagesTokens + toolOutputTokens

    val usageFraction: Float
        get() = if (maxTokens <= 0) 0f else (totalTokens.toFloat() / maxTokens.toFloat()).coerceIn(0f, 1f)

    val usagePercent: Int
        get() = (usageFraction * 100f).toInt()
}

enum class AgentTaskStatus {
    Completed,
    InProgress,
    Pending,
}

@JsonClass(generateAdapter = true)
data class AgentTask(
    val id: String,
    val title: String,
    val status: AgentTaskStatus,
)

@JsonClass(generateAdapter = true)
data class FileDiffEntry(
    val path: String,
    val addedCount: Int,
    val removedCount: Int,
    val isStaged: Boolean = false,
    val diffLines: List<DiffLine>,
)

@JsonClass(generateAdapter = true)
data class ChatSession(
    val id: String,
    val title: String,
    val group: String,
    val modelId: String,
    val isPinned: Boolean = false,
    val updatedAtMs: Long,
    val messages: List<ChatMessage> = emptyList(),
    val contextBreakdown: ContextBreakdown = ContextBreakdown(),
    val tasks: List<AgentTask> = emptyList(),
    val fileChanges: List<FileDiffEntry> = emptyList(),
)

data class FileNode(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val gitStatus: String? = null, // "M", "A", "U"
    val content: String? = null,
    val children: List<FileNode> = emptyList(),
)

enum class FccServerStatus(val label: String) {
    Running("Running on :8082"),
    Starting("Starting…"),
    Stopped("Stopped"),
}

data class FccProviderConfig(
    val id: String,
    val name: String,
    val endpoint: String,
    val apiKeyConfigured: Boolean,
    val enabled: Boolean,
    val models: List<String>,
)

data class FccModelSlots(
    val fableModelId: String = "nvidia/deepseek-r1",
    val opusModelId: String = "nvidia/deepseek-r1",
    val sonnetModelId: String = "openrouter/qwen-3-coder-480b",
    val haikuModelId: String = "groq/llama-3.3-70b-versatile",
)

data class FccRequestLog(
    val id: String,
    val timestamp: String,
    val method: String,
    val slot: String,
    val targetModel: String,
    val statusCode: Int,
    val latencyMs: Int,
    val tokens: Int,
)

enum class AnsiColorRole {
    Default,
    Accent,
    Green,
    Red,
    Amber,
    Blue,
    Muted,
    Bold,
}

data class AnsiSegment(
    val text: String,
    val colorRole: AnsiColorRole = AnsiColorRole.Default,
    val clickableFilePath: String? = null,
)

data class TerminalLine(
    val id: String,
    val segments: List<AnsiSegment>,
)

data class TerminalTabSession(
    val id: String,
    val title: String,
    val cwd: String = "/workspaces/free-claude-code",
    val lines: List<TerminalLine> = emptyList(),
    val commandHistory: List<String> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class StudioSettings(
    val darkMode: Boolean = true,
    val useSerifProse: Boolean = false,
    val codeFontSizeSp: Float = 12.5f,
    val defaultModelId: String = "claude-sonnet-4-6",
    val defaultEffort: EffortLevel = EffortLevel.High,
    val defaultPermissionMode: PermissionMode = PermissionMode.AskBeforeEdits,
)

data class SilentCliEvent(
    val id: String,
    val command: String,
    val timestampMs: Long,
)
