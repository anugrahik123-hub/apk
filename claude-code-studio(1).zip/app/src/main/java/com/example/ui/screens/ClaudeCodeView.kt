package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AiModelOption
import com.example.model.AttachmentType
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.ContextAttachment
import com.example.model.EffortLevel
import com.example.model.FileNode
import com.example.model.MessageRole
import com.example.model.PermissionMode
import com.example.model.SilentCliEvent
import com.example.model.ToolCallBlock
import com.example.model.ToolCallStatus
import com.example.model.ToolType
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.MarkdownProseRenderer
import com.example.ui.components.StatusDot
import com.example.ui.components.StudioPillBadge
import com.example.ui.components.UnifiedDiffBlock
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.SourceSerifFontFamily
import java.util.Locale

@Composable
fun ClaudeCodeView(
    repoFullName: String,
    session: ChatSession?,
    availableModels: List<AiModelOption>,
    selectedModelId: String,
    selectedEffort: EffortLevel,
    extendedThinkingEnabled: Boolean,
    permissionMode: PermissionMode,
    pendingAttachments: List<ContextAttachment>,
    flatRepoFiles: List<FileNode>,
    isStreaming: Boolean,
    queuedPrompt: String?,
    lastSilentCliEvent: SilentCliEvent?,
    onSendPrompt: (String) -> Unit,
    onStopGeneration: () -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onToggleExtendedThinking: (Boolean) -> Unit,
    onSelectPermissionMode: (PermissionMode) -> Unit,
    onCompactContext: () -> Unit,
    onClearConversation: () -> Unit,
    onExportTranscript: () -> Unit,
    onAttachFile: (FileNode) -> Unit,
    onAttachImage: (uriString: String, label: String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onEditAndResend: (messageId: String, newText: String) -> Unit,
    onRetryAssistant: (messageId: String) -> Unit,
    onToggleThinking: (messageId: String) -> Unit,
    onToggleToolOutput: (messageId: String, toolCallId: String) -> Unit,
    onApproveTool: (messageId: String, toolCallId: String, alwaysAllow: Boolean) -> Unit,
    onRejectTool: (messageId: String, toolCallId: String, feedback: String) -> Unit,
    onApplyCodeToFile: (fileName: String?, code: String) -> Unit,
    onOpenFile: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val messages = session?.messages.orEmpty()
    val listState = rememberLazyListState()
    var editingUserMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var rejectingToolTarget by remember { mutableStateOf<Pair<String, ToolCallBlock>?>(null) }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length, messages.lastOrNull()?.toolCalls?.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.canvas),
    ) {
        // Subtle silent CLI sync telemetry strip (shows how GUI controls map silently to fcc-claude)
        if (lastSilentCliEvent != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.sidebar.copy(alpha = 0.65f))
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                StatusDot(color = palette.success, size = 6.dp)
                Text(
                    text = "Synced silently to fcc-claude:",
                    color = palette.textTertiary,
                    fontSize = 10.5.sp,
                )
                Text(
                    text = lastSilentCliEvent.command,
                    color = palette.accent,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 10.5.sp,
                )
            }
        }

        // Conversation Stream or Empty State
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter,
        ) {
            if (messages.isEmpty()) {
                EmptySessionStarterView(
                    repoFullName = repoFullName,
                    onStarterClick = onSendPrompt,
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 860.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    items(messages, key = { it.id }) { msg ->
                        if (msg.role == MessageRole.User) {
                            UserMessageBubble(
                                message = msg,
                                onEditClick = { editingUserMessage = msg },
                                onFileClick = onOpenFile,
                            )
                        } else {
                            AssistantMessageStreamItem(
                                message = msg,
                                onToggleThinking = { onToggleThinking(msg.id) },
                                onToggleToolOutput = { tcId -> onToggleToolOutput(msg.id, tcId) },
                                onApproveTool = { tcId, always -> onApproveTool(msg.id, tcId, always) },
                                onRequestRejectTool = { tc -> rejectingToolTarget = msg.id to tc },
                                onRetry = { onRetryAssistant(msg.id) },
                                onApplyCodeToFile = onApplyCodeToFile,
                                onOpenFile = onOpenFile,
                            )
                        }
                    }
                }
            }
        }

        // Floating Visual Prompt Composer & Control Bar
        ClaudeComposerBar(
            availableModels = availableModels,
            selectedModelId = selectedModelId,
            selectedEffort = selectedEffort,
            extendedThinkingEnabled = extendedThinkingEnabled,
            permissionMode = permissionMode,
            contextBreakdown = session?.contextBreakdown ?: com.example.model.ContextBreakdown(),
            pendingAttachments = pendingAttachments,
            flatRepoFiles = flatRepoFiles,
            isStreaming = isStreaming,
            queuedPrompt = queuedPrompt,
            onSendPrompt = onSendPrompt,
            onStopGeneration = onStopGeneration,
            onSelectModel = onSelectModel,
            onSelectEffort = onSelectEffort,
            onToggleExtendedThinking = onToggleExtendedThinking,
            onSelectPermissionMode = onSelectPermissionMode,
            onCompactContext = onCompactContext,
            onClearConversation = onClearConversation,
            onExportTranscript = onExportTranscript,
            onAttachFile = onAttachFile,
            onAttachImage = onAttachImage,
            onRemoveAttachment = onRemoveAttachment,
        )
    }

    // Edit & Resend User Message Dialog
    editingUserMessage?.let { target ->
        var editedText by remember(target.id) { mutableStateOf(target.text) }
        AlertDialog(
            onDismissRequest = { editingUserMessage = null },
            containerColor = palette.surface,
            title = { Text("Edit & Resend Prompt", color = palette.textPrimary, fontSize = 16.sp) },
            text = {
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onEditAndResend(target.id, editedText)
                    editingUserMessage = null
                }) {
                    Text("Resend", color = palette.accent, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingUserMessage = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            },
        )
    }

    // Reject Tool Call with Feedback Dialog
    rejectingToolTarget?.let { (messageId, toolCall) ->
        var feedback by remember(toolCall.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { rejectingToolTarget = null },
            containerColor = palette.surface,
            title = { Text("Reject ${toolCall.actionLabel}", color = palette.textPrimary, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Optionally tell Claude what to change instead:",
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                    )
                    OutlinedTextField(
                        value = feedback,
                        onValueChange = { feedback = it },
                        placeholder = { Text("e.g. Keep existing signature, only add fallback…", color = palette.textTertiary, fontSize = 12.sp) },
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.danger,
                            unfocusedBorderColor = palette.border,
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary,
                        ),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onRejectTool(messageId, toolCall.id, feedback)
                    rejectingToolTarget = null
                }) {
                    Text("Send Rejection", color = palette.danger, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { rejectingToolTarget = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            },
        )
    }
}

@Composable
private fun EmptySessionStarterView(
    repoFullName: String,
    onStarterClick: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val shortRepo = repoFullName.substringAfterLast("/")
    val starters = listOf(
        Triple(Icons.Outlined.AutoAwesome, "Explain this codebase architecture", "Trace fcc-claude → fcc-server → provider routing"),
        Triple(Icons.Outlined.BugReport, "Find and fix bugs in recent changes", "Audit router.py & stream_adapter.py edge cases"),
        Triple(Icons.Outlined.Science, "Write unit tests", "Add pytest coverage for failover & slot resolution"),
        Triple(Icons.Outlined.Code, "Refactor selected file", "Clean up streaming SSE frame parsing safely"),
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().widthIn(max = 700.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.border, RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    ClaudeSparkleEmblem(size = 30.dp, tint = palette.accent)
                }
                Text(
                    text = "What are we building in $shortRepo?",
                    color = palette.textPrimary,
                    fontFamily = SourceSerifFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 23.sp,
                    textAlign = TextAlign.Center,
                )
                StudioPillBadge(
                    text = "/workspaces/$shortRepo",
                    textColor = palette.textSecondary,
                    backgroundColor = palette.surface,
                    borderColor = palette.border,
                    monospace = true,
                )
            }
        }
        item { Spacer(Modifier.height(6.dp)) }
        items(starters) { (icon, title, subtitle) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                    .clickable { onStarterClick(title) }
                    .padding(14.dp)
                    .testTag("starter_card_${title.take(12).lowercase().replace(" ", "_")}"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(palette.accentSubtle),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, contentDescription = null, tint = palette.accent, modifier = Modifier.size(18.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                    Text(subtitle, color = palette.textSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun UserMessageBubble(
    message: ChatMessage,
    onEditClick: () -> Unit,
    onFileClick: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surface)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (message.attachments.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                message.attachments.forEach { att ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.surfaceElevated)
                            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                            .clickable(enabled = att.type == AttachmentType.File) {
                                onFileClick(att.pathOrUri)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (att.type == AttachmentType.Image) {
                            AsyncImage(
                                model = att.pathOrUri,
                                contentDescription = att.label,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(20.dp).clip(RoundedCornerShape(4.dp)),
                            )
                        } else {
                            Icon(Icons.Outlined.Description, null, tint = palette.accent, modifier = Modifier.size(13.dp))
                        }
                        Text(
                            text = att.label,
                            color = palette.textPrimary,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                        )
                    }
                }
            }
        }

        Text(
            text = message.text,
            color = palette.textPrimary,
            fontSize = 14.5.sp,
            lineHeight = 21.sp,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            TextButton(
                onClick = onEditClick,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(28.dp),
            ) {
                Icon(Icons.Outlined.Edit, contentDescription = "Edit and resend", tint = palette.textTertiary, modifier = Modifier.size(13.dp))
                Spacer(Modifier.width(4.dp))
                Text("Edit & Resend", color = palette.textTertiary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AssistantMessageStreamItem(
    message: ChatMessage,
    onToggleThinking: () -> Unit,
    onToggleToolOutput: (String) -> Unit,
    onApproveTool: (toolCallId: String, alwaysAllow: Boolean) -> Unit,
    onRequestRejectTool: (ToolCallBlock) -> Unit,
    onRetry: () -> Unit,
    onApplyCodeToFile: (fileName: String?, code: String) -> Unit,
    onOpenFile: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // Claude Assistant Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ClaudeSparkleEmblem(size = 18.dp, tint = palette.accent)
            Text(
                text = "Claude",
                color = palette.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.5.sp,
            )
            if (message.isStreaming) {
                StatusDot(color = palette.accent, pulsing = true, size = 7.dp)
            }
        }

        // Collapsible Thinking / Extended Reasoning Accordion
        if (message.thinkingText.isNotBlank() || (!message.isThinkingComplete && message.isStreaming)) {
            val secLabel = String.format(Locale.US, "%.1fs", message.thinkingDurationMs / 1000.0)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(11.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(11.dp)),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onToggleThinking)
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                        .testTag("thinking_accordion_${message.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (!message.isThinkingComplete && message.isStreaming) {
                            StatusDot(color = palette.accent, pulsing = true, size = 7.dp)
                            Text(
                                text = "Thinking… ($secLabel)",
                                color = palette.accent,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        } else {
                            Icon(Icons.Outlined.Psychology, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Thought for $secLabel",
                                color = palette.textSecondary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                    }
                    Icon(
                        imageVector = if (message.isThinkingExpanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        contentDescription = "Toggle reasoning chain",
                        tint = palette.textTertiary,
                        modifier = Modifier.size(17.dp),
                    )
                }

                AnimatedVisibility(visible = message.isThinkingExpanded) {
                    Text(
                        text = message.thinkingText,
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        lineHeight = 19.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.codeBackground.copy(alpha = 0.6f))
                            .padding(12.dp),
                    )
                }
            }
        }

        // Interactive Tool-Use & Permission Cards
        message.toolCalls.forEach { tc ->
            ToolCallPermissionCard(
                toolCall = tc,
                onToggleOutput = { onToggleToolOutput(tc.id) },
                onApproveOnce = { onApproveTool(tc.id, false) },
                onAlwaysAllow = { onApproveTool(tc.id, true) },
                onReject = { onRequestRejectTool(tc) },
                onOpenFile = onOpenFile,
            )
        }

        // Rich Markdown & Syntax Highlighted Prose
        if (message.text.isNotBlank()) {
            MarkdownProseRenderer(
                markdown = message.text,
                onApplyCodeToFile = onApplyCodeToFile,
            )
        }

        // Response Action Footer
        if (!message.isStreaming) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(message.text))
                            copied = true
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp),
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                            contentDescription = "Copy response",
                            tint = if (copied) palette.success else palette.textTertiary,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(if (copied) "Copied" else "Copy", color = if (copied) palette.success else palette.textTertiary, fontSize = 11.5.sp)
                    }
                    TextButton(
                        onClick = onRetry,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp),
                    ) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Retry response", tint = palette.textTertiary, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Retry", color = palette.textTertiary, fontSize = 11.5.sp)
                    }
                }
                if (message.inputTokens > 0 || message.latencyMs > 0) {
                    val latencySec = String.format(Locale.US, "%.1fs", message.latencyMs / 1000.0)
                    Text(
                        text = "${message.inputTokens + message.outputTokens} tok • $latencySec",
                        color = palette.textTertiary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.5.sp,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ToolCallPermissionCard(
    toolCall: ToolCallBlock,
    onToggleOutput: () -> Unit,
    onApproveOnce: () -> Unit,
    onAlwaysAllow: () -> Unit,
    onReject: () -> Unit,
    onOpenFile: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val borderColor = when (toolCall.status) {
        ToolCallStatus.PendingApproval -> palette.warning.copy(alpha = 0.7f)
        ToolCallStatus.Running -> palette.info.copy(alpha = 0.6f)
        ToolCallStatus.Executed -> palette.success.copy(alpha = 0.4f)
        ToolCallStatus.Rejected -> palette.danger.copy(alpha = 0.55f)
    }
    val toolIcon = when (toolCall.toolType) {
        ToolType.ReadFile -> Icons.Outlined.Description
        ToolType.EditFile, ToolType.WriteFile -> Icons.Outlined.Edit
        ToolType.RunBash -> Icons.Outlined.Terminal
        ToolType.SearchGrep -> Icons.Outlined.Search
        ToolType.Glob -> Icons.Outlined.FolderOpen
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surface)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
            .testTag("tool_card_${toolCall.id}"),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(toolIcon, contentDescription = null, tint = palette.info, modifier = Modifier.size(16.dp))
                Column {
                    Text(toolCall.actionLabel, color = palette.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = toolCall.targetPathOrCommand,
                        color = palette.accent,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.5.sp,
                        modifier = Modifier.clickable(
                            enabled = toolCall.toolType == ToolType.ReadFile || toolCall.toolType == ToolType.EditFile,
                        ) { onOpenFile(toolCall.targetPathOrCommand) },
                    )
                }
            }

            when (toolCall.status) {
                ToolCallStatus.PendingApproval -> StudioPillBadge("Awaiting Approval", palette.warning, palette.warningBg, leadingDotColor = palette.warning, pulsingDot = true)
                ToolCallStatus.Running -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(13.dp), strokeWidth = 2.dp, color = palette.info)
                    Text("Running…", color = palette.info, fontSize = 11.sp)
                }
                ToolCallStatus.Executed -> StudioPillBadge("Executed", palette.success, palette.successBg, leadingDotColor = palette.success)
                ToolCallStatus.Rejected -> StudioPillBadge("Rejected", palette.danger, palette.dangerBg)
            }
        }

        if (toolCall.diffLines.isNotEmpty()) {
            UnifiedDiffBlock(lines = toolCall.diffLines)
        }

        if (toolCall.status == ToolCallStatus.PendingApproval) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Button(
                    onClick = onApproveOnce,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.success, contentColor = Color(0xFF111110)),
                    modifier = Modifier.height(34.dp).testTag("approve_once_${toolCall.id}"),
                ) {
                    Icon(Icons.Outlined.CheckCircle, null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Approve Once", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onAlwaysAllow,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.6f)),
                    modifier = Modifier.height(34.dp).testTag("always_allow_${toolCall.id}"),
                ) {
                    Text("Always Allow for Session", color = palette.accent, fontSize = 11.5.sp)
                }

                OutlinedButton(
                    onClick = onReject,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    border = BorderStroke(1.dp, palette.danger.copy(alpha = 0.55f)),
                    modifier = Modifier.height(34.dp).testTag("reject_tool_${toolCall.id}"),
                ) {
                    Icon(Icons.Outlined.Close, null, tint = palette.danger, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reject", color = palette.danger, fontSize = 11.5.sp)
                }
            }
        }

        if (toolCall.stdoutOutput.isNotBlank() && toolCall.status != ToolCallStatus.PendingApproval) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.codeBackground)
                    .clickable(onClick = onToggleOutput)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = if (toolCall.isOutputExpanded) "Hide output" else "Show output",
                        color = palette.textTertiary,
                        fontSize = 11.sp,
                    )
                    Icon(
                        imageVector = if (toolCall.isOutputExpanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        contentDescription = "Toggle tool output",
                        tint = palette.textTertiary,
                        modifier = Modifier.size(15.dp),
                    )
                }
                AnimatedVisibility(visible = toolCall.isOutputExpanded) {
                    Column(modifier = Modifier.padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = toolCall.stdoutOutput,
                            color = palette.textSecondary,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp,
                        )
                        if (!toolCall.rejectionFeedback.isNullOrBlank()) {
                            Text(
                                text = "Feedback: ${toolCall.rejectionFeedback}",
                                color = palette.danger,
                                fontSize = 11.5.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}
