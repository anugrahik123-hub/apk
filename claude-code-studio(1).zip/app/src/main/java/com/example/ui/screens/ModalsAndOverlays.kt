package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.BridgeUrlValidator
import com.example.data.DemoDataFactory
import com.example.model.AiModelOption
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.ChatSession
import com.example.model.CodespaceInfo
import com.example.model.EffortLevel
import com.example.model.PermissionMode
import com.example.model.StudioSettings
import com.example.model.WorkspaceTab
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun BridgeConfigurationDialog(
    codespace: CodespaceInfo,
    initialConfig: BridgeConfig,
    isTesting: Boolean,
    testResult: BridgeTestResult?,
    onDismiss: () -> Unit,
    onSave: (BridgeConfig) -> Unit,
    onTest: (BridgeConfig) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var wsUrl by remember(codespace.name, initialConfig.wsUrl) { mutableStateOf(initialConfig.wsUrl) }
    var fccUrl by remember(codespace.name, initialConfig.fccServerUrl) { mutableStateOf(initialConfig.fccServerUrl) }
    var secret by remember(codespace.name, initialConfig.bearerSecret) { mutableStateOf(initialConfig.bearerSecret) }

    val wsError = remember(wsUrl) { BridgeUrlValidator.validateWebSocketUrl(wsUrl) }
    val fccError = remember(fccUrl) { BridgeUrlValidator.validateHttpUrl(fccUrl) }
    val canSave = wsError == null && fccError == null

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Router,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(20.dp),
                    )
                    Column {
                        Text(
                            text = "Bridge & Port Configuration",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.5.sp,
                        )
                        Text(
                            text = codespace.name,
                            color = palette.textSecondary,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.5.sp,
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                }
            }

            HorizontalDivider(color = palette.border)

            Text(
                text = "Codespace Terminal / Claude Bridge WebSocket URL",
                color = palette.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
            )
            OutlinedTextField(
                value = wsUrl,
                onValueChange = { wsUrl = it },
                singleLine = true,
                isError = wsError != null,
                supportingText = wsError?.let { { Text(it, color = palette.danger, fontSize = 11.sp) } },
                modifier = Modifier.fillMaxWidth().testTag("bridge_ws_url_input"),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.5.sp,
                    color = palette.textPrimary,
                ),
                shape = RoundedCornerShape(10.dp),
                colors = studioFieldColors(),
            )

            Text(
                text = "fcc-server Forwarded Port URL (:8082)",
                color = palette.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
            )
            OutlinedTextField(
                value = fccUrl,
                onValueChange = { fccUrl = it },
                singleLine = true,
                isError = fccError != null,
                supportingText = fccError?.let { { Text(it, color = palette.danger, fontSize = 11.sp) } },
                modifier = Modifier.fillMaxWidth().testTag("bridge_fcc_url_input"),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.5.sp,
                    color = palette.textPrimary,
                ),
                shape = RoundedCornerShape(10.dp),
                colors = studioFieldColors(),
            )

            Text(
                text = "Optional Bridge Bearer Auth Secret",
                color = palette.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
            )
            OutlinedTextField(
                value = secret,
                onValueChange = { secret = it },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text("Leave blank if port is private via Codespaces auth", color = palette.textTertiary, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth().testTag("bridge_secret_input"),
                shape = RoundedCornerShape(10.dp),
                colors = studioFieldColors(),
            )

            if (testResult != null) {
                val bg = if (testResult.success) palette.successBg else palette.dangerBg
                val fg = if (testResult.success) palette.success else palette.danger
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(bg)
                        .border(1.dp, fg.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        testResult.wsLatencyMs?.let {
                            StudioPillBadge("WS ${it}ms", fg, palette.surface, monospace = true)
                        }
                        testResult.fccLatencyMs?.let {
                            StudioPillBadge("FCC ${it}ms", fg, palette.surface, monospace = true)
                        }
                    }
                    Text(
                        text = testResult.diagnostics,
                        color = fg,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        onTest(BridgeConfig(codespace.name, wsUrl.trim(), fccUrl.trim(), secret.trim()))
                    },
                    enabled = !isTesting && canSave,
                    modifier = Modifier.weight(1f).testTag("bridge_test_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.borderFocused),
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp, color = palette.accent)
                        Spacer(Modifier.width(6.dp))
                        Text("Testing…", color = palette.textPrimary, fontSize = 12.5.sp)
                    } else {
                        Icon(Icons.Outlined.NetworkCheck, contentDescription = null, tint = palette.accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Test Latency", color = palette.textPrimary, fontSize = 12.5.sp)
                    }
                }
                Button(
                    onClick = {
                        onSave(BridgeConfig(codespace.name, wsUrl.trim(), fccUrl.trim(), secret.trim()))
                        onDismiss()
                    },
                    enabled = canSave,
                    modifier = Modifier.weight(1f).testTag("bridge_save_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.accent,
                        contentColor = Color(0xFF191918),
                    ),
                ) {
                    Text("Save Bridge", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsModalDialog(
    settings: StudioSettings,
    isDemoMode: Boolean,
    githubUserLogin: String,
    availableModels: List<AiModelOption>,
    onUpdateSettings: (StudioSettings) -> Unit,
    onLogout: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current
    var activeTab by remember { mutableIntStateOf(0) }
    var copiedSnippet by remember { mutableStateOf(false) }

    val setupSnippet = remember {
        """# 1. Start fcc-server proxy & admin UI on port 8082
fcc-server --host 0.0.0.0 --port 8082 &

# 2. Launch the Claude Code Studio WebSocket bridge on port 8765
npx -y @claudecode-studio/codespace-bridge --port 8765 --cmd "fcc-claude"

# 3. In VS Code Ports tab, set ports 8082 & 8765 visibility as needed
#    and paste their forwarded URLs into Configure Bridge."""
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 640.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Outlined.Settings, contentDescription = null, tint = palette.accent, modifier = Modifier.size(20.dp))
                    Text(
                        text = "Workspace Settings",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Outlined.Close, contentDescription = "Close settings", tint = palette.textSecondary)
                }
            }

            // Tab pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.surfaceElevated)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                listOf("Appearance", "Defaults", "Bridge Setup").forEachIndexed { idx, label ->
                    val selected = activeTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) palette.surface else Color.Transparent)
                            .border(
                                width = if (selected) 1.dp else 0.dp,
                                color = if (selected) palette.borderFocused else Color.Transparent,
                                shape = RoundedCornerShape(8.dp),
                            )
                            .clickable { activeTab = idx }
                            .padding(vertical = 8.dp)
                            .testTag("settings_tab_$idx"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = label,
                            color = if (selected) palette.textPrimary else palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                when (activeTab) {
                    0 -> {
                        SettingsSwitchRow(
                            title = "Warm Anthropic Dark Mode",
                            subtitle = "Deep warm charcoal (#191918) vs Warm Cream light canvas",
                            checked = settings.darkMode,
                            onCheckedChange = { onUpdateSettings(settings.copy(darkMode = it)) },
                            testTag = "settings_dark_mode_switch",
                        )
                        SettingsSwitchRow(
                            title = "Editorial Serif Prose",
                            subtitle = "Use Source Serif 4 for Claude's prose responses instead of Inter",
                            checked = settings.useSerifProse,
                            onCheckedChange = { onUpdateSettings(settings.copy(useSerifProse = it)) },
                            testTag = "settings_serif_switch",
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text("Code & Terminal Font Size", color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                                Text(
                                    text = "${settings.codeFontSizeSp.toInt()} sp",
                                    color = palette.accent,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 12.5.sp,
                                )
                            }
                            Slider(
                                value = settings.codeFontSizeSp,
                                onValueChange = { onUpdateSettings(settings.copy(codeFontSizeSp = it)) },
                                valueRange = 10.5f..16f,
                                colors = SliderDefaults.colors(
                                    thumbColor = palette.accent,
                                    activeTrackColor = palette.accent,
                                    inactiveTrackColor = palette.border,
                                ),
                            )
                        }
                        HorizontalDivider(color = palette.border)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text(
                                    text = if (isDemoMode) "Interactive Demo Session" else "GitHub Account: @$githubUserLogin",
                                    color = palette.textPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                )
                                Text(
                                    text = if (isDemoMode) "Sign in with a GitHub PAT anytime" else "PAT stored securely in device DataStore",
                                    color = palette.textSecondary,
                                    fontSize = 11.5.sp,
                                )
                            }
                            OutlinedButton(
                                onClick = onLogout,
                                border = BorderStroke(1.dp, palette.danger.copy(alpha = 0.5f)),
                                modifier = Modifier.testTag("settings_logout_button"),
                            ) {
                                Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null, tint = palette.danger, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(5.dp))
                                Text(if (isDemoMode) "Exit Demo" else "Logout", color = palette.danger, fontSize = 12.sp)
                            }
                        }
                    }

                    1 -> {
                        Text("Default Model", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            availableModels.take(6).forEach { model ->
                                val selected = settings.defaultModelId == model.id
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) palette.accentSubtle else palette.surfaceElevated)
                                        .border(1.dp, if (selected) palette.accent else palette.border, RoundedCornerShape(8.dp))
                                        .clickable { onUpdateSettings(settings.copy(defaultModelId = model.id)) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                ) {
                                    Text(
                                        text = model.displayName,
                                        color = if (selected) palette.accent else palette.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    )
                                }
                            }
                        }

                        Text("Default Effort Level", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            EffortLevel.entries.forEach { level ->
                                val selected = settings.defaultEffort == level
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) palette.accentSubtle else palette.surfaceElevated)
                                        .border(1.dp, if (selected) palette.accent else palette.border, RoundedCornerShape(8.dp))
                                        .clickable { onUpdateSettings(settings.copy(defaultEffort = level)) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        text = level.label,
                                        color = if (selected) palette.accent else palette.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = if (selected || level == EffortLevel.Ultracode) FontWeight.SemiBold else FontWeight.Normal,
                                    )
                                }
                            }
                        }

                        Text("Default Permission Mode", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            PermissionMode.entries.forEach { mode ->
                                val selected = settings.defaultPermissionMode == mode
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) palette.accentSubtle else palette.surfaceElevated)
                                        .border(1.dp, if (selected) palette.accent else palette.border, RoundedCornerShape(10.dp))
                                        .clickable { onUpdateSettings(settings.copy(defaultPermissionMode = mode)) }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(mode.label, color = palette.textPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
                                        Text(mode.description, color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                                    }
                                    if (selected) {
                                        Icon(Icons.Outlined.Check, contentDescription = null, tint = palette.accent, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        Text(
                            text = "3-Step Codespace Bridge Setup",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                        )
                        Text(
                            text = "Run this one-command snippet inside your GitHub Codespace terminal to expose both the fcc-server Admin UI (:8082) and the live WebSocket PTY/Claude bridge (:8765).",
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            lineHeight = 18.sp,
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.codeBackground)
                                .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = setupSnippet,
                                color = palette.textPrimary,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.5.sp,
                                lineHeight = 17.sp,
                            )
                            OutlinedButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(setupSnippet))
                                    copiedSnippet = true
                                },
                                border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.5f)),
                                modifier = Modifier.testTag("copy_bridge_snippet_button"),
                            ) {
                                Icon(
                                    imageVector = if (copiedSnippet) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                                    contentDescription = null,
                                    tint = if (copiedSnippet) palette.success else palette.accent,
                                    modifier = Modifier.size(15.dp),
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (copiedSnippet) "Copied Setup Snippet" else "Copy One-Command Snippet",
                                    color = if (copiedSnippet) palette.success else palette.accent,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    val palette = LocalStudioPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = palette.textSecondary, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF191918),
                checkedTrackColor = palette.accent,
                uncheckedThumbColor = palette.textSecondary,
                uncheckedTrackColor = palette.surfaceElevated,
            ),
        )
    }
}

@Composable
fun CommandPaletteDialog(
    codespaces: List<CodespaceInfo>,
    models: List<AiModelOption>,
    sessions: List<ChatSession>,
    onSelectTab: (WorkspaceTab) -> Unit,
    onSelectCodespace: (CodespaceInfo) -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onSelectSession: (String) -> Unit,
    onNewSession: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    var query by remember { mutableStateOf("") }

    data class PaletteAction(
        val id: String,
        val category: String,
        val title: String,
        val subtitle: String,
        val onRun: () -> Unit,
    )

    val allActions = remember(codespaces, models, sessions) {
        buildList {
            add(PaletteAction("new-sess", "Session", "New Claude Code Session", "Cmd+Shift+N", onNewSession))
            WorkspaceTab.entries.forEach { tab ->
                add(PaletteAction("tab-${tab.name}", "View", "Switch to ${tab.label}", "Workspace tab") { onSelectTab(tab) })
            }
            EffortLevel.entries.forEach { effort ->
                add(PaletteAction("eff-${effort.name}", "Effort", "Set Effort: ${effort.label}", "Silent /effort ${effort.cliValue}") { onSelectEffort(effort) })
            }
            models.forEach { m ->
                add(PaletteAction("mod-${m.id}", "Model", "Switch Model: ${m.displayName}", "${m.provider} • ${m.contextWindowK}k") { onSelectModel(m.id) })
            }
            codespaces.forEach { cs ->
                add(PaletteAction("cs-${cs.id}", "Codespace", "Connect: ${cs.displayName}", cs.repoFullName) { onSelectCodespace(cs) })
            }
            sessions.take(6).forEach { s ->
                add(PaletteAction("s-${s.id}", "Session", s.title, "${s.group} • ${s.messages.size} messages") { onSelectSession(s.id) })
            }
            add(PaletteAction("settings", "System", "Open Workspace Settings", "Theme, PAT & Bridge guide", onOpenSettings))
        }
    }

    val filtered = remember(query, allActions) {
        if (query.isBlank()) allActions
        else allActions.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true) ||
                it.subtitle.contains(query, ignoreCase = true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp)),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Jump to Codespace, model, effort, session, or view…", color = palette.textTertiary, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = palette.accent, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close command palette", tint = palette.textSecondary)
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .testTag("command_palette_input"),
                shape = RoundedCornerShape(12.dp),
                colors = studioFieldColors(),
            )
            HorizontalDivider(color = palette.border)
            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
            ) {
                items(filtered, key = { it.id }) { action ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                action.onRun()
                                onDismiss()
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            when (action.category) {
                                "Model" -> ClaudeSparkleEmblem(size = 16.dp, tint = palette.accent)
                                "Codespace" -> Icon(Icons.Outlined.Dns, contentDescription = null, tint = palette.info, modifier = Modifier.size(16.dp))
                                "View" -> Icon(Icons.Outlined.Terminal, contentDescription = null, tint = palette.success, modifier = Modifier.size(16.dp))
                                "Effort" -> Icon(Icons.Outlined.Bolt, contentDescription = null, tint = palette.warning, modifier = Modifier.size(16.dp))
                                else -> Icon(Icons.Outlined.Add, contentDescription = null, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                            }
                            Column {
                                Text(action.title, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text(action.subtitle, color = palette.textTertiary, fontSize = 11.5.sp)
                            }
                        }
                        StudioPillBadge(
                            text = action.category,
                            textColor = palette.textSecondary,
                            backgroundColor = palette.surfaceElevated,
                        )
                    }
                    HorizontalDivider(color = palette.border.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
private fun studioFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = LocalStudioPalette.current.accent,
    unfocusedBorderColor = LocalStudioPalette.current.border,
    focusedContainerColor = LocalStudioPalette.current.surfaceElevated,
    unfocusedContainerColor = LocalStudioPalette.current.surfaceElevated,
    focusedTextColor = LocalStudioPalette.current.textPrimary,
    unfocusedTextColor = LocalStudioPalette.current.textPrimary,
    cursorColor = LocalStudioPalette.current.accent,
)
