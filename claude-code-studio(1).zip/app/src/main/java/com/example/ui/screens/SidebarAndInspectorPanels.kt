package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AgentTask
import com.example.model.AgentTaskStatus
import com.example.model.ChatSession
import com.example.model.FileDiffEntry
import com.example.model.FileNode
import com.example.model.InspectorTab
import com.example.model.SidebarTab
import com.example.ui.components.SideBySideDiffBlock
import com.example.ui.components.StatusDot
import com.example.ui.components.StudioPillBadge
import com.example.ui.components.UnifiedDiffBlock
import com.example.ui.components.highlightCodeSyntax
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.LocalStudioTypographyConfig

@Composable
fun LeftSidebarPanel(
    sidebarTab: SidebarTab,
    sessions: List<ChatSession>,
    activeSessionId: String,
    sessionSearchQuery: String,
    repoFiles: List<FileNode>,
    selectedFilePath: String,
    showCloseButton: Boolean,
    onSelectTab: (SidebarTab) -> Unit,
    onNewSession: () -> Unit,
    onSelectSession: (String) -> Unit,
    onRenameSession: (String, String) -> Unit,
    onTogglePinSession: (String) -> Unit,
    onDeleteSession: (String) -> Unit,
    onSearchChange: (String) -> Unit,
    onOpenFile: (String) -> Unit,
    onAddFileToContext: (FileNode) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    var renamingSession by remember { mutableStateOf<ChatSession?>(null) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(palette.sidebar)
            .border(width = 1.dp, color = palette.border),
    ) {
        // Sidebar Tab Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(palette.surface)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                SidebarTab.entries.forEach { tab ->
                    val selected = sidebarTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (selected) palette.surfaceElevated else Color.Transparent)
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 6.dp)
                            .testTag("sidebar_tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = tab.label,
                            color = if (selected) palette.textPrimary else palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        )
                    }
                }
            }
            if (showCloseButton) {
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Close sidebar",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }

        HorizontalDivider(color = palette.border)

        when (sidebarTab) {
            SidebarTab.Sessions -> {
                Column(
                    modifier = Modifier.fillMaxSize().padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onNewSession,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("sidebar_new_session_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color(0xFF191918),
                        ),
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("New Session", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }

                    OutlinedTextField(
                        value = sessionSearchQuery,
                        onValueChange = onSearchChange,
                        singleLine = true,
                        placeholder = { Text("Search sessions…", color = palette.textTertiary, fontSize = 12.5.sp) },
                        leadingIcon = {
                            Icon(Icons.Outlined.Search, contentDescription = null, tint = palette.textTertiary, modifier = Modifier.size(16.dp))
                        },
                        modifier = Modifier.fillMaxWidth().testTag("session_search_input"),
                        shape = RoundedCornerShape(10.dp),
                        textStyle = TextStyle(fontSize = 12.5.sp, color = palette.textPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accent,
                            unfocusedBorderColor = palette.border,
                            focusedContainerColor = palette.surface,
                            unfocusedContainerColor = palette.surface,
                            cursorColor = palette.accent,
                        ),
                    )

                    val filtered = remember(sessions, sessionSearchQuery) {
                        val q = sessionSearchQuery.trim()
                        if (q.isEmpty()) sessions
                        else sessions.filter {
                            it.title.contains(q, ignoreCase = true) || it.modelId.contains(q, ignoreCase = true)
                        }
                    }

                    val pinned = filtered.filter { it.isPinned }
                    val grouped = filtered.filterNot { it.isPinned }.groupBy { it.group }
                    val groupOrder = listOf("Today", "Yesterday", "Previous 7 Days")

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (pinned.isNotEmpty()) {
                            item {
                                SidebarSectionLabel("PINNED")
                            }
                            items(pinned, key = { "pin-${it.id}" }) { session ->
                                SessionRowCard(
                                    session = session,
                                    isActive = session.id == activeSessionId,
                                    onClick = { onSelectSession(session.id) },
                                    onRename = { renamingSession = session },
                                    onTogglePin = { onTogglePinSession(session.id) },
                                    onDelete = { onDeleteSession(session.id) },
                                )
                            }
                        }

                        groupOrder.forEach { groupName ->
                            val itemsInGroup = grouped[groupName].orEmpty()
                            if (itemsInGroup.isNotEmpty()) {
                                item {
                                    SidebarSectionLabel(groupName.uppercase())
                                }
                                items(itemsInGroup, key = { it.id }) { session ->
                                    SessionRowCard(
                                        session = session,
                                        isActive = session.id == activeSessionId,
                                        onClick = { onSelectSession(session.id) },
                                        onRename = { renamingSession = session },
                                        onTogglePin = { onTogglePinSession(session.id) },
                                        onDelete = { onDeleteSession(session.id) },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            SidebarTab.Files -> {
                val expandedDirs = remember {
                    mutableStateMapOf(
                        "src" to true,
                        "src/fcc_server" to true,
                        "src/cli" to true,
                        "tests" to true,
                    )
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp, horizontal = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    item {
                        Text(
                            text = "CODESPACE EXPLORER",
                            color = palette.textTertiary,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.7.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }
                    item {
                        FileTreeColumn(
                            nodes = repoFiles,
                            depth = 0,
                            expandedDirs = expandedDirs,
                            selectedFilePath = selectedFilePath,
                            onOpenFile = onOpenFile,
                            onAddToContext = onAddFileToContext,
                        )
                    }
                }
            }
        }
    }

    renamingSession?.let { target ->
        var draft by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renamingSession = null },
            containerColor = palette.surface,
            title = { Text("Rename Session", color = palette.textPrimary, fontSize = 16.sp) },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onRenameSession(target.id, draft)
                    renamingSession = null
                }) {
                    Text("Save", color = palette.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { renamingSession = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            },
        )
    }
}

@Composable
private fun SidebarSectionLabel(label: String) {
    Text(
        text = label,
        color = LocalStudioPalette.current.textTertiary,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.7.sp,
        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp, start = 4.dp),
    )
}

@Composable
private fun SessionRowCard(
    session: ChatSession,
    isActive: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    var menuOpen by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isActive) palette.surfaceElevated else Color.Transparent)
            .border(
                width = if (isActive) 1.dp else 0.dp,
                color = if (isActive) palette.borderFocused else Color.Transparent,
                shape = RoundedCornerShape(10.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = session.title,
                color = if (isActive) palette.textPrimary else palette.textSecondary,
                fontSize = 12.5.sp,
                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StudioPillBadge(
                    text = session.modelId.substringAfterLast("/").take(16),
                    textColor = palette.textSecondary,
                    backgroundColor = palette.surface,
                    monospace = true,
                )
                Text(
                    text = "${session.messages.size} msgs",
                    color = palette.textTertiary,
                    fontSize = 10.5.sp,
                )
            }
        }

        Box {
            IconButton(
                onClick = { menuOpen = true },
                modifier = Modifier.size(30.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.MoreVert,
                    contentDescription = "Session actions",
                    tint = palette.textTertiary,
                    modifier = Modifier.size(16.dp),
                )
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
                modifier = Modifier.background(palette.surfaceElevated),
            ) {
                DropdownMenuItem(
                    text = { Text("Rename", color = palette.textPrimary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Outlined.Edit, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp)) },
                    onClick = {
                        menuOpen = false
                        onRename()
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (session.isPinned) "Unpin" else "Pin", color = palette.textPrimary, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Outlined.PushPin, null, tint = palette.accent, modifier = Modifier.size(16.dp)) },
                    onClick = {
                        menuOpen = false
                        onTogglePin()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Delete", color = palette.danger, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null, tint = palette.danger, modifier = Modifier.size(16.dp)) },
                    onClick = {
                        menuOpen = false
                        onDelete()
                    },
                )
            }
        }
    }
}

@Composable
private fun FileTreeColumn(
    nodes: List<FileNode>,
    depth: Int,
    expandedDirs: MutableMap<String, Boolean>,
    selectedFilePath: String,
    onOpenFile: (String) -> Unit,
    onAddToContext: (FileNode) -> Unit,
) {
    val palette = LocalStudioPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        nodes.forEach { node ->
            val isExpanded = expandedDirs[node.path] == true
            val isSelected = !node.isDirectory && node.path == selectedFilePath
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) palette.accentSubtle else Color.Transparent)
                    .clickable {
                        if (node.isDirectory) {
                            expandedDirs[node.path] = !isExpanded
                        } else {
                            onOpenFile(node.path)
                        }
                    }
                    .padding(start = (8 + depth * 14).dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = when {
                        node.isDirectory && isExpanded -> Icons.Outlined.FolderOpen
                        node.isDirectory -> Icons.Outlined.Folder
                        node.name.endsWith(".py") || node.name.endsWith(".ts") || node.name.endsWith(".kt") -> Icons.Outlined.Code
                        else -> Icons.Outlined.Description
                    },
                    contentDescription = null,
                    tint = if (node.isDirectory) palette.accent else palette.textSecondary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    text = node.name,
                    color = if (isSelected) palette.accent else palette.textPrimary,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (!node.gitStatus.isNullOrBlank()) {
                    val statusColor = when (node.gitStatus) {
                        "M" -> palette.warning
                        "A" -> palette.success
                        else -> palette.info
                    }
                    Text(
                        text = node.gitStatus,
                        color = statusColor,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
                if (!node.isDirectory) {
                    IconButton(
                        onClick = { onAddToContext(node) },
                        modifier = Modifier.size(28.dp).testTag("add_context_${node.name}"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AddCircleOutline,
                            contentDescription = "Add ${node.name} to context",
                            tint = palette.textTertiary,
                            modifier = Modifier.size(15.dp),
                        )
                    }
                }
            }
            if (node.isDirectory) {
                AnimatedVisibility(visible = isExpanded) {
                    FileTreeColumn(
                        nodes = node.children,
                        depth = depth + 1,
                        expandedDirs = expandedDirs,
                        selectedFilePath = selectedFilePath,
                        onOpenFile = onOpenFile,
                        onAddToContext = onAddToContext,
                    )
                }
            }
        }
    }
}

@Composable
fun RightInspectorPanel(
    inspectorTab: InspectorTab,
    fileChanges: List<FileDiffEntry>,
    selectedFile: FileNode?,
    tasks: List<AgentTask>,
    onSelectTab: (InspectorTab) -> Unit,
    onStageAll: () -> Unit,
    onRevertFile: (String) -> Unit,
    onSaveQuickEdit: (path: String, newContent: String) -> Unit,
    onAttachFile: (FileNode) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val typoConfig = LocalStudioTypographyConfig.current
    var sideBySideDiff by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(palette.sidebar)
            .border(width = 1.dp, color = palette.border),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(palette.surface)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                InspectorTab.entries.forEach { tab ->
                    val selected = inspectorTab == tab
                    val badgeCount = when (tab) {
                        InspectorTab.Changes -> fileChanges.size
                        InspectorTab.Plan -> tasks.size
                        InspectorTab.FileViewer -> 0
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (selected) palette.surfaceElevated else Color.Transparent)
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 6.dp)
                            .testTag("inspector_tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = if (badgeCount > 0) "${tab.label} ($badgeCount)" else tab.label,
                            color = if (selected) palette.textPrimary else palette.textSecondary,
                            fontSize = 11.5.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1,
                        )
                    }
                }
            }
            IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Outlined.Close, contentDescription = "Close inspector", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
            }
        }

        HorizontalDivider(color = palette.border)

        when (inspectorTab) {
            InspectorTab.Changes -> {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(palette.surface)
                                .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                                .padding(2.dp),
                        ) {
                            listOf(false to "Unified", true to "Split").forEach { (isSplit, label) ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (sideBySideDiff == isSplit) palette.accentSubtle else Color.Transparent)
                                        .clickable { sideBySideDiff = isSplit }
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                ) {
                                    Text(
                                        text = label,
                                        color = if (sideBySideDiff == isSplit) palette.accent else palette.textSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                    )
                                }
                            }
                        }

                        if (fileChanges.isNotEmpty()) {
                            OutlinedButton(
                                onClick = onStageAll,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                border = BorderStroke(1.dp, palette.success.copy(alpha = 0.5f)),
                                modifier = Modifier.height(30.dp).testTag("stage_all_changes_button"),
                            ) {
                                Text("Stage All", color = palette.success, fontSize = 11.sp)
                            }
                        }
                    }

                    if (fileChanges.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(20.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = "No modified files in this session yet. Approve an Edit File tool card to inspect live diffs here.",
                                color = palette.textTertiary,
                                fontSize = 12.5.sp,
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(fileChanges, key = { it.path }) { diff ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(palette.surface)
                                        .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = diff.path,
                                                color = palette.textPrimary,
                                                fontFamily = JetBrainsMonoFontFamily,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Medium,
                                            )
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("+${diff.addedCount}", color = palette.success, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp)
                                                Text("-${diff.removedCount}", color = palette.danger, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp)
                                                if (diff.isStaged) {
                                                    StudioPillBadge("Staged", palette.success, palette.successBg)
                                                }
                                            }
                                        }
                                        IconButton(
                                            onClick = { onRevertFile(diff.path) },
                                            modifier = Modifier.size(32.dp),
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Undo,
                                                contentDescription = "Revert ${diff.path}",
                                                tint = palette.danger,
                                                modifier = Modifier.size(16.dp),
                                            )
                                        }
                                    }
                                    if (sideBySideDiff) {
                                        SideBySideDiffBlock(diff.diffLines)
                                    } else {
                                        UnifiedDiffBlock(diff.diffLines)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            InspectorTab.FileViewer -> {
                if (selectedFile == null) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Select a file from the Explorer to inspect it.", color = palette.textTertiary, fontSize = 12.5.sp)
                    }
                } else {
                    var isEditing by remember(selectedFile.path) { mutableStateOf(false) }
                    var draftContent by remember(selectedFile.path, selectedFile.content) {
                        mutableStateOf(selectedFile.content.orEmpty())
                    }

                    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = selectedFile.path,
                                color = palette.textPrimary,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { onAttachFile(selectedFile) },
                                    modifier = Modifier.size(32.dp),
                                ) {
                                    Icon(Icons.Outlined.AddCircleOutline, contentDescription = "Attach to prompt", tint = palette.accent, modifier = Modifier.size(17.dp))
                                }
                                IconButton(
                                    onClick = {
                                        if (isEditing) {
                                            onSaveQuickEdit(selectedFile.path, draftContent)
                                            isEditing = false
                                        } else {
                                            isEditing = true
                                        }
                                    },
                                    modifier = Modifier.size(32.dp),
                                ) {
                                    Icon(
                                        imageVector = if (isEditing) Icons.Outlined.Save else Icons.Outlined.Edit,
                                        contentDescription = if (isEditing) "Save file" else "Quick edit file",
                                        tint = if (isEditing) palette.success else palette.textSecondary,
                                        modifier = Modifier.size(17.dp),
                                    )
                                }
                            }
                        }

                        if (isEditing) {
                            OutlinedTextField(
                                value = draftContent,
                                onValueChange = { draftContent = it },
                                modifier = Modifier.fillMaxSize(),
                                textStyle = TextStyle(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = (typoConfig.codeFontSizeSp - 0.5f).sp,
                                    lineHeight = (typoConfig.codeFontSizeSp * 1.45f).sp,
                                    color = palette.textPrimary,
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = palette.accent,
                                    unfocusedBorderColor = palette.border,
                                    focusedContainerColor = palette.codeBackground,
                                    unfocusedContainerColor = palette.codeBackground,
                                ),
                            )
                        } else {
                            val highlighted = remember(selectedFile.content, palette.isDark) {
                                highlightCodeSyntax(
                                    code = selectedFile.content.orEmpty(),
                                    keywordColor = palette.accent,
                                    stringColor = palette.success,
                                    commentColor = palette.textTertiary,
                                    numberColor = palette.info,
                                    defaultColor = palette.textPrimary,
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.codeBackground)
                                    .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                                    .verticalScroll(rememberScrollState())
                                    .horizontalScroll(rememberScrollState())
                                    .padding(10.dp),
                            ) {
                                Text(
                                    text = highlighted,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = (typoConfig.codeFontSizeSp - 0.5f).sp,
                                    lineHeight = (typoConfig.codeFontSizeSp * 1.5f).sp,
                                )
                            }
                        }
                    }
                }
            }

            InspectorTab.Plan -> {
                if (tasks.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Claude's live multi-step execution plan will appear here once a session starts.",
                            color = palette.textTertiary,
                            fontSize = 12.5.sp,
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(tasks, key = { it.id }) { task ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.surface)
                                    .border(
                                        1.dp,
                                        if (task.status == AgentTaskStatus.InProgress) palette.accent.copy(alpha = 0.6f) else palette.border,
                                        RoundedCornerShape(10.dp),
                                    )
                                    .padding(11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                when (task.status) {
                                    AgentTaskStatus.Completed -> Icon(
                                        Icons.Outlined.CheckCircle,
                                        contentDescription = "Completed",
                                        tint = palette.success,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    AgentTaskStatus.InProgress -> StatusDot(
                                        color = palette.accent,
                                        pulsing = true,
                                        size = 10.dp,
                                    )
                                    AgentTaskStatus.Pending -> Icon(
                                        Icons.Outlined.RadioButtonUnchecked,
                                        contentDescription = "Pending",
                                        tint = palette.textTertiary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                                Column {
                                    Text(
                                        text = task.title,
                                        color = if (task.status == AgentTaskStatus.Pending) palette.textSecondary else palette.textPrimary,
                                        fontSize = 12.5.sp,
                                        fontWeight = if (task.status == AgentTaskStatus.InProgress) FontWeight.SemiBold else FontWeight.Normal,
                                    )
                                    Text(
                                        text = when (task.status) {
                                            AgentTaskStatus.Completed -> "Completed"
                                            AgentTaskStatus.InProgress -> "In Progress"
                                            AgentTaskStatus.Pending -> "Pending"
                                        },
                                        color = when (task.status) {
                                            AgentTaskStatus.Completed -> palette.success
                                            AgentTaskStatus.InProgress -> palette.accent
                                            AgentTaskStatus.Pending -> palette.textTertiary
                                        },
                                        fontSize = 11.sp,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
