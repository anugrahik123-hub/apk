package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Queue
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AiModelOption
import com.example.model.AttachmentType
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.EffortLevel
import com.example.model.FileNode
import com.example.model.ModelProviderGroup
import com.example.model.PermissionMode
import com.example.ui.components.EffortSignalBars
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun ClaudeComposerBar(
    availableModels: List<AiModelOption>,
    selectedModelId: String,
    selectedEffort: EffortLevel,
    extendedThinkingEnabled: Boolean,
    permissionMode: PermissionMode,
    contextBreakdown: ContextBreakdown,
    pendingAttachments: List<ContextAttachment>,
    flatRepoFiles: List<FileNode>,
    isStreaming: Boolean,
    queuedPrompt: String?,
    onSendPrompt: (String) -> Unit,
    onStopGeneration: () -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onToggleExtendedThinking: (Boolean) -> Unit,
    onSelectPermissionMode: (PermissionMode) -> Unit,
    onCompactContext: () -> Unit,
    onClearConversation: () -> Unit,
    onExportTranscript: () -> Unit,
    onAttachFile: (FileNode) -> Unit,
    onAttachImage: (uriString: String, label: String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    var promptText by remember { mutableStateOf("") }
    var showModelDialog by remember { mutableStateOf(false) }
    var showEffortMenu by remember { mutableStateOf(false) }
    var showPermissionMenu by remember { mutableStateOf(false) }
    var showContextPopover by remember { mutableStateOf(false) }
    var showAttachMenu by remember { mutableStateOf(false) }
    var showFilePickerDialog by remember { mutableStateOf(false) }

    // Zero-permission Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            onAttachImage(uri.toString(), "Screenshot.png")
        }
    }

    // Inline @ File Mention Autocomplete
    val mentionQuery = remember(promptText) {
        val lastAt = promptText.lastIndexOf('@')
        if (lastAt >= 0) {
            val after = promptText.substring(lastAt + 1)
            if (!after.contains(" ") && !after.contains("\n")) after else null
        } else {
            null
        }
    }
    val mentionMatches = remember(mentionQuery, flatRepoFiles) {
        if (mentionQuery == null) emptyList()
        else flatRepoFiles.filter {
            it.path.contains(mentionQuery, ignoreCase = true) || it.name.contains(mentionQuery, ignoreCase = true)
        }.take(5)
    }

    val activeModel = availableModels.firstOrNull { it.id == selectedModelId } ?: availableModels.first()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 860.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            // Inline @ File Mention Autocomplete Popup
            AnimatedVisibility(visible = mentionMatches.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.surfaceElevated)
                        .border(1.dp, palette.borderFocused, RoundedCornerShape(12.dp))
                        .padding(vertical = 4.dp),
                ) {
                    Text(
                        text = "Mention file in Codespace",
                        color = palette.textTertiary,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    )
                    mentionMatches.forEach { file ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val lastAt = promptText.lastIndexOf('@')
                                    if (lastAt >= 0) {
                                        promptText = promptText.substring(0, lastAt) + "@${file.path} "
                                    }
                                    onAttachFile(file)
                                }
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Outlined.Description, null, tint = palette.accent, modifier = Modifier.size(15.dp))
                            Text(file.path, color = palette.textPrimary, fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (!queuedPrompt.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.accentSubtle)
                        .border(1.dp, palette.accent.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(Icons.Outlined.Queue, null, tint = palette.accent, modifier = Modifier.size(14.dp))
                    Text(
                        text = "Queued next: $queuedPrompt",
                        color = palette.accent,
                        fontSize = 11.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            // Floating Elevated Composer Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // Context Chips Row
                if (pendingAttachments.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        pendingAttachments.forEach { att ->
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.surfaceElevated)
                                    .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                Icon(
                                    imageVector = if (att.type == AttachmentType.Image) Icons.Outlined.Image else Icons.Outlined.Description,
                                    contentDescription = null,
                                    tint = palette.accent,
                                    modifier = Modifier.size(13.dp),
                                )
                                Text(
                                    text = att.label,
                                    color = palette.textPrimary,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                )
                                Icon(
                                    imageVector = Icons.Outlined.Close,
                                    contentDescription = "Remove ${att.label}",
                                    tint = palette.textTertiary,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable { onRemoveAttachment(att.id) },
                                )
                            }
                        }
                    }
                }

                // Multi-line Text Input + Send/Stop Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BasicTextField(
                        value = promptText,
                        onValueChange = { promptText = it },
                        cursorBrush = SolidColor(palette.accent),
                        textStyle = TextStyle(
                            color = palette.textPrimary,
                            fontSize = 14.5.sp,
                            lineHeight = 20.sp,
                        ),
                        maxLines = 5,
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 38.dp)
                            .padding(vertical = 4.dp)
                            .testTag("prompt_composer_input"),
                        decorationBox = { inner ->
                            if (promptText.isEmpty()) {
                                Text(
                                    text = if (isStreaming) "Type to queue your next message…" else "Ask Claude to edit, debug, or explain… (type @ for files)",
                                    color = palette.textTertiary,
                                    fontSize = 14.sp,
                                )
                            }
                            inner()
                        },
                    )

                    if (isStreaming && promptText.isBlank()) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.dangerBg)
                                .border(1.dp, palette.danger.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                .clickable(onClick = onStopGeneration)
                                .testTag("stop_generation_button"),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.Stop, contentDescription = "Stop generation", tint = palette.danger, modifier = Modifier.size(18.dp))
                        }
                    } else {
                        val canSubmit = promptText.isNotBlank() || pendingAttachments.isNotEmpty()
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (canSubmit) palette.accent else palette.surfaceElevated)
                                .clickable(enabled = canSubmit) {
                                    onSendPrompt(promptText)
                                    promptText = ""
                                }
                                .testTag("send_prompt_button"),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = if (isStreaming) Icons.Outlined.Queue else Icons.AutoMirrored.Outlined.Send,
                                contentDescription = if (isStreaming) "Queue message" else "Send message",
                                tint = if (canSubmit) Color(0xFF191918) else palette.textTertiary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }

                // Bottom Visual Control Toolbar (Zero Slash Commands Needed!)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    // 1. Attachment (+) Menu
                    Box {
                        ComposerControlPill(
                            onClick = { showAttachMenu = true },
                            testTag = "composer_attach_button",
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = "Attach file or image", tint = palette.textSecondary, modifier = Modifier.size(15.dp))
                        }
                        DropdownMenu(
                            expanded = showAttachMenu,
                            onDismissRequest = { showAttachMenu = false },
                            modifier = Modifier.background(palette.surfaceElevated),
                        ) {
                            DropdownMenuItem(
                                text = { Text("Attach Codespace File", color = palette.textPrimary, fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Outlined.Description, null, tint = palette.accent, modifier = Modifier.size(17.dp)) },
                                onClick = {
                                    showAttachMenu = false
                                    showFilePickerDialog = true
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Upload Screenshot / Image", color = palette.textPrimary, fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Outlined.Image, null, tint = palette.info, modifier = Modifier.size(17.dp)) },
                                onClick = {
                                    showAttachMenu = false
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                    )
                                },
                            )
                        }
                    }

                    // 2. Model Selector Pill (Claude + FCC Custom Models)
                    ComposerControlPill(
                        onClick = { showModelDialog = true },
                        highlighted = true,
                        testTag = "composer_model_selector",
                    ) {
                        Text(
                            text = activeModel.displayName,
                            color = palette.textPrimary,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                        )
                        Icon(Icons.Outlined.ExpandMore, null, tint = palette.textSecondary, modifier = Modifier.size(14.dp))
                    }

                    // 3. Effort Level + Extended Thinking Pill
                    Box {
                        ComposerControlPill(
                            onClick = { showEffortMenu = true },
                            highlighted = selectedEffort == EffortLevel.Ultracode,
                            testTag = "composer_effort_selector",
                        ) {
                            EffortSignalBars(level = selectedEffort.bars)
                            Text(
                                text = selectedEffort.label,
                                color = if (selectedEffort == EffortLevel.Ultracode) palette.accent else palette.textPrimary,
                                fontSize = 11.5.sp,
                                fontWeight = if (selectedEffort == EffortLevel.Ultracode) FontWeight.SemiBold else FontWeight.Medium,
                            )
                        }
                        DropdownMenu(
                            expanded = showEffortMenu,
                            onDismissRequest = { showEffortMenu = false },
                            modifier = Modifier.background(palette.surfaceElevated).width(248.dp),
                        ) {
                            EffortLevel.entries.forEach { level ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            EffortSignalBars(level = level.bars)
                                            Column {
                                                Text(
                                                    text = if (level == EffortLevel.Ultracode) "Ultracode" else "${level.label} Effort",
                                                    color = if (selectedEffort == level || level == EffortLevel.Ultracode) palette.accent else palette.textPrimary,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = if (selectedEffort == level || level == EffortLevel.Ultracode) FontWeight.SemiBold else FontWeight.Normal,
                                                )
                                                if (!level.subtitle.isNullOrBlank()) {
                                                    Text(
                                                        text = level.subtitle,
                                                        color = palette.textSecondary,
                                                        fontSize = 10.5.sp,
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    trailingIcon = if (selectedEffort == level) {
                                        { Icon(Icons.Outlined.Check, null, tint = palette.accent, modifier = Modifier.size(15.dp)) }
                                    } else null,
                                    onClick = {
                                        onSelectEffort(level)
                                        showEffortMenu = false
                                    },
                                )
                            }
                            HorizontalDivider(color = palette.border)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text("Extended Thinking", color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Switch(
                                    checked = extendedThinkingEnabled,
                                    onCheckedChange = onToggleExtendedThinking,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFF191918),
                                        checkedTrackColor = palette.accent,
                                    ),
                                )
                            }
                        }
                    }

                    // 4. Permission Mode Pill
                    Box {
                        val permColor = when (permissionMode) {
                            PermissionMode.AskBeforeEdits -> palette.warning
                            PermissionMode.AutoAcceptEdits -> palette.info
                            PermissionMode.PlanMode -> palette.textSecondary
                            PermissionMode.FullAuto -> palette.danger
                        }
                        val permIcon = when (permissionMode) {
                            PermissionMode.AskBeforeEdits -> Icons.Outlined.Security
                            PermissionMode.AutoAcceptEdits -> Icons.Outlined.Check
                            PermissionMode.PlanMode -> Icons.Outlined.Visibility
                            PermissionMode.FullAuto -> Icons.Outlined.Bolt
                        }
                        ComposerControlPill(
                            onClick = { showPermissionMenu = true },
                            testTag = "composer_permission_selector",
                        ) {
                            Icon(permIcon, null, tint = permColor, modifier = Modifier.size(13.dp))
                            Text(
                                text = permissionMode.shortLabel,
                                color = permColor,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        DropdownMenu(
                            expanded = showPermissionMenu,
                            onDismissRequest = { showPermissionMenu = false },
                            modifier = Modifier.background(palette.surfaceElevated).width(260.dp),
                        ) {
                            PermissionMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = mode.label,
                                                color = if (permissionMode == mode) palette.accent else palette.textPrimary,
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                            Text(mode.description, color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.sp)
                                        }
                                    },
                                    onClick = {
                                        onSelectPermissionMode(mode)
                                        showPermissionMenu = false
                                    },
                                )
                            }
                        }
                    }

                    // 5. Interactive Context Window Ring & Popover (Replaces /compact & /clear)
                    ComposerControlPill(
                        onClick = { showContextPopover = true },
                        testTag = "composer_context_meter",
                    ) {
                        ContextRingIndicator(
                            fraction = contextBreakdown.usageFraction,
                            ringColor = if (contextBreakdown.usagePercent > 75) palette.warning else palette.accent,
                            trackColor = palette.borderFocused,
                        )
                        val maxLabel = if (contextBreakdown.maxTokens >= 1_000_000) {
                            "${contextBreakdown.maxTokens / 1_000_000}M"
                        } else {
                            "${contextBreakdown.maxTokens / 1000}k"
                        }
                        Text(
                            text = "${contextBreakdown.totalTokens / 1000}k/$maxLabel • ${contextBreakdown.usagePercent}%",
                            color = palette.textSecondary,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                        )
                    }
                }
            }
        }
    }

    // Grouped Model Selector Modal
    if (showModelDialog) {
        ModelPickerModal(
            models = availableModels,
            selectedModelId = selectedModelId,
            onSelect = {
                onSelectModel(it)
                showModelDialog = false
            },
            onDismiss = { showModelDialog = false },
        )
    }

    // Context Window Popover Dialog (Compact / Clear / Export Transcript)
    if (showContextPopover) {
        ContextWindowDialog(
            breakdown = contextBreakdown,
            onCompact = {
                onCompactContext()
                showContextPopover = false
            },
            onClear = {
                onClearConversation()
                showContextPopover = false
            },
            onExport = {
                onExportTranscript()
                showContextPopover = false
            },
            onDismiss = { showContextPopover = false },
        )
    }

    // Attach Codespace File Picker Dialog
    if (showFilePickerDialog) {
        Dialog(onDismissRequest = { showFilePickerDialog = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.borderFocused, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Attach File from Codespace", color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(flatRepoFiles, key = { it.path }) { file ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onAttachFile(file)
                                    showFilePickerDialog = false
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Outlined.Description, null, tint = palette.accent, modifier = Modifier.size(16.dp))
                            Text(file.path, color = palette.textPrimary, fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComposerControlPill(
    onClick: () -> Unit,
    highlighted: Boolean = false,
    testTag: String,
    content: @Composable () -> Unit,
) {
    val palette = LocalStudioPalette.current
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(if (highlighted) palette.surfaceElevated else palette.canvas.copy(alpha = 0.65f))
            .border(1.dp, if (highlighted) palette.borderFocused else palette.border, RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        content()
    }
}

@Composable
private fun ContextRingIndicator(
    fraction: Float,
    ringColor: Color,
    trackColor: Color,
) {
    Canvas(modifier = Modifier.size(14.dp)) {
        val stroke = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
        drawArc(
            color = trackColor,
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            style = stroke,
        )
        drawArc(
            color = ringColor,
            startAngle = -90f,
            sweepAngle = (fraction.coerceIn(0.03f, 1f)) * 360f,
            useCenter = false,
            style = stroke,
        )
    }
}

@Composable
private fun ModelPickerModal(
    models: List<AiModelOption>,
    selectedModelId: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val grouped = remember(models) { models.groupBy { it.group } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 540.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text("Select Model", color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.5.sp)
                    Text("Silently dispatches /model to fcc-claude", color = palette.textSecondary, fontSize = 11.5.sp)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                }
            }
            HorizontalDivider(color = palette.border)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ModelProviderGroup.entries.forEach { group ->
                    val itemsInGroup = grouped[group].orEmpty()
                    if (itemsInGroup.isNotEmpty()) {
                        item {
                            Text(
                                text = group.label.uppercase(),
                                color = palette.textTertiary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.7.sp,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                        items(itemsInGroup, key = { it.id }) { model ->
                            val selected = model.id == selectedModelId
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (selected) palette.accentSubtle else palette.surfaceElevated)
                                    .border(1.dp, if (selected) palette.accent else palette.border, RoundedCornerShape(11.dp))
                                    .clickable { onSelect(model.id) }
                                    .padding(11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = model.displayName,
                                        color = if (selected) palette.accent else palette.textPrimary,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        model.tags.forEach { tag ->
                                            StudioPillBadge(
                                                text = tag,
                                                textColor = if (tag.contains("Free")) palette.success else palette.textSecondary,
                                                backgroundColor = if (tag.contains("Free")) palette.successBg else palette.surface,
                                            )
                                        }
                                        val ctxLabel = if (model.contextWindowK >= 1000) {
                                            "${model.contextWindowK / 1000}M ctx"
                                        } else {
                                            "${model.contextWindowK}k ctx"
                                        }
                                        StudioPillBadge(
                                            text = ctxLabel,
                                            textColor = palette.textTertiary,
                                            backgroundColor = palette.surface,
                                            monospace = true,
                                        )
                                    }
                                }
                                if (selected) {
                                    Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = palette.accent, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContextWindowDialog(
    breakdown: ContextBreakdown,
    onCompact: () -> Unit,
    onClear: () -> Unit,
    onExport: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surface)
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Context Window & Controls", color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                StudioPillBadge("${breakdown.usagePercent}% used", palette.accent, palette.accentSubtle, monospace = true)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.surfaceElevated)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ContextBreakdownRow("System & Tools", breakdown.systemTokens)
                ContextBreakdownRow("Attached Files", breakdown.filesTokens)
                ContextBreakdownRow("Conversation Messages", breakdown.messagesTokens)
                ContextBreakdownRow("Tool Outputs", breakdown.toolOutputTokens)
                HorizontalDivider(color = palette.border)
                ContextBreakdownRow("Total Active Context", breakdown.totalTokens, bold = true)
            }

            OutlinedButton(
                onClick = onCompact,
                modifier = Modifier.fillMaxWidth().testTag("compact_context_button"),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, palette.accent.copy(alpha = 0.6f)),
            ) {
                Icon(Icons.Outlined.Compress, null, tint = palette.accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Compact Context (Summarize Older Turns)", color = palette.accent, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = onExport,
                    modifier = Modifier.weight(1f).testTag("export_transcript_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.borderFocused),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                ) {
                    Icon(Icons.Outlined.Download, null, tint = palette.textPrimary, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Export .md", color = palette.textPrimary, fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onClear,
                    modifier = Modifier.weight(1f).testTag("clear_conversation_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.danger.copy(alpha = 0.55f)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                ) {
                    Icon(Icons.Outlined.DeleteOutline, null, tint = palette.danger, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Clear Chat", color = palette.danger, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ContextBreakdownRow(label: String, tokens: Int, bold: Boolean = false) {
    val palette = LocalStudioPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = label,
            color = if (bold) palette.textPrimary else palette.textSecondary,
            fontSize = 12.sp,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        )
        Text(
            text = String.format("%,d tok", tokens),
            color = if (bold) palette.accent else palette.textPrimary,
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.5.sp,
            fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal,
        )
    }
}
