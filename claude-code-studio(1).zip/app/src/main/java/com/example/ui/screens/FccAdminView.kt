package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.BridgeUrlValidator
import com.example.model.AiModelOption
import com.example.model.FccModelSlots
import com.example.model.FccProviderConfig
import com.example.model.FccRequestLog
import com.example.model.FccServerStatus
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FccAdminView(
    status: FccServerStatus,
    fccServerUrl: String,
    showLiveEmbed: Boolean,
    isDemoMode: Boolean,
    providers: List<FccProviderConfig>,
    slots: FccModelSlots,
    logs: List<FccRequestLog>,
    availableModels: List<AiModelOption>,
    onStartServer: () -> Unit,
    onRestartServer: () -> Unit,
    onStopServer: () -> Unit,
    onToggleShowLiveEmbed: (Boolean) -> Unit,
    onEditPortUrl: () -> Unit,
    onToggleProvider: (String) -> Unit,
    onUpdateSlot: (slot: String, modelId: String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var frameReloadCounter by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas),
    ) {
        // Top Control Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.surface)
                .border(1.dp, palette.border)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Outlined.Dns, contentDescription = null, tint = palette.accent, modifier = Modifier.size(19.dp))
                    Text(
                        text = "fcc-server Admin & Router",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.5.sp,
                    )
                    val (statusColor, statusBg, pulsing) = when (status) {
                        FccServerStatus.Running -> Triple(palette.success, palette.successBg, false)
                        FccServerStatus.Starting -> Triple(palette.warning, palette.warningBg, true)
                        FccServerStatus.Stopped -> Triple(palette.danger, palette.dangerBg, false)
                    }
                    StudioPillBadge(
                        text = status.label,
                        textColor = statusColor,
                        backgroundColor = statusBg,
                        leadingDotColor = statusColor,
                        pulsingDot = pulsing,
                        monospace = true,
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (status == FccServerStatus.Stopped) {
                    Button(
                        onClick = onStartServer,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.success, contentColor = Color(0xFF111110)),
                        modifier = Modifier.height(34.dp).testTag("fcc_start_button"),
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Start fcc-server", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    OutlinedButton(
                        onClick = onRestartServer,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, palette.borderFocused),
                        modifier = Modifier.height(34.dp).testTag("fcc_restart_button"),
                    ) {
                        Icon(Icons.Outlined.RestartAlt, null, tint = palette.accent, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Restart", color = palette.textPrimary, fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = onStopServer,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, palette.danger.copy(alpha = 0.45f)),
                        modifier = Modifier.height(34.dp).testTag("fcc_stop_button"),
                    ) {
                        Icon(Icons.Outlined.Stop, null, tint = palette.danger, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Stop", color = palette.danger, fontSize = 12.sp)
                    }
                }

                OutlinedButton(
                    onClick = { frameReloadCounter++ },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.height(34.dp),
                ) {
                    Icon(Icons.Outlined.Refresh, null, tint = palette.textSecondary, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Refresh", color = palette.textSecondary, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onEditPortUrl,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.height(34.dp).testTag("fcc_edit_url_button"),
                ) {
                    Icon(Icons.Outlined.Edit, null, tint = palette.textSecondary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Port URL", color = palette.textSecondary, fontSize = 12.sp)
                }

                // Segmented mode toggle: Native Quick-Config vs Live Embedded WebView
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.surfaceElevated)
                        .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                        .padding(2.dp),
                ) {
                    listOf(false to "Quick-Config", true to "Live Admin UI").forEach { (embed, label) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (showLiveEmbed == embed) palette.accentSubtle else Color.Transparent)
                                .clickable { onToggleShowLiveEmbed(embed) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("fcc_mode_${if (embed) "embed" else "native"}"),
                        ) {
                            Text(
                                text = label,
                                color = if (showLiveEmbed == embed) palette.accent else palette.textSecondary,
                                fontSize = 11.5.sp,
                                fontWeight = if (showLiveEmbed == embed) FontWeight.SemiBold else FontWeight.Medium,
                            )
                        }
                    }
                }
            }
        }

        if (showLiveEmbed) {
            FccLiveEmbeddedWebView(
                status = status,
                fccServerUrl = fccServerUrl,
                isDemoMode = isDemoMode,
                reloadTrigger = frameReloadCounter,
                onStartServer = onStartServer,
                onSwitchToNative = { onToggleShowLiveEmbed(false) },
            )
        } else {
            FccNativeQuickConfigContent(
                providers = providers,
                slots = slots,
                logs = logs,
                availableModels = availableModels,
                onToggleProvider = onToggleProvider,
                onUpdateSlot = onUpdateSlot,
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun FccLiveEmbeddedWebView(
    status: FccServerStatus,
    fccServerUrl: String,
    isDemoMode: Boolean,
    reloadTrigger: Int,
    onStartServer: () -> Unit,
    onSwitchToNative: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    var webError by remember(fccServerUrl, reloadTrigger) { mutableStateOf<String?>(null) }
    val urlValidationError = remember(fccServerUrl) { BridgeUrlValidator.validateHttpUrl(fccServerUrl) }

    Box(modifier = Modifier.fillMaxSize()) {
        if (status == FccServerStatus.Stopped) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = palette.textTertiary, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text("fcc-server is currently stopped", color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Launch fcc-server inside your Codespace terminal to render the live Admin UI here.",
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onStartServer,
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = Color(0xFF191918)),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Start fcc-server Now", fontWeight = FontWeight.SemiBold)
                }
            }
        } else if (isDemoMode || urlValidationError != null || webError != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = if (isDemoMode) "Live Admin Frame (Simulated in Demo Mode)" else "Unable to reach forwarded fcc-server frame",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                    )
                    Text(
                        text = when {
                            isDemoMode -> "Target URL: $fccServerUrl. In Live Mode with a connected Codespace, the official fcc-server dashboard renders directly inside this in-app WebView."
                            urlValidationError != null -> urlValidationError
                            else -> "The embedded frame reported: $webError. If GitHub Codespaces blocks third-party session cookies on port 8082, set port 8082 visibility to Public or pass your Bridge Bearer secret:"
                        },
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        lineHeight = 18.sp,
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.codeBackground)
                            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                    ) {
                        Text(
                            text = "gh codespace ports visibility 8082:public -c \$CODESPACE_NAME",
                            color = palette.accent,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.5.sp,
                        )
                    }
                    Button(
                        onClick = onSwitchToNative,
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = Color(0xFF191918)),
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        Text("Open Native Quick-Config Panel", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
        } else {
            val allowedHost = remember(fccServerUrl) { Uri.parse(fccServerUrl).host }
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = false
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                val reqUri = request?.url ?: return true
                                val scheme = reqUri.scheme?.lowercase()
                                if (scheme != "https" && scheme != "http") return true
                                // Keep navigation strictly inside the configured fcc-server host
                                return reqUri.host != allowedHost
                            }

                            override fun onReceivedError(
                                view: WebView?,
                                request: WebResourceRequest?,
                                error: WebResourceError?,
                            ) {
                                if (request?.isForMainFrame == true) {
                                    webError = error?.description?.toString() ?: "Connection error"
                                }
                            }
                        }
                        loadUrl(fccServerUrl)
                    }
                },
                update = { webView ->
                    if (webView.url != fccServerUrl || reloadTrigger > 0) {
                        webView.loadUrl(fccServerUrl)
                    }
                },
            )
        }
    }
}

@Composable
private fun FccNativeQuickConfigContent(
    providers: List<FccProviderConfig>,
    slots: FccModelSlots,
    logs: List<FccRequestLog>,
    availableModels: List<AiModelOption>,
    onToggleProvider: (String) -> Unit,
    onUpdateSlot: (slot: String, modelId: String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val customModelIds = remember(availableModels) {
        availableModels.map { it.id }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Model Slot Router Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "Active Model Slot Mapping",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                )
                Text(
                    text = "Map Claude Code's Fable 5.2, Opus, Sonnet, and Haiku slots to any free or custom provider routed by fcc-server.",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                )
                SlotSelectorRow("Fable 5.2 Slot", slots.fableModelId, customModelIds) { onUpdateSlot("fable", it) }
                SlotSelectorRow("Opus Slot", slots.opusModelId, customModelIds) { onUpdateSlot("opus", it) }
                SlotSelectorRow("Sonnet Slot", slots.sonnetModelId, customModelIds) { onUpdateSlot("sonnet", it) }
                SlotSelectorRow("Haiku Slot", slots.haikuModelId, customModelIds) { onUpdateSlot("haiku", it) }
            }
        }

        // Providers Section
        item {
            Text(
                text = "Configured Upstream Providers",
                color = palette.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
            )
        }
        items(providers, key = { it.id }) { provider ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(provider.name, color = palette.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.5.sp)
                        StudioPillBadge(
                            text = if (provider.apiKeyConfigured) "API Key Ready" else "Key Missing",
                            textColor = if (provider.apiKeyConfigured) palette.success else palette.warning,
                            backgroundColor = if (provider.apiKeyConfigured) palette.successBg else palette.warningBg,
                        )
                    }
                    Text(
                        text = provider.endpoint,
                        color = palette.textTertiary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                    )
                    Text(
                        text = "Models: ${provider.models.joinToString(", ")}",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp,
                    )
                }
                Switch(
                    checked = provider.enabled,
                    onCheckedChange = { onToggleProvider(provider.id) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF191918),
                        checkedTrackColor = palette.accent,
                    ),
                )
            }
        }

        // Live Request Logs Section
        item {
            Text(
                text = "Live Proxy Request Logs",
                color = palette.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
            )
        }
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                    .horizontalScroll(rememberScrollState()),
            ) {
                logs.forEachIndexed { idx, log ->
                    if (idx > 0) HorizontalDivider(color = palette.border)
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(log.timestamp, color = palette.textTertiary, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp)
                        StudioPillBadge(log.slot, palette.accent, palette.accentSubtle, monospace = true)
                        Text(log.targetModel, color = palette.textPrimary, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.5.sp)
                        StudioPillBadge("${log.statusCode}", palette.success, palette.successBg, monospace = true)
                        Text("${log.latencyMs} ms", color = palette.textSecondary, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp)
                        if (log.tokens > 0) {
                            Text("${log.tokens} tok", color = palette.textTertiary, fontFamily = JetBrainsMonoFontFamily, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SlotSelectorRow(
    slotLabel: String,
    currentModelId: String,
    options: List<String>,
    onSelect: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(slotLabel, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Box {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(palette.surfaceElevated)
                    .border(1.dp, palette.borderFocused, RoundedCornerShape(9.dp))
                    .clickable { expanded = true }
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = currentModelId,
                    color = palette.accent,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.5.sp,
                )
                Icon(Icons.Outlined.ExpandMore, contentDescription = null, tint = palette.textSecondary, modifier = Modifier.size(16.dp))
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(palette.surfaceElevated),
            ) {
                options.forEach { modelId ->
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = modelId,
                                color = if (modelId == currentModelId) palette.accent else palette.textPrimary,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 12.sp,
                            )
                        },
                        onClick = {
                            expanded = false
                            onSelect(modelId)
                        },
                    )
                }
            }
        }
    }
}
