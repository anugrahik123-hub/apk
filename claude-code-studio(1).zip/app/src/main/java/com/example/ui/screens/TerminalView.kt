package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AnsiColorRole
import com.example.model.TerminalTabSession
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun IntegratedTerminalView(
    tabs: List<TerminalTabSession>,
    activeTabId: String,
    fontSizeSp: Float,
    isDrawerMode: Boolean,
    onSelectTab: (String) -> Unit,
    onAddTab: () -> Unit,
    onCloseTab: (String) -> Unit,
    onRunCommand: (String) -> Unit,
    onQuickAction: (command: String, preferFccTab: Boolean) -> Unit,
    onSendSigInt: () -> Unit,
    onClear: () -> Unit,
    onAdjustFontSize: (Float) -> Unit,
    onClickFilePath: (String) -> Unit,
    onCloseDrawer: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current
    val activeTab = tabs.firstOrNull { it.id == activeTabId } ?: tabs.first()
    var inputCommand by remember(activeTab.id) { mutableStateOf("") }
    var historyCursor by remember(activeTab.id, activeTab.commandHistory.size) {
        mutableIntStateOf(activeTab.commandHistory.size)
    }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val displayedLines = remember(activeTab.lines, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) activeTab.lines
        else activeTab.lines.filter { line ->
            line.segments.any { it.text.contains(q, ignoreCase = true) }
        }
    }

    LaunchedEffect(displayedLines.size) {
        if (displayedLines.isNotEmpty()) {
            listState.animateScrollToItem(displayedLines.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.terminalBackground),
    ) {
        // Multi-tab bar + controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A1A18))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                tabs.forEach { tab ->
                    val selected = tab.id == activeTab.id
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (selected) Color(0xFF2A2927) else Color.Transparent)
                            .border(
                                width = if (selected) 1.dp else 0.dp,
                                color = if (selected) Color(0xFF474540) else Color.Transparent,
                                shape = RoundedCornerShape(7.dp),
                            )
                            .clickable { onSelectTab(tab.id) }
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Terminal,
                            contentDescription = null,
                            tint = if (selected) palette.accent else Color(0xFF9E9B93),
                            modifier = Modifier.size(13.dp),
                        )
                        Text(
                            text = tab.title,
                            color = if (selected) Color(0xFFECEAE4) else Color(0xFF9E9B93),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.5.sp,
                        )
                        if (tabs.size > 1) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Close ${tab.title}",
                                tint = Color(0xFF6F6D66),
                                modifier = Modifier
                                    .size(13.dp)
                                    .clickable { onCloseTab(tab.id) },
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onAddTab,
                    modifier = Modifier.size(28.dp).testTag("terminal_new_tab_button"),
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "New terminal tab", tint = Color(0xFF9E9B93), modifier = Modifier.size(16.dp))
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { showSearch = !showSearch }, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Outlined.Search, contentDescription = "Search terminal", tint = if (showSearch) palette.accent else Color(0xFF9E9B93), modifier = Modifier.size(16.dp))
                }
                Text(
                    text = "A-",
                    color = Color(0xFF9E9B93),
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clickable { onAdjustFontSize(-1f) }
                        .padding(horizontal = 5.dp, vertical = 4.dp),
                )
                Text(
                    text = "A+",
                    color = Color(0xFF9E9B93),
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clickable { onAdjustFontSize(1f) }
                        .padding(horizontal = 5.dp, vertical = 4.dp),
                )
                IconButton(
                    onClick = {
                        val allText = activeTab.lines.joinToString("\n") { l -> l.segments.joinToString("") { it.text } }
                        clipboard.setText(AnnotatedString(allText))
                    },
                    modifier = Modifier.size(30.dp),
                ) {
                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy terminal output", tint = Color(0xFF9E9B93), modifier = Modifier.size(15.dp))
                }
                IconButton(onClick = onClear, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Outlined.DeleteSweep, contentDescription = "Clear terminal", tint = Color(0xFF9E9B93), modifier = Modifier.size(16.dp))
                }
                if (isDrawerMode && onCloseDrawer != null) {
                    IconButton(onClick = onCloseDrawer, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close terminal drawer", tint = Color(0xFF9E9B93), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // One-Click free-claude-code Quick-Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161614))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            TerminalQuickChip("▶ Run fcc-server", palette.accent) { onQuickAction("fcc-server", true) }
            TerminalQuickChip("▶ Run fcc-claude", palette.accent) { onQuickAction("fcc-claude", false) }
            TerminalQuickChip("↺ fcc-claude --continue", Color(0xFF60A5FA)) { onQuickAction("fcc-claude --continue", false) }
            TerminalQuickChip("git status", Color(0xFF4ADE80)) { onQuickAction("git status", false) }
            TerminalQuickChip("⏹ Ctrl+C", Color(0xFFFBBF24)) { onSendSigInt() }
            TerminalQuickChip("⌫ Clear", Color(0xFF9E9B93)) { onClear() }
        }

        AnimatedVisibility(visible = showSearch) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E1E1C))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(Icons.Outlined.Search, null, tint = Color(0xFF9E9B93), modifier = Modifier.size(15.dp))
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    singleLine = true,
                    cursorBrush = SolidColor(palette.accent),
                    textStyle = TextStyle(color = Color(0xFFECEAE4), fontFamily = JetBrainsMonoFontFamily, fontSize = 12.sp),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        if (searchQuery.isEmpty()) {
                            Text("Filter terminal output…", color = Color(0xFF6F6D66), fontSize = 12.sp)
                        }
                        inner()
                    },
                )
                if (searchQuery.isNotEmpty()) {
                    Icon(
                        Icons.Outlined.Close,
                        contentDescription = "Clear search",
                        tint = Color(0xFF9E9B93),
                        modifier = Modifier.size(16.dp).clickable { searchQuery = "" },
                    )
                }
            }
        }

        HorizontalDivider(color = Color(0xFF2D2C28))

        // Terminal Scrollable Output
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(displayedLines, key = { it.id }) { line ->
                val annotated = remember(line, fontSizeSp) {
                    buildAnnotatedString {
                        line.segments.forEach { seg ->
                            val segColor = when (seg.colorRole) {
                                AnsiColorRole.Default -> Color(0xFFECEAE4)
                                AnsiColorRole.Accent -> Color(0xFFD97757)
                                AnsiColorRole.Green -> Color(0xFF4ADE80)
                                AnsiColorRole.Red -> Color(0xFFF87171)
                                AnsiColorRole.Amber -> Color(0xFFFBBF24)
                                AnsiColorRole.Blue -> Color(0xFF60A5FA)
                                AnsiColorRole.Muted -> Color(0xFF9E9B93)
                                AnsiColorRole.Bold -> Color(0xFFFFFFFF)
                            }
                            if (seg.clickableFilePath != null) {
                                pushStringAnnotation(tag = "FILE_PATH", annotation = seg.clickableFilePath)
                                withStyle(
                                    SpanStyle(
                                        color = segColor,
                                        textDecoration = TextDecoration.Underline,
                                    ),
                                ) {
                                    append(seg.text)
                                }
                                pop()
                            } else {
                                withStyle(
                                    SpanStyle(
                                        color = segColor,
                                        fontWeight = if (seg.colorRole == AnsiColorRole.Bold) FontWeight.Bold else FontWeight.Normal,
                                    ),
                                ) {
                                    append(seg.text)
                                }
                            }
                        }
                    }
                }

                @Suppress("DEPRECATION")
                ClickableText(
                    text = annotated,
                    style = TextStyle(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = fontSizeSp.sp,
                        lineHeight = (fontSizeSp * 1.45f).sp,
                    ),
                    onClick = { offset ->
                        annotated.getStringAnnotations(tag = "FILE_PATH", start = offset, end = offset)
                            .firstOrNull()?.let { ann ->
                                onClickFilePath(ann.item)
                            }
                    },
                )
            }
        }

        HorizontalDivider(color = Color(0xFF2D2C28))

        // Interactive Prompt Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF171715))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = "$",
                color = palette.accent,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
            )
            BasicTextField(
                value = inputCommand,
                onValueChange = { inputCommand = it },
                singleLine = true,
                cursorBrush = SolidColor(palette.accent),
                textStyle = TextStyle(
                    color = Color(0xFFECEAE4),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = fontSizeSp.sp,
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputCommand.isNotBlank()) {
                            onRunCommand(inputCommand)
                            inputCommand = ""
                        }
                    },
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                decorationBox = { inner ->
                    if (inputCommand.isEmpty()) {
                        Text(
                            text = "Type a command (help, ls, git status, fcc-server, fcc-claude)…",
                            color = Color(0xFF6F6D66),
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = (fontSizeSp - 0.5f).sp,
                            maxLines = 1,
                        )
                    }
                    inner()
                },
            )
            IconButton(
                onClick = {
                    val hist = activeTab.commandHistory
                    if (hist.isNotEmpty() && historyCursor > 0) {
                        historyCursor -= 1
                        inputCommand = hist[historyCursor]
                    }
                },
                modifier = Modifier.size(30.dp),
            ) {
                Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Previous command", tint = Color(0xFF9E9B93), modifier = Modifier.size(18.dp))
            }
            IconButton(
                onClick = {
                    val hist = activeTab.commandHistory
                    if (historyCursor < hist.lastIndex) {
                        historyCursor += 1
                        inputCommand = hist[historyCursor]
                    } else {
                        historyCursor = hist.size
                        inputCommand = ""
                    }
                },
                modifier = Modifier.size(30.dp),
            ) {
                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Next command", tint = Color(0xFF9E9B93), modifier = Modifier.size(18.dp))
            }
            IconButton(
                onClick = {
                    if (inputCommand.isNotBlank()) {
                        onRunCommand(inputCommand)
                        inputCommand = ""
                    }
                },
                modifier = Modifier.size(32.dp).testTag("terminal_send_button"),
            ) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Run command", tint = palette.accent, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun TerminalQuickChip(
    label: String,
    accent: Color,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0xFF22211F))
            .border(1.dp, Color(0xFF353430), RoundedCornerShape(7.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 4.dp),
    ) {
        Text(
            text = label,
            color = accent,
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}
