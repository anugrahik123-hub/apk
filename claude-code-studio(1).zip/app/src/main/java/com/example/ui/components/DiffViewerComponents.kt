package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DiffLine
import com.example.model.DiffLineType
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.LocalStudioTypographyConfig

@Composable
fun UnifiedDiffBlock(
    lines: List<DiffLine>,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val codeSize = LocalStudioTypographyConfig.current.codeFontSizeSp
    val hScroll = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(palette.codeBackground)
            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
            .horizontalScroll(hScroll)
            .padding(vertical = 4.dp),
    ) {
        lines.forEach { line ->
            val bg = when (line.type) {
                DiffLineType.Added -> palette.successBg
                DiffLineType.Removed -> palette.dangerBg
                DiffLineType.Context -> Color.Transparent
            }
            val fg = when (line.type) {
                DiffLineType.Added -> palette.success
                DiffLineType.Removed -> palette.danger
                DiffLineType.Context -> palette.textSecondary
            }
            val prefix = when (line.type) {
                DiffLineType.Added -> "+"
                DiffLineType.Removed -> "-"
                DiffLineType.Context -> " "
            }
            Row(
                modifier = Modifier
                    .background(bg)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            ) {
                Text(
                    text = line.oldLine?.toString()?.padStart(3) ?: "   ",
                    color = palette.textTertiary,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = (codeSize - 1f).sp,
                    modifier = Modifier.width(28.dp),
                )
                Text(
                    text = line.newLine?.toString()?.padStart(3) ?: "   ",
                    color = palette.textTertiary,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = (codeSize - 1f).sp,
                    modifier = Modifier.width(28.dp),
                )
                Text(
                    text = "$prefix ${line.text}",
                    color = fg,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = if (line.type == DiffLineType.Context) FontWeight.Normal else FontWeight.Medium,
                    fontSize = (codeSize - 0.5f).sp,
                    softWrap = false,
                )
            }
        }
    }
}

@Composable
fun SideBySideDiffBlock(
    lines: List<DiffLine>,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val codeSize = LocalStudioTypographyConfig.current.codeFontSizeSp
    val hScroll = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(palette.codeBackground)
            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
            .horizontalScroll(hScroll)
            .padding(vertical = 4.dp),
    ) {
        lines.forEach { line ->
            val leftBg = if (line.type == DiffLineType.Removed) palette.dangerBg else Color.Transparent
            val rightBg = if (line.type == DiffLineType.Added) palette.successBg else Color.Transparent
            val leftText = if (line.type == DiffLineType.Added) "" else line.text
            val rightText = if (line.type == DiffLineType.Removed) "" else line.text

            Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
                Row(
                    modifier = Modifier
                        .width(240.dp)
                        .background(leftBg)
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    Text(
                        text = line.oldLine?.toString()?.padStart(3) ?: "   ",
                        color = palette.textTertiary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = (codeSize - 1.5f).sp,
                        modifier = Modifier.width(26.dp),
                    )
                    Text(
                        text = leftText,
                        color = if (line.type == DiffLineType.Removed) palette.danger else palette.textSecondary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = (codeSize - 1f).sp,
                        softWrap = false,
                    )
                }
                Row(
                    modifier = Modifier
                        .width(240.dp)
                        .background(rightBg)
                        .padding(horizontal = 6.dp, vertical = 1.dp),
                ) {
                    Text(
                        text = line.newLine?.toString()?.padStart(3) ?: "   ",
                        color = palette.textTertiary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = (codeSize - 1.5f).sp,
                        modifier = Modifier.width(26.dp),
                    )
                    Text(
                        text = rightText,
                        color = if (line.type == DiffLineType.Added) palette.success else palette.textSecondary,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = (codeSize - 1f).sp,
                        softWrap = false,
                    )
                }
            }
        }
    }
}
