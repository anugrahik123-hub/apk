package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.CloudQueue
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.PowerSettingsNew
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BridgeConfig
import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.SourceSerifFontFamily

@Composable
fun CodespacesDashboardScreen(
    codespaces: List<CodespaceInfo>,
    bridgeConfigs: Map<String, BridgeConfig>,
    isDemoMode: Boolean,
    githubUserLogin: String,
    isLoading: Boolean,
    errorMessage: String?,
    isDarkMode: Boolean,
    onRefresh: () -> Unit,
    onConnect: (CodespaceInfo) -> Unit,
    onStart: (CodespaceInfo) -> Unit,
    onStop: (CodespaceInfo) -> Unit,
    onConfigureBridge: (CodespaceInfo) -> Unit,
    onToggleTheme: () -> Unit,
    onOpenSettings: () -> Unit,
    onLogout: () -> Unit,
) {
    val palette = LocalStudioPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Top Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.sidebar)
                .border(width = 1.dp, color = palette.border)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ClaudeSparkleEmblem(size = 22.dp, tint = palette.accent)
                Column {
                    Text(
                        text = "Claude Code Studio",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                    )
                    Text(
                        text = if (isDemoMode) "Interactive Demo Mode" else "@$githubUserLogin • Live GitHub API",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp,
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("dashboard_refresh_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = "Refresh Codespaces",
                        tint = palette.textSecondary,
                    )
                }
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier.testTag("dashboard_theme_button"),
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                        contentDescription = "Toggle theme",
                        tint = palette.textSecondary,
                    )
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("dashboard_settings_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Open Settings",
                        tint = palette.textSecondary,
                    )
                }
                IconButton(
                    onClick = onLogout,
                    modifier = Modifier.testTag("dashboard_logout_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Logout,
                        contentDescription = "Sign out",
                        tint = palette.textSecondary,
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Your GitHub Codespaces",
                        color = palette.textPrimary,
                        fontFamily = SourceSerifFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 24.sp,
                    )
                    Text(
                        text = "Select a Codespace to launch the unified Claude Code GUI, fcc-server Admin UI, and integrated terminal.",
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                    )
                }
            }

            if (!errorMessage.isNullOrBlank()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.dangerBg)
                            .border(1.dp, palette.danger.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = errorMessage,
                            color = palette.danger,
                            fontSize = 12.5.sp,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedButton(onClick = onRefresh) {
                            Text("Retry", color = palette.danger, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            CircularProgressIndicator(color = palette.accent, strokeWidth = 2.5.dp)
                            Text(
                                text = "Fetching Codespaces from api.github.com…",
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            } else if (codespaces.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(palette.surface)
                            .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CloudQueue,
                            contentDescription = null,
                            tint = palette.textTertiary,
                            modifier = Modifier.size(36.dp),
                        )
                        Text(
                            text = "No Codespaces found on this account",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                        )
                        Text(
                            text = "Verify your PAT has the 'codespace' scope, or create a Codespace for alishahryar1/free-claude-code.",
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                        )
                    }
                }
            } else {
                items(codespaces, key = { it.id }) { cs ->
                    CodespaceCard(
                        codespace = cs,
                        bridgeConfig = bridgeConfigs[cs.name],
                        onConnect = { onConnect(cs) },
                        onStart = { onStart(cs) },
                        onStop = { onStop(cs) },
                        onConfigureBridge = { onConfigureBridge(cs) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CodespaceCard(
    codespace: CodespaceInfo,
    bridgeConfig: BridgeConfig?,
    onConnect: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onConfigureBridge: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val (statusColor, statusBg, pulsing) = when (codespace.status) {
        CodespaceStatus.Available -> Triple(palette.success, palette.successBg, false)
        CodespaceStatus.Starting, CodespaceStatus.Rebuilding -> Triple(palette.warning, palette.warningBg, true)
        CodespaceStatus.Shutdown -> Triple(palette.textTertiary, palette.surfaceElevated, false)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surface)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .padding(16.dp)
            .testTag("codespace_card_${codespace.name}"),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = codespace.repoFullName,
                    color = palette.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                )
                Text(
                    text = "${codespace.displayName}  •  ${codespace.name}",
                    color = palette.textSecondary,
                    fontSize = 12.5.sp,
                )
            }

            StudioPillBadge(
                text = codespace.status.label,
                textColor = statusColor,
                backgroundColor = statusBg,
                borderColor = statusColor.copy(alpha = 0.35f),
                leadingDotColor = statusColor,
                pulsingDot = pulsing,
            )
        }

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.surfaceElevated)
                    .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.AccountTree,
                    contentDescription = "Git branch",
                    tint = palette.accent,
                    modifier = Modifier.size(13.dp),
                )
                Text(
                    text = codespace.branch,
                    color = palette.textPrimary,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.5.sp,
                )
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.surfaceElevated)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Memory,
                    contentDescription = "Machine specs",
                    tint = palette.textSecondary,
                    modifier = Modifier.size(13.dp),
                )
                Text(
                    text = codespace.machineSpecs,
                    color = palette.textSecondary,
                    fontSize = 11.5.sp,
                )
            }

            StudioPillBadge(
                text = "${codespace.region} • ${codespace.lastUsed}",
                textColor = palette.textTertiary,
                backgroundColor = palette.surfaceElevated,
            )
        }

        if (bridgeConfig != null) {
            Text(
                text = "Bridge: ${bridgeConfig.wsUrl}",
                color = palette.textTertiary,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 11.sp,
                maxLines = 1,
            )
        }

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = onConnect,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.accent,
                    contentColor = Color(0xFF191918),
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("connect_codespace_${codespace.name}"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.PowerSettingsNew,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text("Connect", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }

            if (codespace.status == CodespaceStatus.Shutdown) {
                OutlinedButton(
                    onClick = onStart,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.success.copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("start_codespace_${codespace.name}"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PlayArrow,
                        contentDescription = null,
                        tint = palette.success,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("Start", color = palette.success, fontSize = 12.5.sp)
                }
            } else {
                OutlinedButton(
                    onClick = onStop,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, palette.danger.copy(alpha = 0.45f)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("stop_codespace_${codespace.name}"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Stop,
                        contentDescription = null,
                        tint = palette.danger,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text("Stop", color = palette.danger, fontSize = 12.5.sp)
                }
            }

            OutlinedButton(
                onClick = onConfigureBridge,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, palette.borderFocused),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("configure_bridge_${codespace.name}"),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Router,
                    contentDescription = null,
                    tint = palette.textSecondary,
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text("Configure Bridge", color = palette.textPrimary, fontSize = 12.5.sp)
            }
        }
    }
}
