package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.SourceSerifFontFamily

@Composable
fun LoginScreen(
    initialPat: String,
    isLoading: Boolean,
    errorMessage: String?,
    isDarkMode: Boolean,
    onConnectGitHub: (String) -> Unit,
    onEnterDemoMode: () -> Unit,
    onToggleTheme: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    var patInput by remember(initialPat) { mutableStateOf(initialPat) }
    var showPat by remember { mutableStateOf(false) }
    var showPatHelper by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        palette.accent.copy(alpha = if (palette.isDark) 0.08f else 0.06f),
                        palette.canvas,
                    ),
                ),
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        IconButton(
            onClick = onToggleTheme,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .testTag("login_theme_toggle"),
        ) {
            Icon(
                imageVector = if (isDarkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                contentDescription = "Toggle warm light or dark theme",
                tint = palette.textSecondary,
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 460.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.border, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    ClaudeSparkleEmblem(size = 34.dp, tint = palette.accent)
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    text = "Claude Code Studio",
                    color = palette.textPrimary,
                    fontFamily = SourceSerifFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 28.sp,
                    textAlign = TextAlign.Center,
                )

                Spacer(Modifier.height(6.dp))

                Text(
                    text = "Unified in-app GitHub Codespaces workspace for fcc-claude, fcc-server, and integrated terminal control.",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp,
                    lineHeight = 20.sp,
                    textAlign = TextAlign.Center,
                )

                Spacer(Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StudioPillBadge(
                        text = "fcc-claude GUI",
                        textColor = palette.accent,
                        backgroundColor = palette.accentSubtle,
                        monospace = true,
                    )
                    StudioPillBadge(
                        text = "fcc-server :8082",
                        textColor = palette.textSecondary,
                        backgroundColor = palette.surfaceElevated,
                        borderColor = palette.border,
                        monospace = true,
                    )
                }

                Spacer(Modifier.height(24.dp))

                // Main Claude-styled authentication card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surface)
                        .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    // Option 2 highlighted quick entry for immediate exploration
                    Button(
                        onClick = onEnterDemoMode,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("enter_demo_mode_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color(0xFF191918),
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Enter Interactive Demo Mode",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                        )
                    }

                    Text(
                        text = "Instantly test streaming Claude Code, interactive tool diff approvals, FCC model routing, and the bash shell with zero credentials.",
                        color = palette.textTertiary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        HorizontalDivider(modifier = Modifier.weight(1f), color = palette.border)
                        Text(
                            text = "OR CONNECT LIVE CODESPACES",
                            color = palette.textTertiary,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.8.sp,
                        )
                        HorizontalDivider(modifier = Modifier.weight(1f), color = palette.border)
                    }

                    Text(
                        text = "GitHub Personal Access Token",
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                    )

                    OutlinedTextField(
                        value = patInput,
                        onValueChange = { patInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("github_pat_input"),
                        placeholder = {
                            Text(
                                text = "ghp_xxxxxxxxxxxxxxxxxxxx",
                                color = palette.textTertiary,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 13.sp,
                            )
                        },
                        singleLine = true,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Key,
                                contentDescription = null,
                                tint = palette.textSecondary,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = { showPat = !showPat }) {
                                Icon(
                                    imageVector = if (showPat) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                    contentDescription = if (showPat) "Hide token" else "Show token",
                                    tint = palette.textSecondary,
                                )
                            }
                        },
                        visualTransformation = if (showPat) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { onConnectGitHub(patInput) }),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.accent,
                            unfocusedBorderColor = palette.border,
                            focusedContainerColor = palette.surfaceElevated,
                            unfocusedContainerColor = palette.surfaceElevated,
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary,
                            cursorColor = palette.accent,
                        ),
                    )

                    if (!errorMessage.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.dangerBg)
                                .border(1.dp, palette.danger.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                        ) {
                            Text(
                                text = errorMessage,
                                color = palette.danger,
                                fontSize = 12.5.sp,
                                lineHeight = 18.sp,
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { onConnectGitHub(patInput) },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("connect_github_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, palette.borderFocused),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = palette.surfaceElevated,
                            contentColor = palette.textPrimary,
                        ),
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = palette.accent,
                            )
                            Spacer(Modifier.width(10.dp))
                            Text("Verifying with GitHub API…", fontSize = 13.5.sp)
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.Terminal,
                                contentDescription = null,
                                tint = palette.accent,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Connect GitHub Account",
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp,
                            )
                        }
                    }

                    // Collapsible inline helper
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(palette.surfaceElevated.copy(alpha = 0.7f))
                            .border(1.dp, palette.border, RoundedCornerShape(10.dp)),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showPatHelper = !showPatHelper }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("pat_helper_toggle"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = "How to generate a scoped GitHub PAT",
                                color = palette.textSecondary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Icon(
                                imageVector = if (showPatHelper) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                                contentDescription = "Toggle PAT instructions",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                        AnimatedVisibility(visible = showPatHelper) {
                            Column(
                                modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                Text(
                                    text = "1. Open GitHub Settings → Developer settings → Personal access tokens (classic).",
                                    color = palette.textSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                )
                                Text(
                                    text = "2. Click Generate new token and enable the 'codespace' and 'repo' scopes.",
                                    color = palette.textSecondary,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                )
                                Text(
                                    text = "3. Paste your token above. It is stored strictly in app-private storage on this device and only sent to api.github.com.",
                                    color = palette.textTertiary,
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
