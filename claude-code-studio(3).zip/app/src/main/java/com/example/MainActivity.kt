package com.example

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AppScreen
import com.example.model.RealModelsCatalog
import com.example.model.WorkspaceTab
import com.example.ui.screens.BridgeConfigDialog
import com.example.ui.screens.CodespacesDashboardScreen
import com.example.ui.screens.CommandPaletteDialog
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.StudioSettingsDialog
import com.example.ui.screens.WorkspaceShellScreen
import com.example.ui.theme.ClaudeCodeStudioTheme
import com.example.ui.theme.LocalStudioPalette
import com.example.viewmodel.StudioViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: StudioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClaudeCodeStudioApp(viewModel = viewModel)
        }
    }
}

/**
 * Native Android Screen Wake Lock effect (replaces web navigator.wakeLock):
 * Keeps the screen awake whenever a Claude response, build, or terminal process is active,
 * automatically re-acquiring on ON_RESUME and clearing immediately once the task finishes.
 */
@Composable
private fun KeepScreenAwakeEffect(isActive: Boolean) {
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(isActive, view, lifecycleOwner) {
        val window = (view.context as? Activity)?.window

        fun applyFlag(keepOn: Boolean) {
            if (window == null) return
            if (keepOn) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        applyFlag(isActive)

        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && isActive) {
                applyFlag(true)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            applyFlag(false)
        }
    }
}

@Composable
fun ClaudeCodeStudioApp(viewModel: StudioViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current

    // Keep screen awake whenever Claude or a terminal task is running
    KeepScreenAwakeEffect(isActive = state.isWakeLockActive)

    // Zero-reset background resume when returning from minimized/other apps
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onAppForegrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Request POST_NOTIFICATIONS politely on Android 13+ when entering Workspace so Foreground Service shows cleanly
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { /* Graceful no-op whether granted or denied */ }

    LaunchedEffect(state.currentScreen) {
        if (state.currentScreen == AppScreen.Workspace && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(state.snackbarMessage) {
        val msg = state.snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    ClaudeCodeStudioTheme(
        darkTheme = state.settings.darkMode,
        useSerifProse = state.settings.useSerifProse,
        codeFontSizeSp = state.settings.codeFontSizeSp,
    ) {
        val palette = LocalStudioPalette.current

        Scaffold(
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            containerColor = palette.canvas,
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(palette.canvas)
                    .padding(bottom = innerPadding.calculateBottomPadding()),
            ) {
                when {
                    state.isInitializing -> {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = palette.accent)
                        }
                    }

                    state.currentScreen == AppScreen.Login -> {
                        LoginScreen(
                            isDarkMode = state.settings.darkMode,
                            isAuthenticating = state.isAuthenticating,
                            authError = state.authError,
                            oauthClientId = state.settings.githubOAuthClientId,
                            oauthProxyUrl = state.settings.oauthProxyUrl,
                            deviceOAuth = state.deviceOAuth,
                            onToggleTheme = { viewModel.updateSettings { it.copy(darkMode = !it.darkMode) } },
                            onUpdateOAuthConfig = viewModel::updateOAuthConfiguration,
                            onStartDeviceOAuth = viewModel::startGitHubDeviceOAuth,
                            onCancelDeviceOAuth = viewModel::cancelGitHubDeviceOAuth,
                            onSetOAuthWebViewVisible = viewModel::setOAuthWebViewVisible,
                            onShowMessage = viewModel::showSnackbar,
                        )
                    }

                    state.currentScreen == AppScreen.Dashboard -> {
                        CodespacesDashboardScreen(
                            githubUserLogin = state.githubUserLogin,
                            isDarkMode = state.settings.darkMode,
                            isLoading = state.isLoadingCodespaces,
                            dashboardMessage = state.dashboardMessage,
                            codespaces = state.codespaces,
                            onToggleTheme = { viewModel.updateSettings { it.copy(darkMode = !it.darkMode) } },
                            onRefresh = viewModel::refreshCodespaces,
                            onConnect = viewModel::connectToCodespace,
                            onStart = viewModel::startCodespace,
                            onStop = viewModel::stopCodespace,
                            onConfigureBridge = viewModel::openBridgeConfigDialog,
                            onSignOut = viewModel::signOut,
                        )
                    }

                    state.currentScreen == AppScreen.Workspace -> {
                        WorkspaceShellScreen(
                            state = state,
                            onReturnToDashboard = viewModel::returnToDashboard,
                            onSelectWorkspaceTab = viewModel::selectWorkspaceTab,
                            onSelectSidebarTab = viewModel::selectSidebarTab,
                            onSelectInspectorTab = viewModel::selectInspectorTab,
                            onSetLeftDrawerMobile = viewModel::setLeftDrawerMobile,
                            onToggleRightInspector = viewModel::toggleRightInspector,
                            onSetRawActivityDrawer = viewModel::setRawActivityDrawer,
                            onClearRawActivity = viewModel::clearRawActivityLog,
                            onOpenSettings = { viewModel.setSettingsDialog(true) },
                            onOpenCommandPalette = { viewModel.setCommandPalette(true) },
                            onReconnectBridge = viewModel::reconnectActiveBridge,
                            onNewSession = viewModel::createNewSession,
                            onSelectSession = viewModel::selectSession,
                            onTogglePinSession = viewModel::togglePinSession,
                            onDeleteSession = viewModel::deleteSession,
                            onComposerTextChange = viewModel::updateComposerText,
                            onSendPrompt = viewModel::sendUserPrompt,
                            onStopGeneration = viewModel::stopGeneration,
                            onSelectModel = viewModel::selectModel,
                            onAddCustomModel = viewModel::addAndSelectCustomModel,
                            onRefreshModels = { viewModel.refreshLiveModels(silent = false) },
                            onSelectEffort = viewModel::selectEffort,
                            onCompactContext = viewModel::compactContext,
                            onClearConversation = viewModel::clearActiveSessionConversation,
                            onExportMarkdown = {
                                val md = viewModel.exportActiveSessionMarkdown()
                                if (md.isNotBlank()) {
                                    clipboard.setText(AnnotatedString(md))
                                    viewModel.showSnackbar("Copied session Markdown to clipboard.")
                                }
                            },
                            onToggleThinking = viewModel::toggleThinkingDrawer,
                            onAddAttachment = viewModel::addContextAttachment,
                            onRemoveAttachment = viewModel::removeContextAttachment,
                            onRefreshDirectory = viewModel::loadDirectory,
                            onToggleDirectory = viewModel::toggleDirectoryExpanded,
                            onToggleHiddenFiles = viewModel::toggleShowHiddenFiles,
                            onOpenFile = viewModel::openFileInEditor,
                            onCreateFile = viewModel::createFileInCodespace,
                            onCreateFolder = viewModel::createFolderInCodespace,
                            onRenameEntry = viewModel::renameFsEntry,
                            onDeleteEntry = viewModel::deleteFsEntry,
                            onInsertPathIntoChat = viewModel::insertFilePathIntoComposer,
                            onOpenBridgeSetup = viewModel::openBridgeSetupSettings,
                            onUpdateEditorContent = viewModel::updateEditorContent,
                            onSaveEditorFile = viewModel::saveEditorFile,
                            onStartFccServer = viewModel::startFccServerInTerminal,
                            onStopFccServer = viewModel::stopFccServerInTerminal,
                            onReloadFccWebView = viewModel::reloadFccWebView,
                            onSelectTerminalTab = viewModel::selectTerminalTab,
                            onAddTerminalTab = viewModel::addTerminalTab,
                            onCloseTerminalTab = viewModel::closeTerminalTab,
                            onRunTerminalCommand = viewModel::runTerminalCommand,
                            onSendTerminalSigInt = viewModel::sendTerminalSigInt,
                            onClearTerminal = viewModel::clearActiveTerminal,
                            onResizeTerminal = viewModel::resizeTerminal,
                            onShowMessage = viewModel::showSnackbar,
                        )
                    }
                }
            }
        }

        // Bridge Endpoint Configuration Modal
        state.bridgeConfigDialogTarget?.let { cs ->
            val currentCfg = state.bridgeConfigs[cs.name] ?: RealModelsCatalog.defaultBridgeConfig(cs.name)
            BridgeConfigDialog(
                codespace = cs,
                initialConfig = currentCfg,
                isTesting = state.isTestingBridge,
                testResult = state.bridgeTestResult,
                onDismiss = viewModel::closeBridgeConfigDialog,
                onTest = viewModel::testBridgeConfig,
                onSaveAndConnect = { cfg ->
                    viewModel.saveBridgeConfig(cfg)
                    viewModel.closeBridgeConfigDialog()
                    viewModel.connectToCodespace(cs)
                },
            )
        }

        // Studio Settings & Bridge.js One-Liner Dialog
        if (state.showSettingsDialog) {
            StudioSettingsDialog(
                settings = state.settings,
                availableModels = state.availableModels,
                initialTab = state.settingsInitialTab,
                onUpdateSettings = viewModel::updateSettings,
                onShowMessage = viewModel::showSnackbar,
                onDismiss = { viewModel.setSettingsDialog(false) },
            )
        }

        // Command Palette Modal
        if (state.showCommandPalette) {
            CommandPaletteDialog(
                onDismiss = { viewModel.setCommandPalette(false) },
                onAction = { actionId ->
                    when (actionId) {
                        "new_session" -> viewModel.createNewSession()
                        "refresh_models" -> viewModel.refreshLiveModels(silent = false)
                        "tab_claude" -> viewModel.selectWorkspaceTab(WorkspaceTab.ClaudeCode)
                        "tab_fcc" -> viewModel.selectWorkspaceTab(WorkspaceTab.FccAdmin)
                        "tab_terminal" -> viewModel.selectWorkspaceTab(WorkspaceTab.Terminal)
                        "raw_activity" -> viewModel.setRawActivityDrawer(true)
                        "toggle_inspector" -> viewModel.toggleRightInspector()
                        "reconnect" -> viewModel.reconnectActiveBridge()
                        "settings" -> viewModel.setSettingsDialog(true)
                    }
                },
            )
        }
    }
}
