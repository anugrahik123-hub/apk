package com.example.data

import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GitHubUserDto(
    val login: String,
    val name: String? = null,
    @Json(name = "avatar_url") val avatarUrl: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubCodespacesResponseDto(
    @Json(name = "total_count") val totalCount: Int = 0,
    val codespaces: List<GitHubCodespaceDto> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class GitHubCodespaceDto(
    val id: Long,
    val name: String,
    @Json(name = "display_name") val displayName: String? = null,
    val state: String? = null,
    val location: String? = null,
    @Json(name = "last_used_at") val lastUsedAt: String? = null,
    val repository: GitHubRepoDto? = null,
    val machine: GitHubMachineDto? = null,
    @Json(name = "git_status") val gitStatus: GitHubGitStatusDto? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubRepoDto(
    @Json(name = "full_name") val fullName: String? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubMachineDto(
    @Json(name = "display_name") val displayName: String? = null,
    val cpus: Int? = null,
    @Json(name = "memory_in_bytes") val memoryInBytes: Long? = null,
    @Json(name = "storage_in_bytes") val storageInBytes: Long? = null,
)

@JsonClass(generateAdapter = true)
data class GitHubGitStatusDto(
    val ref: String? = null,
)

@JsonClass(generateAdapter = true)
data class UpdateCodespaceTimeoutRequest(
    @Json(name = "idle_timeout_minutes") val idleTimeoutMinutes: Int = 240,
)

data class DeviceCodeResponse(
    val deviceCode: String,
    val userCode: String,
    val verificationUri: String,
    val expiresIn: Int,
    val interval: Int,
)

sealed interface DeviceTokenPollResult {
    data class Success(val accessToken: String) : DeviceTokenPollResult
    data object Pending : DeviceTokenPollResult
    data class SlowDown(val nextIntervalSec: Int) : DeviceTokenPollResult
    data class Failure(val message: String) : DeviceTokenPollResult
}

interface GitHubRestApi {
    @GET("user")
    suspend fun getAuthenticatedUser(
        @Header("Authorization") authorization: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubUserDto>

    @GET("user/codespaces")
    suspend fun listCodespaces(
        @Header("Authorization") authorization: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespacesResponseDto>

    @POST("user/codespaces/{codespace_name}/start")
    suspend fun startCodespace(
        @Header("Authorization") authorization: String,
        @Path("codespace_name") codespaceName: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespaceDto>

    @POST("user/codespaces/{codespace_name}/stop")
    suspend fun stopCodespace(
        @Header("Authorization") authorization: String,
        @Path("codespace_name") codespaceName: String,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespaceDto>

    @PATCH("user/codespaces/{codespace_name}")
    suspend fun updateCodespaceTimeout(
        @Header("Authorization") authorization: String,
        @Path("codespace_name") codespaceName: String,
        @Body body: UpdateCodespaceTimeoutRequest,
        @Header("Accept") accept: String = "application/vnd.github+json",
        @Header("X-GitHub-Api-Version") apiVersion: String = "2022-11-28",
    ): Response<GitHubCodespaceDto>
}

class GitHubCodespacesRepository {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    // Intentionally omits HTTP header/body logging so OAuth access tokens are never written to logs.
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val api: GitHubRestApi = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GitHubRestApi::class.java)

    /**
     * Step 1 of GitHub OAuth Device Flow:
     * Requests a device_code & 8-char user_code from GitHub directly (or through the bridge's
     * optional /github-oauth proxy endpoint when configured).
     */
    suspend fun startDeviceOAuthFlow(
        clientId: String,
        oauthProxyUrl: String = "",
    ): Result<DeviceCodeResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanClientId = clientId.trim()
            require(cleanClientId.isNotEmpty()) {
                "Configure a valid GitHub OAuth App Client ID (with Device Flow enabled) in Settings or below."
            }

            val proxyBase = oauthProxyUrl.trim().trimEnd('/')
            val request = if (proxyBase.isNotEmpty() && BridgeUrlValidator.validateHttpUrl(proxyBase) == null) {
                val jsonBody = JSONObject()
                    .put("action", "device_code")
                    .put("client_id", cleanClientId)
                    .put("scope", "codespace repo")
                    .toString()
                    .toRequestBody("application/json; charset=utf-8".toMediaType())
                Request.Builder()
                    .url("$proxyBase/github-oauth")
                    .header("Accept", "application/json")
                    .post(jsonBody)
                    .build()
            } else {
                val formBody = FormBody.Builder()
                    .add("client_id", cleanClientId)
                    .add("scope", "codespace repo")
                    .build()
                Request.Builder()
                    .url("https://github.com/login/device/code")
                    .header("Accept", "application/json")
                    .post(formBody)
                    .build()
            }

            okHttpClient.newCall(request).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                val json = runCatching { JSONObject(raw) }.getOrNull()
                if (!resp.isSuccessful || json == null) {
                    val errDetail = json?.optString("error_description")?.takeIf { it.isNotBlank() }
                        ?: json?.optString("error")?.takeIf { it.isNotBlank() }
                        ?: "HTTP ${resp.code}"
                    error("GitHub OAuth Device Flow failed: $errDetail. Verify your OAuth App Client ID has Device Flow enabled.")
                }
                if (json.has("error")) {
                    error(json.optString("error_description", json.optString("error")))
                }
                DeviceCodeResponse(
                    deviceCode = json.getString("device_code"),
                    userCode = json.getString("user_code"),
                    verificationUri = json.optString("verification_uri", "https://github.com/login/device"),
                    expiresIn = json.optInt("expires_in", 900),
                    interval = json.optInt("interval", 5).coerceAtLeast(5),
                )
            }
        }
    }

    /**
     * Step 2 of GitHub OAuth Device Flow:
     * Polls /login/oauth/access_token (or bridge /github-oauth proxy) until authorized.
     */
    suspend fun pollDeviceOAuthToken(
        clientId: String,
        deviceCode: String,
        currentIntervalSec: Int,
        oauthProxyUrl: String = "",
    ): DeviceTokenPollResult = withContext(Dispatchers.IO) {
        try {
            val cleanClientId = clientId.trim()
            val proxyBase = oauthProxyUrl.trim().trimEnd('/')
            val request = if (proxyBase.isNotEmpty() && BridgeUrlValidator.validateHttpUrl(proxyBase) == null) {
                val jsonBody = JSONObject()
                    .put("action", "access_token")
                    .put("client_id", cleanClientId)
                    .put("device_code", deviceCode)
                    .put("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                    .toString()
                    .toRequestBody("application/json; charset=utf-8".toMediaType())
                Request.Builder()
                    .url("$proxyBase/github-oauth")
                    .header("Accept", "application/json")
                    .post(jsonBody)
                    .build()
            } else {
                val formBody = FormBody.Builder()
                    .add("client_id", cleanClientId)
                    .add("device_code", deviceCode)
                    .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                    .build()
                Request.Builder()
                    .url("https://github.com/login/oauth/access_token")
                    .header("Accept", "application/json")
                    .post(formBody)
                    .build()
            }

            okHttpClient.newCall(request).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                val json = runCatching { JSONObject(raw) }.getOrNull()
                    ?: return@withContext DeviceTokenPollResult.Failure("Unexpected OAuth response (HTTP ${resp.code}).")

                val accessToken = json.optString("access_token")
                if (accessToken.isNotBlank()) {
                    return@withContext DeviceTokenPollResult.Success(accessToken)
                }

                when (val err = json.optString("error")) {
                    "authorization_pending" -> DeviceTokenPollResult.Pending
                    "slow_down" -> DeviceTokenPollResult.SlowDown(
                        json.optInt("interval", currentIntervalSec + 5).coerceAtLeast(currentIntervalSec + 5),
                    )
                    "expired_token" -> DeviceTokenPollResult.Failure("Device code expired. Start sign-in again.")
                    "access_denied" -> DeviceTokenPollResult.Failure("Authorization was cancelled on GitHub.")
                    else -> DeviceTokenPollResult.Failure(
                        json.optString("error_description").ifBlank { err.ifBlank { "OAuth polling error." } },
                    )
                }
            }
        } catch (e: Exception) {
            DeviceTokenPollResult.Failure(e.localizedMessage ?: "Network error while checking GitHub authorization.")
        }
    }

    suspend fun fetchAuthenticatedUser(accessToken: String): Result<GitHubUserDto> = runCatching {
        val token = accessToken.trim()
        require(token.isNotBlank()) { "Missing GitHub OAuth access token." }
        val response = api.getAuthenticatedUser("Bearer $token")
        if (!response.isSuccessful) {
            error("GitHub session expired or unauthorized (HTTP ${response.code()}). Please sign in again.")
        }
        response.body() ?: error("Empty response from GitHub API.")
    }

    suspend fun fetchCodespaces(accessToken: String): Result<List<CodespaceInfo>> = runCatching {
        val token = accessToken.trim()
        val response = api.listCodespaces("Bearer $token")
        if (!response.isSuccessful) {
            val detail = when (response.code()) {
                401 -> "GitHub OAuth token expired (HTTP 401). Please sign in again."
                403 -> "OAuth token lacks the 'codespace' scope (HTTP 403)."
                else -> "Failed to load Codespaces (HTTP ${response.code()})."
            }
            error(detail)
        }
        response.body()?.codespaces.orEmpty().map { it.toDomain() }
    }

    suspend fun startCodespace(accessToken: String, codespaceName: String): Result<CodespaceInfo> = runCatching {
        val response = api.startCodespace("Bearer ${accessToken.trim()}", codespaceName)
        if (!response.isSuccessful) {
            error("Unable to start Codespace (HTTP ${response.code()}).")
        }
        response.body()?.toDomain() ?: error("Empty response when starting Codespace.")
    }

    suspend fun stopCodespace(accessToken: String, codespaceName: String): Result<CodespaceInfo> = runCatching {
        val response = api.stopCodespace("Bearer ${accessToken.trim()}", codespaceName)
        if (!response.isSuccessful) {
            error("Unable to stop Codespace (HTTP ${response.code()}).")
        }
        response.body()?.toDomain() ?: error("Empty response when stopping Codespace.")
    }

    /**
     * Extends GitHub Codespace idle_timeout_minutes to 240 (4 hours) via PATCH /user/codespaces/{name}
     * so GitHub does not shut down the Codespace after the default 30-minute idle limit.
     */
    suspend fun extendCodespaceIdleTimeout(
        accessToken: String,
        codespaceName: String,
        idleTimeoutMinutes: Int = 240,
    ): Result<CodespaceInfo> = runCatching {
        val response = api.updateCodespaceTimeout(
            authorization = "Bearer ${accessToken.trim()}",
            codespaceName = codespaceName,
            body = UpdateCodespaceTimeoutRequest(idleTimeoutMinutes = idleTimeoutMinutes),
        )
        if (!response.isSuccessful) {
            error("Could not extend Codespace idle timeout (HTTP ${response.code()}).")
        }
        response.body()?.toDomain() ?: error("Empty response when extending Codespace timeout.")
    }

    private fun GitHubCodespaceDto.toDomain(): CodespaceInfo {
        val cores = machine?.cpus ?: 4
        val ramGb = ((machine?.memoryInBytes ?: (16L * 1024 * 1024 * 1024)) / (1024L * 1024 * 1024)).coerceAtLeast(2)
        val storageGb = ((machine?.storageInBytes ?: (32L * 1024 * 1024 * 1024)) / (1024L * 1024 * 1024)).coerceAtLeast(16)
        val specs = machine?.displayName?.takeIf { it.isNotBlank() }
            ?: "$cores-core • ${ramGb} GB RAM • ${storageGb} GB storage"

        val mappedStatus = when (state?.lowercase()) {
            "available" -> CodespaceStatus.Available
            "starting", "queued", "provisioning", "awaiting" -> CodespaceStatus.Starting
            "rebuilding" -> CodespaceStatus.Rebuilding
            else -> CodespaceStatus.Shutdown
        }

        return CodespaceInfo(
            id = id.toString(),
            name = name,
            displayName = displayName?.takeIf { it.isNotBlank() } ?: name,
            repoFullName = repository?.fullName ?: "unknown/repository",
            branch = gitStatus?.ref?.takeIf { it.isNotBlank() } ?: "main",
            machineSpecs = specs,
            region = location?.takeIf { it.isNotBlank() } ?: "EastUs",
            lastUsed = formatIsoTimestamp(lastUsedAt),
            status = mappedStatus,
        )
    }

    private fun formatIsoTimestamp(iso: String?): String {
        if (iso.isNullOrBlank()) return "Recently"
        return iso.replace("T", " ").removeSuffix("Z").take(16) + " UTC"
    }
}
