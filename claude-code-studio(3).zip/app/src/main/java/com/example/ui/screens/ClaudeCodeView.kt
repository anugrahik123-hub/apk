package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.Attachment
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiModelOption
import com.example.model.AttachmentType
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.EffortLevel
import com.example.model.FsEntry
import com.example.model.MessageRole
import com.example.model.formatElapsedDuration
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.MarkdownMessageBody
import com.example.ui.components.StatusDot
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ClaudeCodeView(
    session: ChatSession?,
    availableModels: List<AiModelOption>,
    isRefreshingModels: Boolean,
    selectedModel: AiModelOption,
    selectedEffort: EffortLevel,
    composerText: String,
    pendingAttachments: List<ContextAttachment>,
    knownFiles: List<FsEntry>,
    isStreaming: Boolean,
    useSerifProse: Boolean,
    codeFontSizeSp: Float,
    onComposerTextChange: (String) -> Unit,
    onSendPrompt: () -> Unit,
    onStopGeneration: () -> Unit,
    onSelectModel: (String) -> Unit,
    onAddCustomModel: (String) -> Unit,
    onRefreshModels: () -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onCompactContext: () -> Unit,
    onClearConversation: () -> Unit,
    onExportMarkdown: () -> Unit,
    onToggleThinking: (String) -> Unit,
    onAddAttachment: (AttachmentType, String, String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val messages = session?.messages.orEmpty()
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Pause auto-scroll immediately when user scrolls upward; resume only when at bottom or tapping ↓
    var autoScrollEnabled by remember { mutableStateOf(true) }

    val isAtBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val total = info.totalItemsCount
            if (total == 0) true
            else {
                val lastVisible = info.visibleItemsInfo.lastOrNull()
                lastVisible != null && lastVisible.index >= total - 1 && !listState.canScrollForward
            }
        }
    }

    LaunchedEffect(listState.isScrollInProgress, isAtBottom) {
        if (listState.isScrollInProgress && !isAtBottom) {
            autoScrollEnabled = false
        } else if (!listState.isScrollInProgress && isAtBottom) {
            autoScrollEnabled = true
        }
    }

    val lastMessageTextLen = messages.lastOrNull()?.text?.length ?: 0
    val lastThinkingLen = messages.lastOrNull()?.thinkingText?.length ?: 0
    LaunchedEffect(messages.size, lastMessageTextLen, lastThinkingLen, autoScrollEnabled) {
        if (autoScrollEnabled && messages.isNotEmpty()) {
            listState.scrollToItem(messages.lastIndex)
        }
    }

    val showScrollDownArrow by remember {
        derivedStateOf {
            messages.isNotEmpty() && !isAtBottom
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.canvas),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter,
        ) {
            if (messages.isEmpty()) {
                EmptyClaudeSessionView(
                    selectedModel = selectedModel,
                    onQuickPrompt = { prompt ->
                        onComposerTextChange(prompt)
                    },
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .widthIn(max = 820.dp)
                        .fillMaxSize()
                        .testTag("claude_chat_list"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    items(
                        items = messages,
                        key = { it.id },
                    ) { msg ->
                        if (msg.role == MessageRole.User) {
                            UserMessageTurn(message = msg)
                        } else {
                            AssistantMessageTurn(
                                message = msg,
                                useSerifProse = useSerifProse,
                                codeFontSizeSp = codeFontSizeSp,
                                onToggleThinking = { onToggleThinking(msg.id) },
                                onCopySuccess = { onShowMessage("Copied to clipboard.") },
                            )
                        }
                    }
                    item(key = "bottom_spacer") {
                        Spacer(modifier = Modifier.height(28.dp))
                    }
                }
            }

            // Floating Scroll-to-Bottom Arrow (↓) when scrolled up
            androidx.compose.animation.AnimatedVisibility(
                visible = showScrollDownArrow,
                enter = fadeIn() + scaleIn(initialScale = 0.85f),
                exit = fadeOut() + scaleOut(targetScale = 0.85f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 18.dp, bottom = 14.dp),
            ) {
                SmallFloatingActionButton(
                    onClick = {
                        autoScrollEnabled = true
                        coroutineScope.launch {
                            if (messages.isNotEmpty()) {
                                listState.animateScrollToItem(messages.lastIndex)
                            }
                        }
                    },
                    shape = CircleShape,
                    containerColor = palette.surfaceElevated,
                    contentColor = palette.textPrimary,
                    modifier = Modifier
                        .size(44.dp)
                        .border(1.dp, palette.borderFocused, CircleShape)
                        .testTag("scroll_to_bottom_fab"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ArrowDownward,
                        contentDescription = "Scroll to latest message",
                        tint = palette.accent,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }

        // Bottom Floating Composer Bar
        Box(
            modifier = Modifier
                .widthIn(max = 820.dp)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            ClaudeComposerBar(
                composerText = composerText,
                pendingAttachments = pendingAttachments,
                knownFiles = knownFiles,
                availableModels = availableModels,
                isRefreshingModels = isRefreshingModels,
                selectedModel = selectedModel,
                selectedEffort = selectedEffort,
                contextBreakdown = session?.contextBreakdown ?: ContextBreakdown(),
                isStreaming = isStreaming,
                onComposerTextChange = onComposerTextChange,
                onSendPrompt = {
                    autoScrollEnabled = true
                    onSendPrompt()
                },
                onStopGeneration = onStopGeneration,
                onSelectModel = onSelectModel,
                onAddCustomModel = onAddCustomModel,
                onRefreshModels = onRefreshModels,
                onSelectEffort = onSelectEffort,
                onCompactContext = onCompactContext,
                onClearConversation = onClearConversation,
                onExportMarkdown = onExportMarkdown,
                onAddAttachment = onAddAttachment,
                onRemoveAttachment = onRemoveAttachment,
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EmptyClaudeSessionView(
    selectedModel: AiModelOption,
    onQuickPrompt: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val starters = remember {
        listOf(
            "Inspect the workspace architecture and summarize key files",
            "Run the test suite and fix any failing tests",
            "Review git status and recent changes",
        )
    }

    Column(
        modifier = Modifier
            .widthIn(max = 600.dp)
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceElevated)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) {
            ClaudeSparkleEmblem(size = 30.dp, tint = palette.accent)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "What are we building?",
            color = palette.textPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = InterFontFamily,
        )
        Spacer(modifier = Modifier.height(6.dp))
        StudioPillBadge(
            text = "${selectedModel.displayName} • Full-Auto",
            textColor = palette.accent,
            backgroundColor = palette.accentSubtle,
            monospace = true,
        )
        Spacer(modifier = Modifier.height(22.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            starters.forEach { starter ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = palette.surfaceElevated,
                    modifier = Modifier
                        .border(1.dp, palette.borderDefault, RoundedCornerShape(12.dp))
                        .clickable { onQuickPrompt(starter) },
                ) {
                    Text(
                        text = starter,
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        fontFamily = InterFontFamily,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun UserMessageTurn(message: ChatMessage) {
    val palette = LocalStudioPalette.current
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
    ) {
        if (message.attachments.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(bottom = 6.dp),
            ) {
                message.attachments.forEach { att ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.surfaceElevated)
                            .border(1.dp, palette.borderDefault, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Attachment,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(13.dp),
                        )
                        Text(
                            text = att.label,
                            color = palette.textSecondary,
                            fontSize = 11.5.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = palette.userBubbleBg,
            modifier = Modifier
                .widthIn(max = 640.dp)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
        ) {
            Text(
                text = message.text,
                color = palette.textPrimary,
                fontSize = 14.5.sp,
                lineHeight = 21.sp,
                fontFamily = InterFontFamily,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
            )
        }
    }
}

@Composable
private fun AssistantMessageTurn(
    message: ChatMessage,
    useSerifProse: Boolean,
    codeFontSizeSp: Float,
    onToggleThinking: () -> Unit,
    onCopySuccess: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(
            modifier = Modifier
                .padding(top = 2.dp)
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(palette.surfaceElevated)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center,
        ) {
            ClaudeSparkleEmblem(size = 16.dp, tint = palette.accent)
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Genuine Extended Thinking Drawer — rendered ONLY when real thinking_delta blocks exist!
            if (message.thinkingText.isNotBlank()) {
                GenuineThinkingDrawer(
                    thinkingText = message.thinkingText,
                    expanded = message.isThinkingExpanded,
                    isStreaming = message.isStreaming,
                    onToggle = onToggleThinking,
                )
            }

            // Clean Markdown & Syntax-Highlighted Code Body (memoized when complete)
            if (message.text.isNotEmpty()) {
                MarkdownMessageBody(
                    markdown = message.text,
                    useSerifProse = useSerifProse,
                    codeFontSizeSp = codeFontSizeSp,
                    onCopyCode = { code ->
                        clipboard.setText(AnnotatedString(code))
                        onCopySuccess()
                    },
                )
            }

            // Minimal live status line while Claude is working (disappears completely when done)
            if (message.isStreaming) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 2.dp),
                ) {
                    StatusDot(color = palette.accent, pulsing = true, size = 7.dp)
                    Text(
                        text = message.liveStatusLabel.ifBlank { "Working on project…" },
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        fontFamily = InterFontFamily,
                    )
                    Text(
                        text = "•",
                        color = palette.textTertiary,
                        fontSize = 12.sp,
                    )
                    LiveElapsedTimerText(
                        startedAtMs = message.startedAtMs,
                        frozenElapsedMs = message.elapsedMs,
                        isStreaming = true,
                    )
                }
            } else {
                // Compact Completed Turn Footer with permanently frozen Xm Ys cumulative duration
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 2.dp),
                ) {
                    if (message.elapsedMs != null) {
                        LiveElapsedTimerText(
                            startedAtMs = message.startedAtMs,
                            frozenElapsedMs = message.elapsedMs,
                            isStreaming = false,
                        )
                    }
                    if (message.outputTokens > 0) {
                        Text(
                            text = "${message.outputTokens} tok",
                            color = palette.textTertiary,
                            fontSize = 11.5.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                    }
                    if (message.text.isNotBlank()) {
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(message.text))
                                onCopySuccess()
                            },
                            modifier = Modifier.size(32.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = "Copy response",
                                tint = palette.textTertiary,
                                modifier = Modifier.size(14.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GenuineThinkingDrawer(
    thinkingText: String,
    expanded: Boolean,
    isStreaming: Boolean,
    onToggle: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceElevated)
            .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.Psychology,
                    contentDescription = null,
                    tint = palette.accent,
                    modifier = Modifier.size(15.dp),
                )
                Text(
                    text = if (isStreaming) "Thinking…" else "Thought process",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = InterFontFamily,
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                contentDescription = if (expanded) "Collapse thinking" else "Expand thinking",
                tint = palette.textTertiary,
                modifier = Modifier.size(16.dp),
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column {
                HorizontalDivider(color = palette.borderDefault)
                Text(
                    text = thinkingText,
                    color = palette.textSecondary,
                    fontSize = 12.5.sp,
                    lineHeight = 18.sp,
                    fontFamily = InterFontFamily,
                    modifier = Modifier.padding(12.dp),
                )
            }
        }
    }
}

/**
 * Isolated leaf composable so 1-second live elapsed ticking NEVER recomposes the outer chat list
 * or completed turns. Displays human-readable "42s" under 60s and "1m 2s" for 60s+.
 */
@Composable
fun LiveElapsedTimerText(
    startedAtMs: Long,
    frozenElapsedMs: Long?,
    isStreaming: Boolean,
) {
    val palette = LocalStudioPalette.current
    var liveElapsedMs by remember(startedAtMs, frozenElapsedMs) {
        mutableLongStateOf(frozenElapsedMs ?: (System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L))
    }

    LaunchedEffect(isStreaming, startedAtMs, frozenElapsedMs) {
        if (!isStreaming || frozenElapsedMs != null) {
            if (frozenElapsedMs != null) liveElapsedMs = frozenElapsedMs
            return@LaunchedEffect
        }
        while (true) {
            liveElapsedMs = (System.currentTimeMillis() - startedAtMs).coerceAtLeast(0L)
            delay(1_000L)
        }
    }

    Text(
        text = formatElapsedDuration(frozenElapsedMs ?: liveElapsedMs),
        color = if (isStreaming) palette.textSecondary else palette.textTertiary,
        fontSize = 11.5.sp,
        fontFamily = JetBrainsMonoFontFamily,
    )
}
