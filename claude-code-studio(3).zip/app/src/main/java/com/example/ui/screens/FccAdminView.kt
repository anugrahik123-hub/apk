package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.AiModelOption
import com.example.model.EffortLevel
import com.example.model.FccServerStatus
import com.example.ui.components.EffortSignalBars
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@OptIn(ExperimentalLayoutApi::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FccAdminView(
    fccServerUrl: String,
    fccServerStatus: FccServerStatus,
    availableModels: List<AiModelOption>,
    selectedModel: AiModelOption,
    selectedEffort: EffortLevel,
    isRefreshingModels: Boolean,
    reloadNonce: Int,
    onSelectModel: (String) -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onStartFccServer: () -> Unit,
    onStopFccServer: () -> Unit,
    onReloadWebView: () -> Unit,
    onRefreshModels: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    var showEffortMenu by remember { mutableStateOf(false) }

    val (statusColor, statusBg, pulsing) = when (fccServerStatus) {
        FccServerStatus.Running -> Triple(palette.success, palette.successBg, true)
        FccServerStatus.Starting, FccServerStatus.Unknown -> Triple(palette.warning, palette.warningBg, true)
        FccServerStatus.Stopped -> Triple(palette.danger, palette.dangerBg, false)
    }

    val safeUrl = remember(fccServerUrl) {
        val trimmed = fccServerUrl.trim()
        val uri = Uri.parse(trimmed)
        if ((uri.scheme == "https" || uri.scheme == "http") && !uri.host.isNullOrBlank()) trimmed else ""
    }
    val allowedHost = remember(safeUrl) { Uri.parse(safeUrl).host?.lowercase().orEmpty() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.canvas),
    ) {
        // Real Live fcc-server Control Bar + Always-Unlocked Model & Ultracode Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.sidebar)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Text(
                        text = "fcc-server Admin",
                        color = palette.textPrimary,
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = InterFontFamily,
                    )
                    StudioPillBadge(
                        text = fccServerStatus.label,
                        textColor = statusColor,
                        backgroundColor = statusBg,
                        leadingDotColor = statusColor,
                        pulsingDot = pulsing,
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Button(
                        onClick = onStartFccServer,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color.White,
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("fcc_start_button"),
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start", fontSize = 11.5.sp)
                    }
                    OutlinedButton(
                        onClick = onStopFccServer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("fcc_stop_button"),
                    ) {
                        Icon(Icons.Outlined.Stop, null, tint = palette.danger, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop", color = palette.danger, fontSize = 11.5.sp)
                    }
                    IconButton(
                        onClick = onReloadWebView,
                        modifier = Modifier.size(34.dp),
                    ) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Reload admin UI", tint = palette.textSecondary, modifier = Modifier.size(17.dp))
                    }
                }
            }

            // Unlocked Live Model & Toggleable Ultracode Strip (Always clickable even with Admin UI open!)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Box {
                        val isUltracode = selectedEffort == EffortLevel.Ultracode
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isUltracode) palette.accentSubtle else palette.surfaceElevated)
                                .border(
                                    1.dp,
                                    if (isUltracode) palette.accent else palette.borderDefault,
                                    RoundedCornerShape(8.dp),
                                )
                                .clickable { showEffortMenu = true }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .testTag("fcc_effort_selector"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            if (isUltracode) {
                                Icon(Icons.Outlined.Psychology, null, tint = palette.accent, modifier = Modifier.size(13.dp))
                            } else {
                                EffortSignalBars(level = selectedEffort.bars)
                            }
                            Text(
                                text = "Effort: ${selectedEffort.label}",
                                color = if (isUltracode) palette.accent else palette.textPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                            )
                            Icon(Icons.Outlined.ExpandMore, null, tint = palette.textTertiary, modifier = Modifier.size(13.dp))
                        }

                        DropdownMenu(
                            expanded = showEffortMenu,
                            onDismissRequest = { showEffortMenu = false },
                            modifier = Modifier.background(palette.surfaceElevated),
                        ) {
                            EffortLevel.entries.forEach { level ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            EffortSignalBars(level = level.bars)
                                            Text(
                                                text = if (level == EffortLevel.Ultracode) "Ultracode (Max)" else level.label,
                                                color = if (level == EffortLevel.Ultracode) palette.accent else palette.textPrimary,
                                                fontSize = 12.sp,
                                            )
                                            if (level == selectedEffort) {
                                                Icon(Icons.Outlined.Check, null, tint = palette.accent, modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    },
                                    onClick = {
                                        onSelectEffort(level)
                                        showEffortMenu = false
                                    },
                                )
                            }
                        }
                    }

                    Text(
                        text = safeUrl.ifBlank { "Configure port 8082" },
                        color = palette.textTertiary,
                        fontSize = 10.5.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                OutlinedButton(
                    onClick = onRefreshModels,
                    enabled = !isRefreshingModels,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp),
                ) {
                    Text(
                        text = if (isRefreshingModels) "Syncing…" else "Sync Models (${availableModels.size})",
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                    )
                }
            }

            // Interactive Model Switcher Chips (tap any model directly to switch active model)
            if (availableModels.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    availableModels.take(10).forEach { m ->
                        val isSelected = m.id == selectedModel.id
                        StudioPillBadge(
                            text = m.displayName,
                            textColor = if (isSelected) palette.accent else palette.textSecondary,
                            backgroundColor = if (isSelected) palette.accentSubtle else palette.surfaceElevated,
                            borderColor = if (isSelected) palette.accent else palette.borderDefault,
                            monospace = true,
                            modifier = Modifier.clickable { onSelectModel(m.id) },
                        )
                    }
                }
            }
        }
        HorizontalDivider(color = palette.borderDefault)

        // Embedded In-App Hardened WebView for fcc-server (:8082)
        if (safeUrl.isBlank()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "Set your Codespace port 8082 URL in Bridge Settings to load the live fcc-server Admin UI inside the app.",
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                )
            }
        } else {
            key(safeUrl, reloadNonce) {
                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("fcc_admin_webview"),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                ): Boolean {
                                    val host = request?.url?.host?.lowercase().orEmpty()
                                    val isAllowed = host == allowedHost ||
                                        host.endsWith(".app.github.dev") ||
                                        host == "github.com" ||
                                        host.endsWith(".github.com")
                                    return !isAllowed
                                }
                            }
                            loadUrl(safeUrl)
                        }
                    },
                )
            }
        }
    }
}
