package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.BridgeUrlValidator
import com.example.model.AiModelOption
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.CodespaceInfo
import com.example.model.EffortLevel
import com.example.model.RealModelsCatalog
import com.example.model.StudioSettings
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

/**
 * Self-contained production Node.js bridge.js one-liner matching LiveCodespaceBridgeService 100%:
 * - Listens on HTTP + WebSocket port 8765
 * - POST /github-oauth proxy endpoint for GitHub OAuth Device Flow (avoids CORS)
 * - 10s ping/pong heartbeat + persistent event replay buffer ({ type: "resume", sessionId, lastEventId })
 * - Runs fcc-claude with --dangerously-skip-permissions (full-auto, zero prompts) and keeps running across WS drops
 * - { type: "list_models" } querying local http://127.0.0.1:8082/v1/models
 * - Real /workspaces-confined filesystem CRUD (fs_list, fs_read, fs_write, fs_mkdir, fs_rename, fs_delete)
 * - Interactive shell PTY streaming (pty_input, pty_output, pty_resize, pty_signal)
 */
const val CODESPACE_BRIDGE_ONE_LINER = """cat << 'EOF' > bridge.js
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');

const PORT = Number(process.env.BRIDGE_PORT || 8765);
const SECRET = (process.env.BRIDGE_SECRET || '').trim();
const WORKSPACE_ROOT = path.resolve(process.env.WORKSPACE_ROOT || '/workspaces');

function safePath(inputPath) {
  const raw = String(inputPath || WORKSPACE_ROOT);
  const resolved = path.resolve(raw.startsWith('/') ? raw : path.join(WORKSPACE_ROOT, raw));
  if (resolved !== WORKSPACE_ROOT && !resolved.startsWith(WORKSPACE_ROOT + path.sep)) {
    throw new Error('Access outside /workspaces is forbidden');
  }
  return resolved;
}

function timingSafeAuth(header) {
  if (!SECRET) return true;
  const expected = Buffer.from('Bearer ' + SECRET);
  const actual = Buffer.from(String(header || ''));
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

function postGitHubForm(urlPath, params) {
  return new Promise((resolve, reject) => {
    const body = new URLSearchParams(params).toString();
    const req = https.request({
      hostname: 'github.com',
      path: urlPath,
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(body),
      },
    }, (res) => {
      let data = '';
      res.on('data', (c) => data += c);
      res.on('end', () => resolve({ status: res.statusCode || 200, body: data }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function fetchLocalModels() {
  return new Promise((resolve) => {
    const req = http.get('http://127.0.0.1:8082/v1/models', (res) => {
      let data = '';
      res.on('data', (c) => data += c);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(Array.isArray(parsed.data) ? parsed.data : []);
        } catch { resolve([]); }
      });
    });
    req.on('error', () => resolve([]));
    req.setTimeout(3500, () => { req.destroy(); resolve([]); });
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  const parsedUrl = new URL(req.url || '/', 'http://127.0.0.1');

  if (req.method === 'POST' && parsedUrl.pathname === '/github-oauth') {
    let body = '';
    req.on('data', (c) => body += c);
    req.on('end', async () => {
      try {
        const json = JSON.parse(body || '{}');
        const out = json.action === 'device_code'
          ? await postGitHubForm('/login/device/code', { client_id: json.client_id || '', scope: json.scope || 'codespace repo' })
          : await postGitHubForm('/login/oauth/access_token', { client_id: json.client_id || '', device_code: json.device_code || '', grant_type: 'urn:ietf:params:oauth:grant-type:device_code' });
        res.writeHead(out.status, { 'Content-Type': 'application/json' });
        res.end(out.body);
      } catch (e) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  if (parsedUrl.pathname === '/api/files' || parsedUrl.pathname === '/api/files/content') {
    if (!timingSafeAuth(req.headers.authorization)) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Unauthorized' }));
      return;
    }
    if (req.method === 'GET' && parsedUrl.pathname === '/api/files') {
      try {
        const dir = safePath(parsedUrl.searchParams.get('path') || WORKSPACE_ROOT);
        const includeHidden = parsedUrl.searchParams.get('includeHidden') === 'true';
        const dirents = fs.readdirSync(dir, { withFileTypes: true });
        const entries = dirents
          .filter((d) => includeHidden || !d.name.startsWith('.'))
          .map((d) => {
            const full = path.join(dir, d.name);
            let size = 0;
            try { if (!d.isDirectory()) size = fs.statSync(full).size; } catch {}
            return { name: d.name, path: full, isDirectory: d.isDirectory(), size };
          });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, entries }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
      return;
    }
    if (req.method === 'GET' && parsedUrl.pathname === '/api/files/content') {
      try {
        const content = fs.readFileSync(safePath(parsedUrl.searchParams.get('path')), 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, content }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
      return;
    }
    if (req.method === 'POST' && parsedUrl.pathname === '/api/files') {
      let body = '';
      req.on('data', (c) => body += c);
      req.on('end', () => {
        try {
          const msg = JSON.parse(body || '{}');
          if (msg.action === 'write') {
            const target = safePath(msg.path);
            fs.mkdirSync(path.dirname(target), { recursive: true });
            fs.writeFileSync(target, String(msg.content ?? ''), 'utf8');
          } else if (msg.action === 'mkdir') {
            fs.mkdirSync(safePath(msg.path), { recursive: true });
          } else if (msg.action === 'rename') {
            fs.renameSync(safePath(msg.oldPath), safePath(msg.newPath));
          } else if (msg.action === 'delete') {
            fs.rmSync(safePath(msg.path), { recursive: true, force: true });
          }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: e.message }));
        }
      });
      return;
    }
  }

  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: true, service: 'claude-code-studio-bridge', port: PORT, features: ['ws', 'api_files', 'keepalive', 'resume'] }));
});

const wss = new WebSocketServer({ server });
const clients = new Set();
const sessions = new Map(); // sessionId -> { events: [], proc: ChildProcess|null }
const ptys = new Map(); // tabId -> ChildProcess
let globalEventId = 1;

function broadcastSessionEvent(sessionId, payload) {
  const ev = { ...payload, sessionId, eventId: globalEventId++ };
  let st = sessions.get(sessionId);
  if (!st) { st = { events: [], proc: null }; sessions.set(sessionId, st); }
  st.events.push(ev);
  if (st.events.length > 500) st.events.shift();
  const wire = JSON.stringify(ev);
  for (const ws of clients) {
    if (ws.readyState === 1) ws.send(wire);
  }
}

function broadcastPty(tabId, stream, chunk) {
  const wire = JSON.stringify({ type: 'pty_output', tabId, stream, data: chunk.toString('utf8') });
  for (const ws of clients) {
    if (ws.readyState === 1) ws.send(wire);
  }
}

function ensurePty(tabId) {
  if (ptys.has(tabId)) return ptys.get(tabId);
  const sh = spawn('bash', ['-i'], { cwd: WORKSPACE_ROOT, env: { ...process.env, TERM: 'xterm-256color' } });
  sh.stdout.on('data', (d) => broadcastPty(tabId, 'stdout', d));
  sh.stderr.on('data', (d) => broadcastPty(tabId, 'stderr', d));
  sh.on('close', () => ptys.delete(tabId));
  ptys.set(tabId, sh);
  return sh;
}

wss.on('connection', (ws, req) => {
  if (!timingSafeAuth(req.headers.authorization)) {
    ws.close(4001, 'Unauthorized');
    return;
  }
  clients.add(ws);
  ws.on('close', () => clients.delete(ws));

  ws.on('message', async (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString('utf8')); } catch { return; }
    const send = (obj) => { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); };

    if (msg.type === 'ping' || msg.type === 'keepalive') { send({ type: 'pong', ts: Date.now() }); return; }

    if (msg.type === 'resume') {
      const st = sessions.get(msg.sessionId);
      const afterId = Number(msg.lastEventId || 0);
      if (st) {
        for (const ev of st.events) {
          if (ev.eventId > afterId) send(ev);
        }
      }
      return;
    }

    if (msg.type === 'list_models') {
      const models = await fetchLocalModels();
      send({ requestId: msg.requestId, ok: true, models });
      return;
    }

    if (msg.type && msg.type.startsWith('fs_')) {
      try {
        if (msg.type === 'fs_list') {
          const dir = safePath(msg.path);
          const includeHidden = Boolean(msg.includeHidden);
          const dirents = fs.readdirSync(dir, { withFileTypes: true });
          const entries = dirents
            .filter((d) => includeHidden || !d.name.startsWith('.'))
            .map((d) => {
              const full = path.join(dir, d.name);
              let size = 0;
              try { if (!d.isDirectory()) size = fs.statSync(full).size; } catch {}
              return { name: d.name, path: full, isDirectory: d.isDirectory(), size };
            });
          send({ requestId: msg.requestId, ok: true, entries });
        } else if (msg.type === 'fs_read') {
          const content = fs.readFileSync(safePath(msg.path), 'utf8');
          send({ requestId: msg.requestId, ok: true, content });
        } else if (msg.type === 'fs_write') {
          const target = safePath(msg.path);
          fs.mkdirSync(path.dirname(target), { recursive: true });
          fs.writeFileSync(target, String(msg.content ?? ''), 'utf8');
          send({ requestId: msg.requestId, ok: true });
        } else if (msg.type === 'fs_mkdir') {
          fs.mkdirSync(safePath(msg.path), { recursive: true });
          send({ requestId: msg.requestId, ok: true });
        } else if (msg.type === 'fs_rename') {
          fs.renameSync(safePath(msg.oldPath), safePath(msg.newPath));
          send({ requestId: msg.requestId, ok: true });
        } else if (msg.type === 'fs_delete') {
          fs.rmSync(safePath(msg.path), { recursive: true, force: true });
          send({ requestId: msg.requestId, ok: true });
        }
      } catch (e) {
        send({ requestId: msg.requestId, ok: false, error: e.message });
      }
      return;
    }

    if (msg.type === 'pty_input') {
      ensurePty(msg.tabId || 'term-bash-1').stdin.write(String(msg.data || ''));
      return;
    }
    if (msg.type === 'pty_signal') {
      const sh = ptys.get(msg.tabId || 'term-bash-1');
      if (sh) sh.kill(msg.signal || 'SIGINT');
      return;
    }
    if (msg.type === 'pty_resize') { return; }

    if (msg.type === 'cancel_prompt') {
      const st = sessions.get(msg.sessionId);
      if (st && st.proc) { st.proc.kill('SIGINT'); st.proc = null; }
      return;
    }

    if (msg.type === 'prompt') {
      const sid = msg.sessionId || 'default';
      let st = sessions.get(sid);
      if (!st) { st = { events: [], proc: null }; sessions.set(sid, st); }
      if (st.proc) { try { st.proc.kill('SIGTERM'); } catch {} }

      const args = ['-p', String(msg.prompt || ''), '--dangerously-skip-permissions', '--output-format', 'stream-json', '--verbose'];
      if (msg.model) args.push('--model', String(msg.model));
      const procEnv = { ...process.env };
      if (msg.thinkingEnabled === false || msg.effortLevel === 'off') {
        procEnv.CLAUDE_CODE_DISABLE_THINKING = '1';
      } else if (msg.effortLevel || msg.effort) {
        procEnv.CLAUDE_CODE_EFFORT_LEVEL = String(msg.effortLevel || msg.effort);
      }
      const proc = spawn('fcc-claude', args, { cwd: WORKSPACE_ROOT, env: procEnv });
      st.proc = proc;
      broadcastSessionEvent(sid, { type: 'status', label: 'Working on project…' });

      let buf = '';
      proc.stdout.on('data', (chunk) => {
        buf += chunk.toString('utf8');
        const lines = buf.split('\n');
        buf = lines.pop() || '';
        for (const line of lines) {
          const t = line.trim();
          if (!t) continue;
          try {
            const ev = JSON.parse(t);
            if (ev.type === 'assistant' && ev.message && Array.isArray(ev.message.content)) {
              for (const b of ev.message.content) {
                if (b.type === 'thinking' && b.thinking) broadcastSessionEvent(sid, { type: 'thinking_delta', delta: b.thinking });
                else if (b.type === 'text' && b.text) broadcastSessionEvent(sid, { type: 'text_delta', delta: b.text });
                else if (b.type === 'tool_use') broadcastSessionEvent(sid, { type: 'tool_call', actionLabel: b.name || 'Tool', target: JSON.stringify(b.input || {}).slice(0, 220) });
              }
            } else if (ev.type === 'content_block_delta' && ev.delta) {
              if (ev.delta.type === 'thinking_delta' && ev.delta.thinking) broadcastSessionEvent(sid, { type: 'thinking_delta', delta: ev.delta.thinking });
              if (ev.delta.type === 'text_delta' && ev.delta.text) broadcastSessionEvent(sid, { type: 'text_delta', delta: ev.delta.text });
            } else if (ev.type === 'result' && ev.result) {
              broadcastSessionEvent(sid, { type: 'done', inputTokens: ev.usage?.input_tokens || 0, outputTokens: ev.usage?.output_tokens || 0 });
            }
          } catch {
            broadcastSessionEvent(sid, { type: 'text_delta', delta: t + '\n' });
          }
        }
      });
      proc.stderr.on('data', (d) => broadcastSessionEvent(sid, { type: 'tool_result', id: 'stderr', stdout: d.toString('utf8') }));
      proc.on('close', (code) => {
        if (buf.trim()) broadcastSessionEvent(sid, { type: 'text_delta', delta: buf });
        st.proc = null;
        if (code && code !== 0) broadcastSessionEvent(sid, { type: 'error', message: 'fcc-claude exited with code ' + code });
        else broadcastSessionEvent(sid, { type: 'done', inputTokens: 0, outputTokens: 0 });
      });
    }
  });
});

server.listen(PORT, '0.0.0.0', () => console.log('Claude Code Studio bridge listening on :' + PORT));
EOF
(node -e "require('ws')" 2>/dev/null || npm install --no-save ws) && node bridge.js"""

@Composable
fun BridgeConfigDialog(
    codespace: CodespaceInfo,
    initialConfig: BridgeConfig,
    isTesting: Boolean,
    testResult: BridgeTestResult?,
    onDismiss: () -> Unit,
    onTest: (BridgeConfig) -> Unit,
    onSaveAndConnect: (BridgeConfig) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var wsUrl by remember(initialConfig) { mutableStateOf(initialConfig.wsUrl) }
    var fccUrl by remember(initialConfig) { mutableStateOf(initialConfig.fccServerUrl) }
    var bearerSecret by remember(initialConfig) { mutableStateOf(initialConfig.bearerSecret) }

    val wsError = remember(wsUrl) { BridgeUrlValidator.validateWebSocketUrl(wsUrl) }
    val fccError = remember(fccUrl) { BridgeUrlValidator.validateHttpUrl(fccUrl) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            color = palette.surfaceElevated,
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(
                            text = "Codespace Bridge Endpoints",
                            color = palette.textPrimary,
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = codespace.displayName,
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                    }
                }

                OutlinedTextField(
                    value = wsUrl,
                    onValueChange = { wsUrl = it },
                    label = { Text("Bridge WebSocket URL (port 8765)", fontSize = 12.sp) },
                    isError = wsError != null,
                    supportingText = wsError?.let { { Text(it, color = palette.danger, fontSize = 11.sp) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.borderDefault,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )

                OutlinedTextField(
                    value = fccUrl,
                    onValueChange = { fccUrl = it },
                    label = { Text("fcc-server URL (port 8082)", fontSize = 12.sp) },
                    isError = fccError != null,
                    supportingText = fccError?.let { { Text(it, color = palette.danger, fontSize = 11.sp) } },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.borderDefault,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )

                OutlinedTextField(
                    value = bearerSecret,
                    onValueChange = { bearerSecret = it },
                    label = { Text("Optional BRIDGE_SECRET Bearer Token", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.borderDefault,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )

                if (testResult != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (testResult.success) palette.successBg else palette.dangerBg)
                            .padding(10.dp),
                    ) {
                        Text(
                            text = testResult.diagnostics,
                            color = if (testResult.success) palette.success else palette.danger,
                            fontSize = 12.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val currentConfig = BridgeConfig(
                        codespaceName = codespace.name,
                        wsUrl = wsUrl.trim(),
                        fccServerUrl = fccUrl.trim(),
                        bearerSecret = bearerSecret.trim(),
                    )
                    OutlinedButton(
                        onClick = { onTest(currentConfig) },
                        enabled = !isTesting && wsError == null && fccError == null,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        if (isTesting) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = palette.accent)
                        } else {
                            Icon(Icons.Outlined.NetworkCheck, null, tint = palette.textPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Test", color = palette.textPrimary, fontSize = 12.5.sp)
                        }
                    }

                    Button(
                        onClick = { onSaveAndConnect(currentConfig) },
                        enabled = wsError == null && fccError == null,
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = Color.White),
                    ) {
                        Text("Save & Connect", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun StudioSettingsDialog(
    settings: StudioSettings,
    availableModels: List<AiModelOption>,
    initialTab: Int = 0,
    onUpdateSettings: ((StudioSettings) -> StudioSettings) -> Unit,
    onShowMessage: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current
    var selectedSection by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    var oauthClientId by remember(settings.githubOAuthClientId) { mutableStateOf(settings.githubOAuthClientId) }
    var oauthProxyUrl by remember(settings.oauthProxyUrl) { mutableStateOf(settings.oauthProxyUrl) }
    val tabs = listOf("Appearance", "Defaults", "OAuth", "Bridge Setup")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .heightIn(max = 640.dp)
                .padding(14.dp)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            color = palette.surfaceElevated,
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.sidebar)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Studio Settings",
                        color = palette.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.sidebar)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    tabs.forEachIndexed { idx, title ->
                        val active = idx == selectedSection
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) palette.surfaceElevated else Color.Transparent)
                                .clickable { selectedSection = idx }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = title,
                                color = if (active) palette.accent else palette.textSecondary,
                                fontSize = 11.5.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                            )
                        }
                    }
                }
                HorizontalDivider(color = palette.borderDefault)

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    when (selectedSection) {
                        0 -> {
                            SettingsToggleRow(
                                title = "Warm Anthropic Dark Mode",
                                subtitle = "Toggle between Warm Charcoal Dark and Warm Cream Light",
                                checked = settings.darkMode,
                                onCheckedChange = { onUpdateSettings { s -> s.copy(darkMode = it) } },
                            )
                            SettingsToggleRow(
                                title = "Editorial Serif Chat Prose",
                                subtitle = "Render Claude's prose responses in Source Serif 4",
                                checked = settings.useSerifProse,
                                onCheckedChange = { onUpdateSettings { s -> s.copy(useSerifProse = it) } },
                            )
                            Column {
                                Text(
                                    text = "Code & Terminal Font Size: ${settings.codeFontSizeSp.toInt()}sp",
                                    color = palette.textPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                )
                                Slider(
                                    value = settings.codeFontSizeSp,
                                    onValueChange = { onUpdateSettings { s -> s.copy(codeFontSizeSp = it) } },
                                    valueRange = 11f..16f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = palette.accent,
                                        activeTrackColor = palette.accent,
                                    ),
                                )
                            }
                        }

                        1 -> {
                            Text("Default Model", color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                            val models = availableModels.ifEmpty { RealModelsCatalog.cliDefaultModels }
                            models.take(8).forEach { m ->
                                val selected = settings.defaultModelId == m.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) palette.accentSubtle else palette.surfaceSubtle)
                                        .border(1.dp, if (selected) palette.accent else palette.borderDefault, RoundedCornerShape(10.dp))
                                        .clickable { onUpdateSettings { s -> s.copy(defaultModelId = m.id) } }
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(m.displayName, color = palette.textPrimary, fontSize = 12.5.sp, fontFamily = JetBrainsMonoFontFamily)
                                    Text(m.provider, color = palette.textTertiary, fontSize = 11.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Default Thinking Effort", color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                EffortLevel.entries.forEach { eff ->
                                    val selected = settings.defaultEffort == eff
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selected) palette.accent else palette.surfaceSubtle)
                                            .clickable { onUpdateSettings { s -> s.copy(defaultEffort = eff) } }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Text(
                                            text = eff.label,
                                            color = if (selected) Color.White else palette.textSecondary,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    }
                                }
                            }
                        }

                        2 -> {
                            Text(
                                text = "GitHub OAuth Device Flow Configuration",
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            OutlinedTextField(
                                value = oauthClientId,
                                onValueChange = { oauthClientId = it },
                                label = { Text("GitHub OAuth App Client ID", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            OutlinedTextField(
                                value = oauthProxyUrl,
                                onValueChange = { oauthProxyUrl = it },
                                label = { Text("Optional Bridge /github-oauth Proxy Base URL", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Button(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            githubOAuthClientId = oauthClientId.trim(),
                                            oauthProxyUrl = oauthProxyUrl.trim(),
                                        )
                                    }
                                    onShowMessage("Saved GitHub OAuth settings.")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                            ) {
                                Text("Save OAuth Settings")
                            }
                        }

                        3 -> {
                            Text(
                                text = "Self-Contained Codespace Bridge (Port 8765)",
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = "Paste this one-liner in your GitHub Codespace terminal alongside fcc-server. It supports auto-reconnect event replay, --dangerously-skip-permissions full-auto streaming, /workspaces file CRUD, live /v1/models discovery, /github-oauth proxy, and interactive bash PTY.",
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                            )
                            Button(
                                onClick = {
                                    clipboard.setText(AnnotatedString(CODESPACE_BRIDGE_ONE_LINER))
                                    onShowMessage("Copied bridge.js one-command snippet to clipboard.")
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("copy_bridge_snippet_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = palette.accent, contentColor = Color.White),
                            ) {
                                Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Copy One-Command Snippet", fontWeight = FontWeight.SemiBold)
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.codeBlockBg)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp))
                                    .padding(10.dp),
                            ) {
                                Text(
                                    text = CODESPACE_BRIDGE_ONE_LINER,
                                    color = palette.textSecondary,
                                    fontSize = 10.5.sp,
                                    lineHeight = 15.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    val palette = LocalStudioPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = palette.textSecondary, fontSize = 11.5.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = palette.accent),
        )
    }
}

@Composable
fun CommandPaletteDialog(
    onDismiss: () -> Unit,
    onAction: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var query by remember { mutableStateOf("") }
    val actions = remember {
        listOf(
            "new_session" to "New Claude Code Session",
            "refresh_models" to "Refresh Live Models (:8082/v1/models)",
            "tab_claude" to "Switch to Claude Code Tab",
            "tab_fcc" to "Switch to FCC Admin Tab (:8082)",
            "tab_terminal" to "Switch to Embedded Terminal Tab",
            "raw_activity" to "Open Raw Activity Log",
            "toggle_inspector" to "Toggle In-App Code Editor",
            "reconnect" to "Reconnect Codespace Bridge",
            "settings" to "Open Settings & Bridge Setup",
        )
    }
    val filtered = remember(query) {
        if (query.isBlank()) actions else actions.filter { it.second.contains(query, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.borderFocused, RoundedCornerShape(14.dp)),
            shape = RoundedCornerShape(14.dp),
            color = palette.surfaceElevated,
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Outlined.Search, null, tint = palette.textSecondary) },
                    placeholder = { Text("Run command…", fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                filtered.forEach { (id, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                onDismiss()
                                onAction(id)
                            }
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                    ) {
                        Text(label, color = palette.textPrimary, fontSize = 13.sp, fontFamily = InterFontFamily)
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Close", color = palette.textSecondary)
                    }
                }
            }
        }
    }
}
