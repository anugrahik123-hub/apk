package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AttachmentType
import com.example.model.ConnectionState
import com.example.model.EffortLevel
import com.example.model.InspectorTab
import com.example.model.SidebarTab
import com.example.model.WorkspaceTab
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.viewmodel.StudioUiState

@Composable
fun WorkspaceShellScreen(
    state: StudioUiState,
    onReturnToDashboard: () -> Unit,
    onSelectWorkspaceTab: (WorkspaceTab) -> Unit,
    onSelectSidebarTab: (SidebarTab) -> Unit,
    onSelectInspectorTab: (InspectorTab) -> Unit,
    onSetLeftDrawerMobile: (Boolean) -> Unit,
    onToggleRightInspector: () -> Unit,
    onSetRawActivityDrawer: (Boolean) -> Unit,
    onClearRawActivity: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenCommandPalette: () -> Unit,
    onReconnectBridge: () -> Unit,
    // Sessions & Chat
    onNewSession: () -> Unit,
    onSelectSession: (String) -> Unit,
    onTogglePinSession: (String) -> Unit,
    onDeleteSession: (String) -> Unit,
    onComposerTextChange: (String) -> Unit,
    onSendPrompt: () -> Unit,
    onStopGeneration: () -> Unit,
    onSelectModel: (String) -> Unit,
    onAddCustomModel: (String) -> Unit,
    onRefreshModels: () -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onCompactContext: () -> Unit,
    onClearConversation: () -> Unit,
    onExportMarkdown: () -> Unit,
    onToggleThinking: (String) -> Unit,
    onAddAttachment: (AttachmentType, String, String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    // Filesystem & Editor
    onRefreshDirectory: (String) -> Unit,
    onToggleDirectory: (String) -> Unit,
    onToggleHiddenFiles: () -> Unit,
    onOpenFile: (String) -> Unit,
    onCreateFile: (String, String) -> Unit,
    onCreateFolder: (String, String) -> Unit,
    onRenameEntry: (String, String) -> Unit,
    onDeleteEntry: (String) -> Unit,
    onInsertPathIntoChat: (String) -> Unit,
    onOpenBridgeSetup: () -> Unit,
    onUpdateEditorContent: (String) -> Unit,
    onSaveEditorFile: () -> Unit,
    // FCC Server
    onStartFccServer: () -> Unit,
    onStopFccServer: () -> Unit,
    onReloadFccWebView: () -> Unit,
    // Terminal
    onSelectTerminalTab: (String) -> Unit,
    onAddTerminalTab: () -> Unit,
    onCloseTerminalTab: (String) -> Unit,
    onRunTerminalCommand: (String) -> Unit,
    onSendTerminalSigInt: () -> Unit,
    onClearTerminal: () -> Unit,
    onResizeTerminal: (Int, Int) -> Unit,
    onShowMessage: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current

    BackHandler(enabled = state.showLeftDrawerMobile || state.showRightInspector || state.showRawActivityDrawer) {
        when {
            state.showRawActivityDrawer -> onSetRawActivityDrawer(false)
            state.showLeftDrawerMobile -> onSetLeftDrawerMobile(false)
            state.showRightInspector -> onToggleRightInspector()
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        val isExpanded = maxWidth >= 840.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // Top Workspace Header
            WorkspaceTopBar(
                codespaceName = state.activeCodespace?.displayName ?: "Codespace",
                connectionState = state.connectionState,
                isWakeLockActive = state.isWakeLockActive,
                activeTab = state.activeWorkspaceTab,
                rawActivityCount = state.rawActivityLog.size,
                isExpanded = isExpanded,
                onBack = onReturnToDashboard,
                onToggleMenu = { onSetLeftDrawerMobile(!state.showLeftDrawerMobile) },
                onSelectTab = onSelectWorkspaceTab,
                onReconnect = onReconnectBridge,
                onOpenRawActivity = { onSetRawActivityDrawer(true) },
                onToggleInspector = onToggleRightInspector,
                onOpenCommandPalette = onOpenCommandPalette,
                onOpenSettings = onOpenSettings,
            )
            HorizontalDivider(color = palette.borderDefault)

            // Main Workspace Body
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    if (isExpanded) {
                        LeftWorkspaceSidebar(
                            activeTab = state.activeSidebarTab,
                            sessions = state.sessions,
                            activeSessionId = state.activeSessionId,
                            fsRootPath = state.fsRootPath,
                            fsEntriesByDir = state.fsEntriesByDir,
                            fsExpandedDirs = state.fsExpandedDirs,
                            fsLoadingDirs = state.fsLoadingDirs,
                            fsError = state.fsError,
                            fsNeedsBridgeUpgrade = state.fsNeedsBridgeUpgrade,
                            showHiddenFiles = state.settings.showHiddenFiles,
                            activeEditorPath = state.editorDoc.path,
                            onSelectTab = onSelectSidebarTab,
                            onNewSession = onNewSession,
                            onSelectSession = onSelectSession,
                            onTogglePinSession = onTogglePinSession,
                            onDeleteSession = onDeleteSession,
                            onRefreshDirectory = onRefreshDirectory,
                            onToggleDirectory = onToggleDirectory,
                            onToggleHiddenFiles = onToggleHiddenFiles,
                            onOpenFile = onOpenFile,
                            onCreateFile = onCreateFile,
                            onCreateFolder = onCreateFolder,
                            onRenameEntry = onRenameEntry,
                            onDeleteEntry = onDeleteEntry,
                            onInsertPathIntoChat = onInsertPathIntoChat,
                            onOpenBridgeSetup = onOpenBridgeSetup,
                            modifier = Modifier.width(276.dp),
                        )
                        VerticalDivider(color = palette.borderDefault)
                    }

                    // Active Center Pane (Claude Code / FCC Admin / Native Terminal)
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when (state.activeWorkspaceTab) {
                            WorkspaceTab.ClaudeCode -> ClaudeCodeView(
                                session = state.activeSession,
                                availableModels = state.availableModels,
                                isRefreshingModels = state.isRefreshingModels,
                                selectedModel = state.selectedModel,
                                selectedEffort = state.selectedEffort,
                                composerText = state.composerText,
                                pendingAttachments = state.pendingAttachments,
                                knownFiles = state.allKnownFiles,
                                isStreaming = state.isAssistantStreaming,
                                useSerifProse = state.settings.useSerifProse,
                                codeFontSizeSp = state.settings.codeFontSizeSp,
                                onComposerTextChange = onComposerTextChange,
                                onSendPrompt = onSendPrompt,
                                onStopGeneration = onStopGeneration,
                                onSelectModel = onSelectModel,
                                onAddCustomModel = onAddCustomModel,
                                onRefreshModels = onRefreshModels,
                                onSelectEffort = onSelectEffort,
                                onCompactContext = onCompactContext,
                                onClearConversation = onClearConversation,
                                onExportMarkdown = onExportMarkdown,
                                onToggleThinking = onToggleThinking,
                                onAddAttachment = onAddAttachment,
                                onRemoveAttachment = onRemoveAttachment,
                                onShowMessage = onShowMessage,
                            )

                            WorkspaceTab.FccAdmin -> FccAdminView(
                                fccServerUrl = state.activeBridgeConfig.fccServerUrl,
                                fccServerStatus = state.fccServerStatus,
                                availableModels = state.availableModels,
                                selectedModel = state.selectedModel,
                                selectedEffort = state.selectedEffort,
                                isRefreshingModels = state.isRefreshingModels,
                                reloadNonce = state.fccWebViewReloadNonce,
                                onSelectModel = onSelectModel,
                                onSelectEffort = onSelectEffort,
                                onStartFccServer = onStartFccServer,
                                onStopFccServer = onStopFccServer,
                                onReloadWebView = onReloadFccWebView,
                                onRefreshModels = onRefreshModels,
                            )

                            WorkspaceTab.Terminal -> TerminalView(
                                tabs = state.terminalTabs,
                                activeTabId = state.activeTerminalTabId,
                                codeFontSizeSp = state.settings.codeFontSizeSp,
                                onSelectTab = onSelectTerminalTab,
                                onAddTab = onAddTerminalTab,
                                onCloseTab = onCloseTerminalTab,
                                onRunCommand = onRunTerminalCommand,
                                onSendSigInt = onSendTerminalSigInt,
                                onClearTerminal = onClearTerminal,
                                onResizeTerminal = onResizeTerminal,
                            )
                        }
                    }

                    // Right Inspector (Built-in Code & Text Editor + Changes) on wide screens
                    if (isExpanded && state.showRightInspector) {
                        VerticalDivider(color = palette.borderDefault)
                        RightInspectorPanel(
                            activeTab = state.activeInspectorTab,
                            editorDoc = state.editorDoc,
                            fileChanges = state.activeSession?.fileChanges.orEmpty(),
                            codeFontSizeSp = state.settings.codeFontSizeSp,
                            onSelectTab = onSelectInspectorTab,
                            onUpdateEditorContent = onUpdateEditorContent,
                            onSaveEditorFile = onSaveEditorFile,
                            onInsertEditorPathIntoChat = onInsertPathIntoChat,
                            onClose = onToggleRightInspector,
                            modifier = Modifier.width(380.dp),
                        )
                    }
                }

                // Compact / Phone Left Overlay Drawer (Sessions & Real File Explorer)
                if (!isExpanded && state.showLeftDrawerMobile) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f))
                            .clickable { onSetLeftDrawerMobile(false) },
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(304.dp)
                                .clickable(enabled = false) {},
                            color = palette.sidebar,
                        ) {
                            LeftWorkspaceSidebar(
                                activeTab = state.activeSidebarTab,
                                sessions = state.sessions,
                                activeSessionId = state.activeSessionId,
                                fsRootPath = state.fsRootPath,
                                fsEntriesByDir = state.fsEntriesByDir,
                                fsExpandedDirs = state.fsExpandedDirs,
                                fsLoadingDirs = state.fsLoadingDirs,
                                fsError = state.fsError,
                                fsNeedsBridgeUpgrade = state.fsNeedsBridgeUpgrade,
                                showHiddenFiles = state.settings.showHiddenFiles,
                                activeEditorPath = state.editorDoc.path,
                                onSelectTab = onSelectSidebarTab,
                                onNewSession = onNewSession,
                                onSelectSession = onSelectSession,
                                onTogglePinSession = onTogglePinSession,
                                onDeleteSession = onDeleteSession,
                                onRefreshDirectory = onRefreshDirectory,
                                onToggleDirectory = onToggleDirectory,
                                onToggleHiddenFiles = onToggleHiddenFiles,
                                onOpenFile = onOpenFile,
                                onCreateFile = onCreateFile,
                                onCreateFolder = onCreateFolder,
                                onRenameEntry = onRenameEntry,
                                onDeleteEntry = onDeleteEntry,
                                onInsertPathIntoChat = onInsertPathIntoChat,
                                onOpenBridgeSetup = onOpenBridgeSetup,
                            )
                        }
                    }
                }

                // Compact / Phone Right Overlay Editor / Inspector
                if (!isExpanded && state.showRightInspector) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = palette.sidebar,
                    ) {
                        RightInspectorPanel(
                            activeTab = state.activeInspectorTab,
                            editorDoc = state.editorDoc,
                            fileChanges = state.activeSession?.fileChanges.orEmpty(),
                            codeFontSizeSp = state.settings.codeFontSizeSp,
                            onSelectTab = onSelectInspectorTab,
                            onUpdateEditorContent = onUpdateEditorContent,
                            onSaveEditorFile = onSaveEditorFile,
                            onInsertEditorPathIntoChat = onInsertPathIntoChat,
                            onClose = onToggleRightInspector,
                        )
                    }
                }
            }
        }
    }

    if (state.showRawActivityDrawer) {
        RawActivityDrawerDialog(
            entries = state.rawActivityLog,
            onClear = onClearRawActivity,
            onDismiss = { onSetRawActivityDrawer(false) },
        )
    }
}

@Composable
private fun WorkspaceTopBar(
    codespaceName: String,
    connectionState: ConnectionState,
    isWakeLockActive: Boolean,
    activeTab: WorkspaceTab,
    rawActivityCount: Int,
    isExpanded: Boolean,
    onBack: () -> Unit,
    onToggleMenu: () -> Unit,
    onSelectTab: (WorkspaceTab) -> Unit,
    onReconnect: () -> Unit,
    onOpenRawActivity: () -> Unit,
    onToggleInspector: () -> Unit,
    onOpenCommandPalette: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val (connColor, connBg, pulsing) = when (connectionState) {
        ConnectionState.Connected -> Triple(palette.success, palette.successBg, false)
        ConnectionState.Connecting, ConnectionState.Reconnecting -> Triple(palette.warning, palette.warningBg, true)
        ConnectionState.Disconnected -> Triple(palette.danger, palette.dangerBg, false)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.sidebar),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                if (!isExpanded) {
                    IconButton(
                        onClick = onToggleMenu,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("workspace_menu_button"),
                    ) {
                        Icon(Icons.Outlined.Menu, contentDescription = "Open sidebar", tint = palette.textSecondary, modifier = Modifier.size(20.dp))
                    }
                } else {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("workspace_back_button"),
                    ) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back to Codespaces", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
                    }
                }

                ClaudeSparkleEmblem(size = 18.dp, tint = palette.accent)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = codespaceName,
                    color = palette.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = JetBrainsMonoFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(modifier = Modifier.width(8.dp))

                // Subtle non-blocking Reconnecting… / Connected status pill (tappable to reconnect)
                StudioPillBadge(
                    text = connectionState.label,
                    textColor = connColor,
                    backgroundColor = connBg,
                    leadingDotColor = connColor,
                    pulsingDot = pulsing,
                    modifier = Modifier
                        .clickable {
                            if (connectionState != ConnectionState.Connected) onReconnect()
                        }
                        .testTag("connection_status_pill"),
                )

                if (isWakeLockActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    StudioPillBadge(
                        text = "Awake",
                        textColor = palette.accent,
                        backgroundColor = palette.accentSubtle,
                        leadingDotColor = palette.accent,
                        pulsingDot = true,
                        modifier = Modifier.testTag("screen_wakelock_badge"),
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenRawActivity,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("raw_activity_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ReceiptLong,
                        contentDescription = "Raw Activity ($rawActivityCount)",
                        tint = if (rawActivityCount > 0) palette.accent else palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onToggleInspector,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("toggle_editor_inspector_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Code,
                        contentDescription = "Toggle code editor",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onOpenCommandPalette,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("command_palette_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Command palette",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("workspace_settings_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings & Bridge setup",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }

        // Unified In-App Workspace Tabs: Claude Code | FCC Admin | Terminal
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            WorkspaceTab.entries.forEach { tab ->
                val selected = tab == activeTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) palette.surfaceElevated else Color.Transparent)
                        .border(
                            1.dp,
                            if (selected) palette.borderFocused else Color.Transparent,
                            RoundedCornerShape(8.dp),
                        )
                        .clickable { onSelectTab(tab) }
                        .padding(vertical = 7.dp)
                        .testTag("workspace_tab_${tab.name.lowercase()}"),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = tab.label,
                        color = if (selected) palette.accent else palette.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        fontFamily = InterFontFamily,
                    )
                }
            }
        }
    }
}
