package com.example.model

import com.squareup.moshi.JsonClass

enum class AppScreen {
    Login,
    Dashboard,
    Workspace,
}

enum class WorkspaceTab(val label: String) {
    ClaudeCode("Claude Code"),
    FccAdmin("FCC Admin"),
    Terminal("Terminal"),
}

enum class SidebarTab(val label: String) {
    Sessions("Sessions"),
    Files("Files"),
}

enum class InspectorTab(val label: String) {
    Editor("Editor"),
    Changes("Changes"),
}

enum class CodespaceStatus(val label: String) {
    Available("Available"),
    Starting("Starting"),
    Shutdown("Shutdown"),
    Rebuilding("Rebuilding"),
}

enum class ConnectionState(val label: String) {
    Disconnected("Disconnected"),
    Connecting("Connecting…"),
    Connected("Connected"),
    Reconnecting("Reconnecting…"),
}

@JsonClass(generateAdapter = true)
data class CodespaceInfo(
    val id: String,
    val name: String,
    val displayName: String,
    val repoFullName: String,
    val branch: String,
    val machineSpecs: String,
    val region: String,
    val lastUsed: String,
    val status: CodespaceStatus,
)

@JsonClass(generateAdapter = true)
data class BridgeConfig(
    val codespaceName: String,
    val wsUrl: String,
    val fccServerUrl: String,
    val bearerSecret: String = "",
)

data class BridgeTestResult(
    val success: Boolean,
    val wsLatencyMs: Long?,
    val fccLatencyMs: Long?,
    val diagnostics: String,
)

enum class ModelProviderGroup(val label: String) {
    FccRouter("FCC Admin / Live Models (:8082)"),
    Claude("Standard Claude Models"),
    Custom("Custom Model Aliases"),
}

data class AiModelOption(
    val id: String,
    val displayName: String,
    val provider: String,
    val group: ModelProviderGroup,
    val contextWindowK: Int = 200,
)

enum class EffortLevel(
    val cliValue: String,
    val label: String,
    val subtitle: String,
    val bars: Int,
    val thinkingEnabled: Boolean,
) {
    Off("off", "Off", "Standard response (no extended thinking)", 0, false),
    Low("low", "Low", "Light reasoning budget", 1, true),
    Medium("medium", "Medium", "Balanced reasoning", 2, true),
    High("high", "High", "Deep multi-step reasoning", 3, true),
    Ultracode("max", "Ultracode", "Max reasoning effort", 4, true),
}

enum class DiffLineType {
    Context,
    Added,
    Removed,
}

@JsonClass(generateAdapter = true)
data class DiffLine(
    val type: DiffLineType,
    val oldLine: Int?,
    val newLine: Int?,
    val text: String,
)

enum class AttachmentType {
    File,
    Image,
}

@JsonClass(generateAdapter = true)
data class ContextAttachment(
    val id: String,
    val type: AttachmentType,
    val label: String,
    val pathOrUri: String,
)

enum class MessageRole {
    User,
    Assistant,
}

@JsonClass(generateAdapter = true)
data class RawActivityEntry(
    val id: String,
    val timestampMs: Long,
    val kind: String, // "tool_call", "tool_result", "cli", "bridge"
    val label: String,
    val detail: String,
)

@JsonClass(generateAdapter = true)
data class ChatMessage(
    val id: String,
    val role: MessageRole,
    val text: String,
    val timestampMs: Long,
    val startedAtMs: Long = timestampMs,
    val elapsedMs: Long? = null, // Frozen permanently when turn finishes
    val attachments: List<ContextAttachment> = emptyList(),
    val thinkingText: String = "",
    val isThinkingExpanded: Boolean = false,
    val isStreaming: Boolean = false,
    val liveStatusLabel: String = "",
    val inputTokens: Int = 0,
    val outputTokens: Int = 0,
)

@JsonClass(generateAdapter = true)
data class ContextBreakdown(
    val systemTokens: Int = 0,
    val filesTokens: Int = 0,
    val messagesTokens: Int = 0,
    val toolOutputTokens: Int = 0,
    val maxTokens: Int = 200_000,
) {
    val totalTokens: Int
        get() = systemTokens + filesTokens + messagesTokens + toolOutputTokens

    val usageFraction: Float
        get() = if (maxTokens <= 0) 0f else (totalTokens.toFloat() / maxTokens.toFloat()).coerceIn(0f, 1f)

    val usagePercent: Int
        get() = (usageFraction * 100f).toInt()
}

@JsonClass(generateAdapter = true)
data class FileDiffEntry(
    val path: String,
    val addedCount: Int,
    val removedCount: Int,
    val diffLines: List<DiffLine>,
)

@JsonClass(generateAdapter = true)
data class ChatSession(
    val id: String,
    val title: String,
    val group: String,
    val modelId: String,
    val isPinned: Boolean = false,
    val updatedAtMs: Long,
    val messages: List<ChatMessage> = emptyList(),
    val contextBreakdown: ContextBreakdown = ContextBreakdown(),
    val fileChanges: List<FileDiffEntry> = emptyList(),
)

data class FsEntry(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long = 0L,
    val isHidden: Boolean = name.startsWith("."),
)

data class EditorDocumentState(
    val path: String = "",
    val originalContent: String = "",
    val currentContent: String = "",
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val error: String? = null,
) {
    val isDirty: Boolean
        get() = path.isNotEmpty() && currentContent != originalContent
}

enum class FccServerStatus(val label: String) {
    Running("Running on :8082"),
    Starting("Starting…"),
    Stopped("Stopped"),
    Unknown("Checking…"),
}

enum class AnsiColorRole {
    Default,
    Accent,
    Green,
    Red,
    Amber,
    Blue,
    Cyan,
    Magenta,
    Muted,
    Bold,
}

data class AnsiSegment(
    val text: String,
    val colorRole: AnsiColorRole = AnsiColorRole.Default,
    val clickableFilePath: String? = null,
)

data class TerminalLine(
    val id: String,
    val segments: List<AnsiSegment>,
)

data class TerminalTabSession(
    val id: String,
    val title: String,
    val cwd: String = "/workspaces",
    val lines: List<TerminalLine> = emptyList(),
    val commandHistory: List<String> = emptyList(),
)

data class DeviceOAuthFlowState(
    val deviceCode: String = "",
    val userCode: String = "",
    val verificationUri: String = "https://github.com/login/device",
    val expiresInSec: Int = 900,
    val intervalSec: Int = 5,
    val isPolling: Boolean = false,
    val statusText: String = "",
    val showInAppWebView: Boolean = false,
)

@JsonClass(generateAdapter = true)
data class StudioSettings(
    val darkMode: Boolean = true,
    val useSerifProse: Boolean = false,
    val codeFontSizeSp: Float = 12.5f,
    val defaultModelId: String = "claude-sonnet-4-6",
    val defaultEffort: EffortLevel = EffortLevel.High,
    val githubOAuthClientId: String = "Ov23liClaudeCodeStudio",
    val oauthProxyUrl: String = "",
    val showHiddenFiles: Boolean = false,
    val customModelIds: List<String> = emptyList(),
)

object RealModelsCatalog {
    val cliDefaultModels: List<AiModelOption> = listOf(
        AiModelOption(
            id = "claude-sonnet-4-6",
            displayName = "claude-sonnet-4-6",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            contextWindowK = 200,
        ),
        AiModelOption(
            id = "claude-opus-4-6",
            displayName = "claude-opus-4-6",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            contextWindowK = 200,
        ),
        AiModelOption(
            id = "claude-haiku-4-5",
            displayName = "claude-haiku-4-5",
            provider = "Anthropic",
            group = ModelProviderGroup.Claude,
            contextWindowK = 200,
        ),
    )

    fun defaultBridgeConfig(codespaceName: String): BridgeConfig = BridgeConfig(
        codespaceName = codespaceName,
        wsUrl = "wss://$codespaceName-8765.app.github.dev",
        fccServerUrl = "https://$codespaceName-8082.app.github.dev",
        bearerSecret = "",
    )
}

/**
 * Shared human-readable elapsed duration formatter:
 * - Under 60s -> "42s"
 * - 60s and over -> "1m 2s", "4m 18s"
 */
fun formatElapsedDuration(elapsedMs: Long): String {
    val totalSeconds = (elapsedMs.coerceAtLeast(0L)) / 1000L
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return if (minutes > 0L) {
        "${minutes}m ${seconds}s"
    } else {
        "${seconds}s"
    }
}
