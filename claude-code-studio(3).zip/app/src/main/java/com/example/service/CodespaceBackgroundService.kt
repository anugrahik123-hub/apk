package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.LiveCodespaceBridgeService

/**
 * Process-scoped holder for LiveCodespaceBridgeService so the WebSocket, 5-second ping heartbeat,
 * and 2-minute Codespace keep-alive survive Activity pause/minimization without resetting.
 */
object BridgeServiceHolder {
    val liveBridge: LiveCodespaceBridgeService by lazy { LiveCodespaceBridgeService() }
}

/**
 * Compliant Android Foreground Service (foregroundServiceType="dataSync") that keeps the
 * Codespace WebSocket session, 5s heartbeat, and active builds/Claude turns running reliably
 * when the user minimizes the app or switches to another app.
 */
class CodespaceBackgroundService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                releaseCpuWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, ACTION_UPDATE -> {
                val codespaceName = intent.getStringExtra(EXTRA_CODESPACE_NAME).orEmpty().ifBlank { "Codespace" }
                val isWorking = intent.getBooleanExtra(EXTRA_IS_WORKING, false)
                val notification = buildNotification(codespaceName, isWorking)

                runCatching {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(
                            NOTIFICATION_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, notification)
                    }
                }

                if (isWorking) {
                    acquireCpuWakeLock()
                } else {
                    releaseCpuWakeLock()
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        releaseCpuWakeLock()
        super.onDestroy()
    }

    private fun acquireCpuWakeLock() {
        runCatching {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "ClaudeCodeStudio::ActiveCodespaceTask",
                ).apply { setReferenceCounted(false) }
            }
            if (wakeLock?.isHeld != true) {
                // Guarded 4-hour max timeout matching extended 240-minute Codespace idle timeout
                wakeLock?.acquire(4L * 60L * 60L * 1000L)
            }
        }
    }

    private fun releaseCpuWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val existing = nm.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Codespace Active Session",
                    NotificationManager.IMPORTANCE_LOW,
                ).apply {
                    description = "Keeps your Codespace WebSocket and active Claude Code tasks alive in the background."
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(codespaceName: String, isWorking: Boolean): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val statusLine = if (isWorking) {
            "Task running on $codespaceName • Keep-alive active"
        } else {
            "Connected to $codespaceName • Background sync active"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Claude Code Studio")
            .setContentText(statusLine)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingOpen)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "codespace_background_sync"
        private const val NOTIFICATION_ID = 42087
        private const val ACTION_START = "com.example.action.START_CODESPACE_BG"
        private const val ACTION_UPDATE = "com.example.action.UPDATE_CODESPACE_BG"
        private const val ACTION_STOP = "com.example.action.STOP_CODESPACE_BG"
        private const val EXTRA_CODESPACE_NAME = "extra_codespace_name"
        private const val EXTRA_IS_WORKING = "extra_is_working"

        fun startOrUpdate(context: Context, codespaceName: String, isWorking: Boolean) {
            val intent = Intent(context, CodespaceBackgroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_CODESPACE_NAME, codespaceName)
                putExtra(EXTRA_IS_WORKING, isWorking)
            }
            runCatching {
                ContextCompat.startForegroundService(context, intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, CodespaceBackgroundService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching {
                context.stopService(intent)
            }
        }
    }
}
