package com.example.data

import com.example.model.AiModelOption
import com.example.model.AnsiColorRole
import com.example.model.AnsiSegment
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.ConnectionState
import com.example.model.EffortLevel
import com.example.model.FsEntry
import com.example.model.ModelProviderGroup
import com.example.model.RealModelsCatalog
import com.example.model.TerminalLine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

sealed interface BridgeIncomingEvent {
    val eventId: Long?

    data class ThinkingDelta(val sessionId: String, val delta: String, override val eventId: Long?) : BridgeIncomingEvent
    data class TextDelta(val sessionId: String, val delta: String, override val eventId: Long?) : BridgeIncomingEvent
    data class StatusUpdate(val sessionId: String, val label: String, override val eventId: Long?) : BridgeIncomingEvent
    data class RawActivity(val sessionId: String, val kind: String, val label: String, val detail: String, override val eventId: Long?) : BridgeIncomingEvent
    data class Done(val sessionId: String, val inputTokens: Int, val outputTokens: Int, override val eventId: Long?) : BridgeIncomingEvent
    data class Error(val sessionId: String, val message: String, override val eventId: Long?) : BridgeIncomingEvent
}

data class TerminalOutputEvent(
    val tabId: String,
    val lines: List<TerminalLine>,
)

object BridgeUrlValidator {
    fun validateWebSocketUrl(url: String): String? {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return "WebSocket URL is required."
        if (!trimmed.startsWith("wss://") && !trimmed.startsWith("ws://")) {
            return "WebSocket URL must start with wss:// or ws://."
        }
        val httpEquiv = trimmed.replaceFirst("wss://", "https://").replaceFirst("ws://", "http://")
        if (httpEquiv.toHttpUrlOrNull() == null) return "Invalid WebSocket URL format."
        return null
    }

    fun validateHttpUrl(url: String): String? {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return "URL is required."
        if (!trimmed.startsWith("https://") && !trimmed.startsWith("http://")) {
            return "URL must start with https:// or http://."
        }
        if (trimmed.toHttpUrlOrNull() == null) return "Invalid URL format."
        return null
    }
}

/**
 * Real auto-reconnecting Codespace WebSocket + HTTP Bridge Client.
 *
 * Features:
 * - Zero-reset exponential backoff reconnection (500ms -> 1s -> 2s -> 4s -> max 5s)
 * - 10-second ping/pong heartbeat
 * - Persistent event replay via { type: "resume", sessionId, lastEventId }
 * - Always full-auto execution (autoApprove: true, permissionMode: "bypassPermissions")
 * - Full real filesystem RPCs (fs_list, fs_read, fs_write, fs_mkdir, fs_rename, fs_delete)
 * - Dynamic model listing via GET :8082/v1/models with WebSocket { type: "list_models" } fallback
 * - Real ANSI-parsed PTY streaming (pty_input, pty_output, pty_resize, pty_signal)
 */
class LiveCodespaceBridgeService {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _connectionState = MutableStateFlow(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _lastConnectionError = MutableStateFlow<String?>(null)
    val lastConnectionError: StateFlow<String?> = _lastConnectionError.asStateFlow()

    private val _streamEvents = MutableSharedFlow<BridgeIncomingEvent>(extraBufferCapacity = 512)
    val streamEvents: SharedFlow<BridgeIncomingEvent> = _streamEvents.asSharedFlow()

    private val _terminalOutputEvents = MutableSharedFlow<TerminalOutputEvent>(extraBufferCapacity = 256)
    val terminalOutputEvents: SharedFlow<TerminalOutputEvent> = _terminalOutputEvents.asSharedFlow()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var activeConfig: BridgeConfig? = null

    @Volatile
    private var activeSocket: WebSocket? = null

    @Volatile
    private var isSocketOpen: Boolean = false

    @Volatile
    private var shouldStayConnected: Boolean = false

    @Volatile
    private var currentSessionId: String = ""

    private val lastEventId = AtomicLong(0L)

    @Volatile
    private var lastPongAtMs: Long = 0L

    private var reconnectJob: Job? = null
    private var heartbeatJob: Job? = null
    private var backoffMs: Long = 500L

    private val pendingRpc = ConcurrentHashMap<String, CompletableDeferred<JSONObject>>()

    fun setActiveSessionForResume(sessionId: String, resetEventCursor: Boolean = false) {
        currentSessionId = sessionId
        if (resetEventCursor) {
            lastEventId.set(0L)
        }
    }

    fun connect(config: BridgeConfig) {
        val urlErr = BridgeUrlValidator.validateWebSocketUrl(config.wsUrl)
        if (urlErr != null) {
            shouldStayConnected = false
            _connectionState.value = ConnectionState.Disconnected
            _lastConnectionError.value = urlErr
            return
        }
        activeConfig = config
        shouldStayConnected = true
        backoffMs = 500L
        reconnectJob?.cancel()
        openSocket(config, isReconnect = false)
    }

    fun disconnect() {
        shouldStayConnected = false
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        isSocketOpen = false
        val previous = activeSocket
        activeSocket = null
        previous?.close(1000, "Client disconnected")
        _connectionState.value = ConnectionState.Disconnected
        pendingRpc.values.forEach { it.cancel() }
        pendingRpc.clear()
    }

    private fun openSocket(config: BridgeConfig, isReconnect: Boolean) {
        val prev = activeSocket
        activeSocket = null
        prev?.close(1000, "Reconnecting")
        isSocketOpen = false

        _connectionState.value = if (isReconnect) ConnectionState.Reconnecting else ConnectionState.Connecting

        val reqBuilder = Request.Builder().url(config.wsUrl.trim())
        if (config.bearerSecret.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer ${config.bearerSecret.trim()}")
        }

        lateinit var socketRef: WebSocket
        socketRef = client.newWebSocket(
            reqBuilder.build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = true
                    backoffMs = 500L
                    lastPongAtMs = System.currentTimeMillis()
                    _connectionState.value = ConnectionState.Connected
                    _lastConnectionError.value = null
                    startHeartbeat(webSocket)

                    // Immediately resume & replay missed events without resetting active chat state!
                    val sid = currentSessionId
                    if (sid.isNotBlank()) {
                        sendRawJson(
                            JSONObject()
                                .put("type", "resume")
                                .put("sessionId", sid)
                                .put("lastEventId", lastEventId.get()),
                        )
                    }
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (activeSocket !== webSocket) return
                    lastPongAtMs = System.currentTimeMillis()
                    handleIncomingMessage(text)
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = false
                    activeSocket = null
                    heartbeatJob?.cancel()
                    scheduleReconnect("Bridge closed (${reason.ifBlank { "code $code" }}).")
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = false
                    activeSocket = null
                    heartbeatJob?.cancel()
                    val codeHint = response?.code?.let { code ->
                        when (code) {
                            401, 403 -> "HTTP $code (Check Bearer secret or port 8765 visibility)"
                            404, 502, 503 -> "HTTP $code (Start bridge.js on port 8765)"
                            else -> "HTTP $code"
                        }
                    } ?: (t.localizedMessage ?: "Network interrupted")
                    scheduleReconnect(codeHint)
                }
            },
        )
        activeSocket = socketRef
    }

    private fun startHeartbeat(socket: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && activeSocket === socket && isSocketOpen) {
                delay(10_000L)
                if (!isSocketOpen || activeSocket !== socket) break
                val staleMs = System.currentTimeMillis() - lastPongAtMs
                if (staleMs > 25_000L) {
                    socket.cancel()
                    break
                }
                sendRawJson(JSONObject().put("type", "ping").put("ts", System.currentTimeMillis()))
            }
        }
    }

    private fun scheduleReconnect(reason: String) {
        _lastConnectionError.value = reason
        if (!shouldStayConnected) {
            _connectionState.value = ConnectionState.Disconnected
            return
        }
        val cfg = activeConfig ?: return
        _connectionState.value = ConnectionState.Reconnecting
        val waitMs = backoffMs
        backoffMs = (backoffMs * 2L).coerceAtMost(5_000L)
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(waitMs)
            if (shouldStayConnected) {
                openSocket(cfg, isReconnect = true)
            }
        }
    }

    private fun handleIncomingMessage(raw: String) {
        val trimmed = raw.trimStart()
        if (!trimmed.startsWith("{")) {
            if (raw.isNotBlank() && currentSessionId.isNotBlank()) {
                _streamEvents.tryEmit(BridgeIncomingEvent.TextDelta(currentSessionId, raw, null))
            }
            return
        }
        runCatching {
            val json = JSONObject(trimmed)
            val requestId = json.optString("requestId")
            if (requestId.isNotBlank() && pendingRpc.containsKey(requestId)) {
                pendingRpc.remove(requestId)?.complete(json)
                return
            }

            val evId = if (json.has("eventId")) json.optLong("eventId") else null
            if (evId != null && evId > 0L) {
                lastEventId.accumulateAndGet(evId) { cur, next -> maxOf(cur, next) }
            }

            val sessionId = json.optString("sessionId").ifBlank { currentSessionId }
            when (json.optString("type")) {
                "pong" -> lastPongAtMs = System.currentTimeMillis()
                "pty_output" -> emitPtyOutput(json)
                "thinking_delta" -> {
                    val delta = json.optString("delta")
                    if (delta.isNotEmpty()) {
                        _streamEvents.tryEmit(BridgeIncomingEvent.ThinkingDelta(sessionId, delta, evId))
                    }
                }
                "text_delta" -> {
                    val delta = json.optString("delta")
                    if (delta.isNotEmpty()) {
                        _streamEvents.tryEmit(BridgeIncomingEvent.TextDelta(sessionId, delta, evId))
                    }
                }
                "status" -> {
                    val label = json.optString("label", "Working on project…")
                    _streamEvents.tryEmit(BridgeIncomingEvent.StatusUpdate(sessionId, label, evId))
                }
                "tool_call" -> {
                    val action = json.optString("actionLabel", json.optString("toolType", "Tool"))
                    val target = json.optString("target")
                    _streamEvents.tryEmit(
                        BridgeIncomingEvent.RawActivity(sessionId, "tool_call", action, target, evId),
                    )
                    _streamEvents.tryEmit(
                        BridgeIncomingEvent.StatusUpdate(sessionId, "Working on project…", evId),
                    )
                }
                "tool_result" -> {
                    val stdout = json.optString("stdout")
                    val id = json.optString("id")
                    _streamEvents.tryEmit(
                        BridgeIncomingEvent.RawActivity(sessionId, "tool_result", "Result $id", stdout, evId),
                    )
                }
                "done" -> {
                    _streamEvents.tryEmit(
                        BridgeIncomingEvent.Done(
                            sessionId = sessionId,
                            inputTokens = json.optInt("inputTokens", 0),
                            outputTokens = json.optInt("outputTokens", 0),
                            eventId = evId,
                        ),
                    )
                }
                "error" -> {
                    _streamEvents.tryEmit(
                        BridgeIncomingEvent.Error(
                            sessionId = sessionId,
                            message = json.optString("message", "Bridge error"),
                            eventId = evId,
                        ),
                    )
                }
            }
        }
    }

    private fun emitPtyOutput(json: JSONObject) {
        val tabId = json.optString("tabId").ifBlank { "term-bash-1" }
        val stream = json.optString("stream", "stdout")
        val rawData = json.optString("data")
        if (rawData.isEmpty()) return

        val normalized = rawData.replace("\r\n", "\n").replace("\r", "\n")
        val textLines = normalized.split("\n").let { list ->
            if (list.lastOrNull()?.isEmpty() == true) list.dropLast(1) else list
        }
        val defaultRole = if (stream == "stderr") AnsiColorRole.Red else AnsiColorRole.Default
        val parsed = textLines.map { line ->
            TerminalLine(
                id = "pty-${UUID.randomUUID().toString().take(8)}",
                segments = parseAnsiLine(line, defaultRole),
            )
        }
        if (parsed.isNotEmpty()) {
            _terminalOutputEvents.tryEmit(TerminalOutputEvent(tabId, parsed))
        }
    }

    private fun sendRawJson(payload: JSONObject): Boolean {
        val socket = activeSocket
        if (socket == null || !isSocketOpen) return false
        return socket.send(payload.toString())
    }

    private suspend fun sendRpc(payload: JSONObject, timeoutMs: Long = 10_000L): Result<JSONObject> {
        val reqId = "rpc-${UUID.randomUUID().toString().take(10)}"
        val deferred = CompletableDeferred<JSONObject>()
        pendingRpc[reqId] = deferred
        payload.put("requestId", reqId)
        val sent = sendRawJson(payload)
        if (!sent) {
            pendingRpc.remove(reqId)
            return Result.failure(
                IllegalStateException(
                    _lastConnectionError.value ?: "Bridge WebSocket is not connected. Start bridge.js on port 8765.",
                ),
            )
        }
        val response = withTimeoutOrNull(timeoutMs) { deferred.await() }
        pendingRpc.remove(reqId)
        if (response == null) {
            return Result.failure(IllegalStateException("Timed out waiting for Codespace bridge response."))
        }
        if (response.optBoolean("ok", true).not() || response.has("error")) {
            return Result.failure(IllegalStateException(response.optString("error", "Bridge request failed.")))
        }
        return Result.success(response)
    }

    // region Full-Auto Prompt & Control Dispatch

    fun sendPrompt(
        sessionId: String,
        prompt: String,
        modelId: String,
        effort: EffortLevel,
    ): Boolean {
        currentSessionId = sessionId
        val payload = JSONObject()
            .put("type", "prompt")
            .put("sessionId", sessionId)
            .put("prompt", prompt)
            .put("model", modelId)
            .put("effort", effort.cliValue)
            .put("autoApprove", true)
            .put("permissionMode", "bypassPermissions")
        return sendRawJson(payload)
    }

    fun cancelPrompt(sessionId: String) {
        sendRawJson(JSONObject().put("type", "cancel_prompt").put("sessionId", sessionId))
    }

    fun dispatchControl(command: String) {
        sendRawJson(
            JSONObject()
                .put("type", "claude_cli_control")
                .put("sessionId", currentSessionId)
                .put("command", command),
        )
    }

    // endregion

    // region Real Terminal PTY

    fun sendPtyInput(tabId: String, data: String): Boolean = sendRawJson(
        JSONObject()
            .put("type", "pty_input")
            .put("tabId", tabId)
            .put("data", data),
    )

    fun sendPtyResize(tabId: String, cols: Int, rows: Int) {
        sendRawJson(
            JSONObject()
                .put("type", "pty_resize")
                .put("tabId", tabId)
                .put("cols", cols.coerceIn(40, 240))
                .put("rows", rows.coerceIn(10, 80)),
        )
    }

    fun sendPtySignal(tabId: String, signal: String = "SIGINT"): Boolean = sendRawJson(
        JSONObject()
            .put("type", "pty_signal")
            .put("tabId", tabId)
            .put("signal", signal),
    )

    // endregion

    // region Real Codespace Filesystem CRUD

    suspend fun listDirectory(path: String, includeHidden: Boolean): Result<List<FsEntry>> =
        sendRpc(
            JSONObject()
                .put("type", "fs_list")
                .put("path", path)
                .put("includeHidden", includeHidden),
        ).map { resp ->
            val arr = resp.optJSONArray("entries") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val name = obj.optString("name")
                    val entryPath = obj.optString("path")
                    if (name.isBlank() || entryPath.isBlank()) continue
                    add(
                        FsEntry(
                            path = entryPath,
                            name = name,
                            isDirectory = obj.optBoolean("isDirectory", false),
                            sizeBytes = obj.optLong("size", 0L),
                            isHidden = name.startsWith("."),
                        ),
                    )
                }
            }.sortedWith(compareByDescending<FsEntry> { it.isDirectory }.thenBy { it.name.lowercase() })
        }

    suspend fun readFile(path: String): Result<String> =
        sendRpc(
            JSONObject()
                .put("type", "fs_read")
                .put("path", path),
        ).map { it.optString("content") }

    suspend fun writeFile(path: String, content: String): Result<Unit> =
        sendRpc(
            JSONObject()
                .put("type", "fs_write")
                .put("path", path)
                .put("content", content),
        ).map { Unit }

    suspend fun createDirectory(path: String): Result<Unit> =
        sendRpc(
            JSONObject()
                .put("type", "fs_mkdir")
                .put("path", path),
        ).map { Unit }

    suspend fun renamePath(oldPath: String, newPath: String): Result<Unit> =
        sendRpc(
            JSONObject()
                .put("type", "fs_rename")
                .put("oldPath", oldPath)
                .put("newPath", newPath),
        ).map { Unit }

    suspend fun deletePath(path: String): Result<Unit> =
        sendRpc(
            JSONObject()
                .put("type", "fs_delete")
                .put("path", path),
        ).map { Unit }

    // endregion

    // region Real Dynamic Model Discovery & Connection Latency Test

    suspend fun fetchLiveModels(config: BridgeConfig): List<AiModelOption> = withContext(Dispatchers.IO) {
        val routerModels = mutableListOf<AiModelOption>()

        // 1. Primary: GET https://<codespace>-8082.app.github.dev/v1/models
        if (BridgeUrlValidator.validateHttpUrl(config.fccServerUrl) == null) {
            runCatching {
                val baseUrl = config.fccServerUrl.trim().trimEnd('/')
                val req = Request.Builder().url("$baseUrl/v1/models").apply {
                    if (config.bearerSecret.isNotBlank()) {
                        header("Authorization", "Bearer ${config.bearerSecret.trim()}")
                    }
                }.build()
                httpClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val arr = JSONObject(resp.body?.string().orEmpty()).optJSONArray("data")
                        if (arr != null) {
                            routerModels += parseModelArray(arr)
                        }
                    }
                }
            }
        }

        // 2. Fallback: WebSocket { type: "list_models" } via bridge.js
        if (routerModels.isEmpty() && isSocketOpen) {
            sendRpc(JSONObject().put("type", "list_models"), timeoutMs = 5_000L).onSuccess { resp ->
                val arr = resp.optJSONArray("models") ?: resp.optJSONArray("data")
                if (arr != null) {
                    routerModels += parseModelArray(arr)
                }
            }
        }

        // Merge with real Claude CLI IDs without duplicates
        val seen = HashSet<String>()
        buildList {
            for (m in routerModels) {
                if (seen.add(m.id)) add(m)
            }
            for (m in RealModelsCatalog.cliDefaultModels) {
                if (seen.add(m.id)) add(m)
            }
        }
    }

    private fun parseModelArray(arr: JSONArray): List<AiModelOption> = buildList {
        for (i in 0 until arr.length()) {
            val item = arr.opt(i)
            val id = when (item) {
                is JSONObject -> item.optString("id")
                is String -> item
                else -> ""
            }.trim()
            if (id.isEmpty()) continue
            val isClaude = id.startsWith("claude-", ignoreCase = true)
            val owner = if (item is JSONObject) item.optString("owned_by", "fcc-server") else "fcc-server"
            val ctxLen = if (item is JSONObject) item.optInt("context_length", 200_000) / 1000 else 200
            add(
                AiModelOption(
                    id = id,
                    displayName = id,
                    provider = if (isClaude) "Anthropic" else owner,
                    group = if (isClaude) ModelProviderGroup.Claude else ModelProviderGroup.FccRouter,
                    contextWindowK = ctxLen.coerceAtLeast(32),
                ),
            )
        }
    }

    suspend fun testConnection(config: BridgeConfig): BridgeTestResult = withContext(Dispatchers.IO) {
        BridgeUrlValidator.validateWebSocketUrl(config.wsUrl)?.let { err ->
            return@withContext BridgeTestResult(false, null, null, err)
        }
        BridgeUrlValidator.validateHttpUrl(config.fccServerUrl)?.let { err ->
            return@withContext BridgeTestResult(false, null, null, err)
        }

        var fccLatency: Long? = null
        val fccStart = System.currentTimeMillis()
        val fccMsg = try {
            val baseUrl = config.fccServerUrl.trim().trimEnd('/')
            val req = Request.Builder().url("$baseUrl/v1/models").apply {
                if (config.bearerSecret.isNotBlank()) {
                    header("Authorization", "Bearer ${config.bearerSecret.trim()}")
                }
            }.get().build()
            httpClient.newCall(req).execute().use { resp ->
                fccLatency = System.currentTimeMillis() - fccStart
                "fcc-server HTTP ${resp.code} (${fccLatency} ms)"
            }
        } catch (e: Exception) {
            "fcc-server unreachable: ${e.localizedMessage ?: "network error"}"
        }

        var wsLatency: Long? = null
        val wsStart = System.currentTimeMillis()
        val wsResult = CompletableDeferred<Pair<Boolean, String>>()
        try {
            val wsReq = Request.Builder().url(config.wsUrl.trim()).apply {
                if (config.bearerSecret.isNotBlank()) {
                    header("Authorization", "Bearer ${config.bearerSecret.trim()}")
                }
            }.build()
            val probe = httpClient.newWebSocket(
                wsReq,
                object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        wsLatency = System.currentTimeMillis() - wsStart
                        webSocket.close(1000, "Probe complete")
                        wsResult.complete(true to "Bridge WS OK (${wsLatency} ms)")
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        wsResult.complete(false to "Bridge WS failed: ${response?.code ?: t.localizedMessage ?: "unreachable"}")
                    }
                },
            )
            val (ok, msg) = withTimeoutOrNull(7_000L) { wsResult.await() } ?: (false to "Bridge WS timed out")
            probe.cancel()
            BridgeTestResult(
                success = ok,
                wsLatencyMs = wsLatency,
                fccLatencyMs = fccLatency,
                diagnostics = "$msg • $fccMsg",
            )
        } catch (e: Exception) {
            BridgeTestResult(false, null, fccLatency, "Bridge WS error: ${e.localizedMessage ?: "invalid"} • $fccMsg")
        }
    }

    // endregion

    // region ANSI Terminal Color Parser

    private val sgrRegex = Regex("""\u001B\[([0-9;]*)m""")
    private val otherEscapeRegex = Regex("""\u001B\[[;?\d]*[A-LN-Za-z]|\u001B\][^\u0007]*\u0007""")

    private fun parseAnsiLine(raw: String, defaultRole: AnsiColorRole): List<AnsiSegment> {
        val cleaned = otherEscapeRegex.replace(raw, "")
        val segments = mutableListOf<AnsiSegment>()
        var currentRole = defaultRole
        var lastIdx = 0

        for (match in sgrRegex.findAll(cleaned)) {
            if (match.range.first > lastIdx) {
                segments += AnsiSegment(cleaned.substring(lastIdx, match.range.first), currentRole)
            }
            val codes = match.groupValues[1].split(";").mapNotNull { it.toIntOrNull() }
            currentRole = when {
                codes.isEmpty() || 0 in codes -> defaultRole
                31 in codes || 91 in codes -> AnsiColorRole.Red
                32 in codes || 92 in codes -> AnsiColorRole.Green
                33 in codes || 93 in codes -> AnsiColorRole.Amber
                34 in codes || 94 in codes -> AnsiColorRole.Blue
                35 in codes || 95 in codes -> AnsiColorRole.Magenta
                36 in codes || 96 in codes -> AnsiColorRole.Cyan
                90 in codes -> AnsiColorRole.Muted
                1 in codes -> AnsiColorRole.Bold
                else -> currentRole
            }
            lastIdx = match.range.last + 1
        }
        if (lastIdx < cleaned.length) {
            segments += AnsiSegment(cleaned.substring(lastIdx), currentRole)
        }
        return if (segments.isEmpty()) listOf(AnsiSegment("", defaultRole)) else segments
    }

    // endregion
}
