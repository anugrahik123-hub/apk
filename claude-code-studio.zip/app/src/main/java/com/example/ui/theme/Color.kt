package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

// Exact Warm Anthropic Dark Mode Palette
val WarmDarkCanvas = Color(0xFF191918)
val WarmDarkSidebar = Color(0xFF141413)
val WarmDarkSurface = Color(0xFF22211F)
val WarmDarkSurfaceElevated = Color(0xFF2A2927)
val WarmDarkHover = Color(0xFF302F2C)
val WarmDarkBorder = Color(0xFF353430)
val WarmDarkBorderFocused = Color(0xFF474540)
val WarmDarkTextPrimary = Color(0xFFECEAE4)
val WarmDarkTextSecondary = Color(0xFF9E9B93)
val WarmDarkTextTertiary = Color(0xFF6F6D66)

// Warm Cream Light Mode Palette
val WarmLightCanvas = Color(0xFFFAF9F5)
val WarmLightSidebar = Color(0xFFF2EFE7)
val WarmLightSurface = Color(0xFFFFFFFF)
val WarmLightSurfaceElevated = Color(0xFFF5F2EA)
val WarmLightHover = Color(0xFFEBE7DC)
val WarmLightBorder = Color(0xFFE0DBD0)
val WarmLightBorderFocused = Color(0xFFC4BDB0)
val WarmLightTextPrimary = Color(0xFF1E1D1B)
val WarmLightTextSecondary = Color(0xFF646159)
val WarmLightTextTertiary = Color(0xFF8F8B81)

// Brand Accent (Anthropic Terracotta / Coral)
val AnthropicTerracotta = Color(0xFFD97757)
val AnthropicTerracottaHover = Color(0xFFE38667)
val AnthropicTerracottaLight = Color(0xFFC96442)
val AnthropicTerracottaSubtleDark = Color(0x26D97757)
val AnthropicTerracottaSubtleLight = Color(0x1AC96442)

// Semantic Colors
val SemanticSuccess = Color(0xFF4ADE80)
val SemanticSuccessDark = Color(0xFF16A34A)
val SemanticSuccessBgDark = Color(0x1F4ADE80) // rgba(74,222,128,0.12)
val SemanticSuccessBgLight = Color(0x1A16A34A)

val SemanticDanger = Color(0xFFF87171)
val SemanticDangerDark = Color(0xFFDC2626)
val SemanticDangerBgDark = Color(0x1FF87171) // rgba(248,113,113,0.12)
val SemanticDangerBgLight = Color(0x1ADC2626)

val SemanticWarning = Color(0xFFFBBF24)
val SemanticWarningDark = Color(0xFFD97706)
val SemanticWarningBgDark = Color(0x1FFBBF24)
val SemanticWarningBgLight = Color(0x1AD97706)

val SemanticInfo = Color(0xFF60A5FA)
val SemanticInfoDark = Color(0xFF2563EB)
val SemanticInfoBgDark = Color(0x1F60A5FA)
val SemanticInfoBgLight = Color(0x1A2563EB)

@Immutable
data class StudioPalette(
    val isDark: Boolean,
    val canvas: Color,
    val sidebar: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val hover: Color,
    val border: Color,
    val borderFocused: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val accent: Color,
    val accentHover: Color,
    val accentSubtle: Color,
    val success: Color,
    val successBg: Color,
    val danger: Color,
    val dangerBg: Color,
    val warning: Color,
    val warningBg: Color,
    val info: Color,
    val infoBg: Color,
    val codeBackground: Color,
    val terminalBackground: Color,
) {
    val borderDefault: Color get() = border
    val surfaceSubtle: Color get() = surface
    val codeBlockBg: Color get() = codeBackground
    val terminalBg: Color get() = terminalBackground
    val userBubbleBg: Color get() = surfaceElevated
}

val DarkStudioPalette = StudioPalette(
    isDark = true,
    canvas = WarmDarkCanvas,
    sidebar = WarmDarkSidebar,
    surface = WarmDarkSurface,
    surfaceElevated = WarmDarkSurfaceElevated,
    hover = WarmDarkHover,
    border = WarmDarkBorder,
    borderFocused = WarmDarkBorderFocused,
    textPrimary = WarmDarkTextPrimary,
    textSecondary = WarmDarkTextSecondary,
    textTertiary = WarmDarkTextTertiary,
    accent = AnthropicTerracotta,
    accentHover = AnthropicTerracottaHover,
    accentSubtle = AnthropicTerracottaSubtleDark,
    success = SemanticSuccess,
    successBg = SemanticSuccessBgDark,
    danger = SemanticDanger,
    dangerBg = SemanticDangerBgDark,
    warning = SemanticWarning,
    warningBg = SemanticWarningBgDark,
    info = SemanticInfo,
    infoBg = SemanticInfoBgDark,
    codeBackground = Color(0xFF151514),
    terminalBackground = Color(0xFF111110),
)

val LightStudioPalette = StudioPalette(
    isDark = false,
    canvas = WarmLightCanvas,
    sidebar = WarmLightSidebar,
    surface = WarmLightSurface,
    surfaceElevated = WarmLightSurfaceElevated,
    hover = WarmLightHover,
    border = WarmLightBorder,
    borderFocused = WarmLightBorderFocused,
    textPrimary = WarmLightTextPrimary,
    textSecondary = WarmLightTextSecondary,
    textTertiary = WarmLightTextTertiary,
    accent = AnthropicTerracottaLight,
    accentHover = AnthropicTerracotta,
    accentSubtle = AnthropicTerracottaSubtleLight,
    success = SemanticSuccessDark,
    successBg = SemanticSuccessBgLight,
    danger = SemanticDangerDark,
    dangerBg = SemanticDangerBgLight,
    warning = SemanticWarningDark,
    warningBg = SemanticWarningBgLight,
    info = SemanticInfoDark,
    infoBg = SemanticInfoBgLight,
    codeBackground = Color(0xFFF3F0E8),
    terminalBackground = Color(0xFF191918),
)
