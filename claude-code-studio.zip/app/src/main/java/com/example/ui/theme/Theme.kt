package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

val LocalStudioPalette = staticCompositionLocalOf { DarkStudioPalette }
val LocalStudioTypographyConfig = staticCompositionLocalOf { StudioTypographyConfig() }

private val DarkM3Scheme = darkColorScheme(
    primary = AnthropicTerracotta,
    onPrimary = Color(0xFF191918),
    primaryContainer = AnthropicTerracottaSubtleDark,
    onPrimaryContainer = AnthropicTerracottaHover,
    secondary = SemanticInfo,
    onSecondary = Color(0xFF111110),
    background = WarmDarkCanvas,
    onBackground = WarmDarkTextPrimary,
    surface = WarmDarkSurface,
    onSurface = WarmDarkTextPrimary,
    surfaceVariant = WarmDarkSurfaceElevated,
    onSurfaceVariant = WarmDarkTextSecondary,
    outline = WarmDarkBorder,
    outlineVariant = WarmDarkBorderFocused,
    error = SemanticDanger,
    onError = Color(0xFF191918),
)

private val LightM3Scheme = lightColorScheme(
    primary = AnthropicTerracottaLight,
    onPrimary = Color.White,
    primaryContainer = AnthropicTerracottaSubtleLight,
    onPrimaryContainer = AnthropicTerracottaLight,
    secondary = SemanticInfoDark,
    onSecondary = Color.White,
    background = WarmLightCanvas,
    onBackground = WarmLightTextPrimary,
    surface = WarmLightSurface,
    onSurface = WarmLightTextPrimary,
    surfaceVariant = WarmLightSurfaceElevated,
    onSurfaceVariant = WarmLightTextSecondary,
    outline = WarmLightBorder,
    outlineVariant = WarmLightBorderFocused,
    error = SemanticDangerDark,
    onError = Color.White,
)

private val StudioShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp),
)

@Composable
fun ClaudeCodeStudioTheme(
    darkTheme: Boolean = true,
    useSerifProse: Boolean = false,
    codeFontSizeSp: Float = 12.5f,
    content: @Composable () -> Unit,
) {
    val palette = if (darkTheme) DarkStudioPalette else LightStudioPalette
    val colorScheme = if (darkTheme) DarkM3Scheme else LightM3Scheme
    val typographyConfig = StudioTypographyConfig(
        useSerifProse = useSerifProse,
        codeFontSizeSp = codeFontSizeSp,
    )

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalStudioPalette provides palette,
        LocalStudioTypographyConfig provides typographyConfig,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = StudioTypography,
            shapes = StudioShapes,
            content = content,
        )
    }
}
