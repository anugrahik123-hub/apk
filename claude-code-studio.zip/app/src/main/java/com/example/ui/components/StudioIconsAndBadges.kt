package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom Anthropic-inspired 8-ray radiant editorial sparkle emblem drawn crisply with Compose Canvas.
 */
@Composable
fun ClaudeSparkleEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    tint: Color = LocalStudioPalette.current.accent,
) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val outerR = this.size.minDimension * 0.45f
        val innerR = this.size.minDimension * 0.14f
        val strokeMain = this.size.minDimension * 0.115f
        val strokeMinor = this.size.minDimension * 0.085f

        for (i in 0 until 8) {
            val angleRad = (i * 45.0) * PI / 180.0
            val isPrimary = i % 2 == 0
            val rEnd = if (isPrimary) outerR else outerR * 0.84f
            val start = Offset(
                x = cx + (cos(angleRad) * innerR).toFloat(),
                y = cy + (sin(angleRad) * innerR).toFloat(),
            )
            val end = Offset(
                x = cx + (cos(angleRad) * rEnd).toFloat(),
                y = cy + (sin(angleRad) * rEnd).toFloat(),
            )
            drawLine(
                color = tint,
                start = start,
                end = end,
                strokeWidth = if (isPrimary) strokeMain else strokeMinor,
                cap = StrokeCap.Round,
            )
        }
        drawCircle(color = tint, radius = innerR * 1.15f, center = Offset(cx, cy))
    }
}

@Composable
fun StatusDot(
    color: Color,
    pulsing: Boolean = false,
    size: Dp = 8.dp,
    modifier: Modifier = Modifier,
) {
    val alpha = if (pulsing) {
        val transition = rememberInfiniteTransition(label = "status_pulse")
        val animated by transition.animateFloat(
            initialValue = 0.35f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 750),
                repeatMode = RepeatMode.Reverse,
            ),
            label = "pulse_alpha",
        )
        animated
    } else {
        1f
    }

    Box(
        modifier = modifier
            .size(size)
            .alpha(alpha)
            .clip(CircleShape)
            .background(color),
    )
}

@Composable
fun StudioPillBadge(
    text: String,
    textColor: Color,
    backgroundColor: Color,
    borderColor: Color = Color.Transparent,
    monospace: Boolean = false,
    leadingDotColor: Color? = null,
    pulsingDot: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(backgroundColor)
            .then(
                if (borderColor != Color.Transparent) {
                    Modifier.border(1.dp, borderColor, RoundedCornerShape(999.dp))
                } else {
                    Modifier
                },
            )
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        if (leadingDotColor != null) {
            StatusDot(color = leadingDotColor, pulsing = pulsingDot, size = 6.dp)
        }
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            lineHeight = 14.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = if (monospace) JetBrainsMonoFontFamily else InterFontFamily,
            maxLines = 1,
        )
    }
}

@Composable
fun EffortSignalBars(
    level: Int,
    activeColor: Color = LocalStudioPalette.current.accent,
    inactiveColor: Color = LocalStudioPalette.current.borderFocused,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        for (bar in 1..4) {
            val h = (4 + bar * 2.5f).dp
            Box(
                modifier = Modifier
                    .size(width = 3.dp, height = h)
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(if (bar <= level) activeColor else inactiveColor),
            )
        }
    }
}
