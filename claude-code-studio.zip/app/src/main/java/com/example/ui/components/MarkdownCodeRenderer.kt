package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.ui.theme.LocalStudioTypographyConfig

private sealed interface MarkdownBlock {
    data class Prose(val text: String) : MarkdownBlock
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class Bullet(val text: String) : MarkdownBlock
    data class Callout(val text: String) : MarkdownBlock
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock
    data class Code(val language: String, val fileName: String?, val content: String) : MarkdownBlock
}

@Composable
fun MarkdownMessageBody(
    markdown: String,
    useSerifProse: Boolean = false,
    codeFontSizeSp: Float = 12.5f,
    onCopyCode: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    MarkdownProseRenderer(
        markdown = markdown,
        modifier = modifier,
    )
}

fun highlightSyntax(
    code: String,
    language: String,
    palette: com.example.ui.theme.StudioPalette,
): AnnotatedString = highlightCodeSyntax(
    code = code,
    keywordColor = palette.accent,
    stringColor = palette.success,
    commentColor = palette.textTertiary,
    numberColor = palette.info,
    defaultColor = palette.textPrimary,
)

@Composable
fun MarkdownProseRenderer(
    markdown: String,
    onApplyCodeToFile: ((fileName: String?, code: String) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val typoConfig = LocalStudioTypographyConfig.current
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        blocks.forEach { block ->
            when (block) {
                is MarkdownBlock.Heading -> {
                    Text(
                        text = renderInlineMarkdown(block.text, palette.accent, palette.codeBackground, palette.textPrimary),
                        color = palette.textPrimary,
                        fontFamily = typoConfig.proseFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = when (block.level) {
                            1 -> 19.sp
                            2 -> 17.sp
                            else -> 15.sp
                        },
                        lineHeight = 24.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                is MarkdownBlock.Bullet -> {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(start = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = "•",
                            color = palette.accent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = renderInlineMarkdown(block.text, palette.accent, palette.codeBackground, palette.textPrimary),
                            color = palette.textPrimary,
                            fontFamily = typoConfig.proseFontFamily,
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                        )
                    }
                }
                is MarkdownBlock.Callout -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(palette.accentSubtle)
                            .border(1.dp, palette.accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Text(
                            text = renderInlineMarkdown(block.text, palette.accent, palette.codeBackground, palette.textPrimary),
                            color = palette.textPrimary,
                            fontFamily = typoConfig.proseFontFamily,
                            fontSize = 13.5.sp,
                            lineHeight = 20.sp,
                        )
                    }
                }
                is MarkdownBlock.Table -> {
                    MarkdownTableCard(block.headers, block.rows)
                }
                is MarkdownBlock.Code -> {
                    SyntaxHighlightedCodeCard(
                        language = block.language,
                        fileName = block.fileName,
                        code = block.content,
                        onApplyToFile = onApplyCodeToFile,
                    )
                }
                is MarkdownBlock.Prose -> {
                    Text(
                        text = renderInlineMarkdown(block.text, palette.accent, palette.codeBackground, palette.textPrimary),
                        color = palette.textPrimary,
                        fontFamily = typoConfig.proseFontFamily,
                        fontSize = 14.5.sp,
                        lineHeight = 22.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun MarkdownTableCard(headers: List<String>, rows: List<List<String>>) {
    val palette = LocalStudioPalette.current
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surface)
            .border(1.dp, palette.border, RoundedCornerShape(10.dp))
            .horizontalScroll(scroll),
    ) {
        Row(
            modifier = Modifier
                .background(palette.surfaceElevated)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            headers.forEach { header ->
                Text(
                    text = header,
                    color = palette.textPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.width(120.dp),
                )
            }
        }
        rows.forEach { row ->
            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.border))
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                row.forEach { cell ->
                    Text(
                        text = cell,
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.width(120.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun SyntaxHighlightedCodeCard(
    language: String,
    fileName: String?,
    code: String,
    onApplyToFile: ((fileName: String?, code: String) -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val typoConfig = LocalStudioTypographyConfig.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.codeBackground)
            .border(1.dp, palette.border, RoundedCornerShape(12.dp)),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.surfaceElevated.copy(alpha = 0.7f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StudioPillBadge(
                    text = language.ifBlank { "code" }.uppercase(),
                    textColor = palette.accent,
                    backgroundColor = palette.accentSubtle,
                    monospace = true,
                )
                if (!fileName.isNullOrBlank()) {
                    Text(
                        text = fileName,
                        color = palette.textSecondary,
                        fontSize = 11.5.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        maxLines = 1,
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(code))
                        copied = true
                    },
                    modifier = Modifier.testTag("copy_code_button"),
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                        contentDescription = "Copy code",
                        tint = if (copied) palette.success else palette.textSecondary,
                        modifier = Modifier.size(14.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (copied) "Copied" else "Copy",
                        color = if (copied) palette.success else palette.textSecondary,
                        fontSize = 11.5.sp,
                    )
                }
                if (onApplyToFile != null) {
                    TextButton(
                        onClick = { onApplyToFile(fileName, code) },
                        modifier = Modifier.testTag("apply_code_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FileUpload,
                            contentDescription = "Apply code to file",
                            tint = palette.accent,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "Apply",
                            color = palette.accent,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
        }

        val hScroll = rememberScrollState()
        val highlighted = remember(code, palette.isDark) {
            highlightCodeSyntax(
                code = code,
                keywordColor = palette.accent,
                stringColor = palette.success,
                commentColor = palette.textTertiary,
                numberColor = palette.info,
                defaultColor = palette.textPrimary,
            )
        }
        Text(
            text = highlighted,
            fontFamily = JetBrainsMonoFontFamily,
            fontSize = typoConfig.codeFontSizeSp.sp,
            lineHeight = (typoConfig.codeFontSizeSp * 1.52f).sp,
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(hScroll)
                .padding(horizontal = 12.dp, vertical = 10.dp),
        )
    }
}

fun highlightCodeSyntax(
    code: String,
    keywordColor: Color,
    stringColor: Color,
    commentColor: Color,
    numberColor: Color,
    defaultColor: Color,
): AnnotatedString {
    val keywords = setOf(
        "def", "async", "await", "return", "if", "elif", "else", "for", "in", "not", "import",
        "from", "class", "raise", "yield", "continue", "break", "val", "var", "fun", "const",
        "let", "function", "export", "interface", "type", "try", "catch", "true", "false", "None", "null",
    )
    val tokenRegex = Regex("""(#.*|//.*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b\d+(?:\.\d+)?\b|\b[A-Za-z_][A-Za-z0-9_]*\b)""")

    return buildAnnotatedString {
        var lastIndex = 0
        for (match in tokenRegex.findAll(code)) {
            if (match.range.first > lastIndex) {
                withStyle(SpanStyle(color = defaultColor)) {
                    append(code.substring(lastIndex, match.range.first))
                }
            }
            val token = match.value
            val color = when {
                token.startsWith("#") || token.startsWith("//") -> commentColor
                token.startsWith("\"") || token.startsWith("'") -> stringColor
                token.first().isDigit() -> numberColor
                token in keywords -> keywordColor
                else -> defaultColor
            }
            withStyle(
                SpanStyle(
                    color = color,
                    fontWeight = if (token in keywords) FontWeight.Medium else FontWeight.Normal,
                ),
            ) {
                append(token)
            }
            lastIndex = match.range.last + 1
        }
        if (lastIndex < code.length) {
            withStyle(SpanStyle(color = defaultColor)) {
                append(code.substring(lastIndex))
            }
        }
    }
}

private fun renderInlineMarkdown(
    text: String,
    accent: Color,
    codeBg: Color,
    primary: Color,
): AnnotatedString {
    val pattern = Regex("""(`[^`]+`|\*\*[^*]+\*\*|_[^_]+_)""")
    return buildAnnotatedString {
        var last = 0
        for (m in pattern.findAll(text)) {
            if (m.range.first > last) {
                append(text.substring(last, m.range.first))
            }
            val token = m.value
            when {
                token.startsWith("`") && token.endsWith("`") -> {
                    withStyle(
                        SpanStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.5.sp,
                            color = accent,
                            background = codeBg,
                        ),
                    ) {
                        append(" ${token.drop(1).dropLast(1)} ")
                    }
                }
                token.startsWith("**") && token.endsWith("**") -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = primary)) {
                        append(token.drop(2).dropLast(2))
                    }
                }
                token.startsWith("_") && token.endsWith("_") -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(token.drop(1).dropLast(1))
                    }
                }
            }
            last = m.range.last + 1
        }
        if (last < text.length) {
            append(text.substring(last))
        }
    }
}

private fun parseMarkdownBlocks(raw: String): List<MarkdownBlock> {
    val lines = raw.lines()
    val blocks = mutableListOf<MarkdownBlock>()
    var i = 0
    val proseBuffer = mutableListOf<String>()

    fun flushProse() {
        val text = proseBuffer.joinToString("\n").trim()
        if (text.isNotEmpty()) blocks += MarkdownBlock.Prose(text)
        proseBuffer.clear()
    }

    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()
        when {
            trimmed.startsWith("```") -> {
                flushProse()
                val lang = trimmed.removePrefix("```").trim()
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    codeLines += lines[i]
                    i++
                }
                val firstLine = codeLines.firstOrNull()?.trim().orEmpty()
                val extractedFile = when {
                    firstLine.startsWith("# ") && firstLine.contains(".") -> firstLine.removePrefix("# ").trim()
                    firstLine.startsWith("// ") && firstLine.contains(".") -> firstLine.removePrefix("// ").trim()
                    else -> null
                }
                val finalCode = if (extractedFile != null) codeLines.drop(1).joinToString("\n") else codeLines.joinToString("\n")
                blocks += MarkdownBlock.Code(lang, extractedFile, finalCode)
            }
            trimmed.startsWith("### ") -> {
                flushProse()
                blocks += MarkdownBlock.Heading(3, trimmed.removePrefix("### "))
            }
            trimmed.startsWith("## ") -> {
                flushProse()
                blocks += MarkdownBlock.Heading(2, trimmed.removePrefix("## "))
            }
            trimmed.startsWith("# ") -> {
                flushProse()
                blocks += MarkdownBlock.Heading(1, trimmed.removePrefix("# "))
            }
            trimmed.startsWith("> ") -> {
                flushProse()
                blocks += MarkdownBlock.Callout(trimmed.removePrefix("> "))
            }
            trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                flushProse()
                blocks += MarkdownBlock.Bullet(trimmed.drop(2))
            }
            trimmed.startsWith("|") && i + 1 < lines.size && lines[i + 1].trim().startsWith("|---") -> {
                flushProse()
                val headers = trimmed.split("|").map { it.trim() }.filter { it.isNotEmpty() }
                i += 2
                val rows = mutableListOf<List<String>>()
                while (i < lines.size && lines[i].trim().startsWith("|")) {
                    rows += lines[i].trim().split("|").map { it.trim() }.filter { it.isNotEmpty() }
                    i++
                }
                blocks += MarkdownBlock.Table(headers, rows)
                continue
            }
            trimmed.isEmpty() -> {
                flushProse()
            }
            else -> {
                proseBuffer += line
            }
        }
        i++
    }
    flushProse()
    return blocks
}
