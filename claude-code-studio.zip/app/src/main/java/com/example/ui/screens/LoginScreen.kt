package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.OpenInBrowser
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.DeviceOAuthFlowState
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StatusDot
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun LoginScreen(
    isDarkMode: Boolean,
    isAuthenticating: Boolean,
    authError: String?,
    oauthClientId: String,
    oauthProxyUrl: String,
    deviceOAuth: DeviceOAuthFlowState?,
    onToggleTheme: () -> Unit,
    onUpdateOAuthConfig: (clientId: String, proxyUrl: String) -> Unit,
    onStartDeviceOAuth: () -> Unit,
    onCancelDeviceOAuth: () -> Unit,
    onSetOAuthWebViewVisible: (Boolean) -> Unit,
    onShowMessage: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    val clipboard = LocalClipboardManager.current
    var clientIdInput by remember(oauthClientId) { mutableStateOf(oauthClientId) }
    var proxyUrlInput by remember(oauthProxyUrl) { mutableStateOf(oauthProxyUrl) }
    var showAdvancedConfig by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        IconButton(
            onClick = onToggleTheme,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
                .testTag("login_theme_toggle"),
        ) {
            Icon(
                imageVector = if (isDarkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                contentDescription = "Toggle theme",
                tint = palette.textSecondary,
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .widthIn(max = 460.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceElevated)
                    .border(1.dp, palette.borderDefault, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center,
            ) {
                ClaudeSparkleEmblem(size = 34.dp, tint = palette.accent)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Claude Code Studio",
                color = palette.textPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = InterFontFamily,
                letterSpacing = (-0.4).sp,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "In-app GitHub Codespaces workspace for fcc-claude & fcc-server",
                color = palette.textSecondary,
                fontSize = 13.5.sp,
                lineHeight = 19.sp,
                textAlign = TextAlign.Center,
                fontFamily = InterFontFamily,
            )

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                color = palette.surfaceElevated,
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.VerifiedUser,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = "GitHub OAuth Device Sign-In",
                            color = palette.textPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = InterFontFamily,
                        )
                    }

                    Text(
                        text = "Authenticate directly with GitHub OAuth Device Flow (codespace & repo scopes). Authorization happens strictly inside the app with zero manual tokens.",
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        lineHeight = 18.sp,
                        fontFamily = InterFontFamily,
                    )

                    if (deviceOAuth == null) {
                        Button(
                            onClick = {
                                onUpdateOAuthConfig(clientIdInput, proxyUrlInput)
                                onStartDeviceOAuth()
                            },
                            enabled = !isAuthenticating && clientIdInput.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("github_oauth_signin_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.accent,
                                contentColor = Color.White,
                            ),
                        ) {
                            if (isAuthenticating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White,
                                )
                            } else {
                                Text(
                                    text = "Sign in with GitHub",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.5.sp,
                                    fontFamily = InterFontFamily,
                                )
                            }
                        }
                    } else {
                        // Active Device Flow Card with 8-character one-tap copy code
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.surfaceSubtle)
                                .border(1.dp, palette.accent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(
                                text = "ONE-TIME AUTHORIZATION CODE",
                                color = palette.textTertiary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.8.sp,
                                fontFamily = InterFontFamily,
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.canvas)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp))
                                    .clickable {
                                        clipboard.setText(AnnotatedString(deviceOAuth.userCode))
                                        onShowMessage("Copied ${deviceOAuth.userCode} to clipboard.")
                                    }
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                                    .testTag("copy_device_code_box"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(
                                    text = deviceOAuth.userCode,
                                    color = palette.textPrimary,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.5.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.ContentCopy,
                                        contentDescription = "Copy device code",
                                        tint = palette.accent,
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Text(
                                        text = "Copy",
                                        color = palette.accent,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    clipboard.setText(AnnotatedString(deviceOAuth.userCode))
                                    onSetOAuthWebViewVisible(true)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("open_inapp_github_auth_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.accent,
                                    contentColor = Color.White,
                                ),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.OpenInBrowser,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.size(8.dp))
                                Text(
                                    text = "Copy Code & Authorize In-App",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.5.sp,
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                StatusDot(color = palette.warning, pulsing = true, size = 7.dp)
                                Text(
                                    text = deviceOAuth.statusText.ifBlank { "Waiting for authorization…" },
                                    color = palette.textSecondary,
                                    fontSize = 12.sp,
                                )
                            }

                            TextButton(
                                onClick = onCancelDeviceOAuth,
                                modifier = Modifier.testTag("cancel_oauth_button"),
                            ) {
                                Text("Cancel", color = palette.textSecondary, fontSize = 12.sp)
                            }
                        }
                    }

                    if (!authError.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.dangerBg)
                                .border(1.dp, palette.danger.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
                                .padding(12.dp),
                        ) {
                            Text(
                                text = authError,
                                color = palette.danger,
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                fontFamily = InterFontFamily,
                            )
                        }
                    }

                    HorizontalDivider(color = palette.borderDefault)

                    // Collapsible GitHub OAuth Client ID & optional Bridge /github-oauth Proxy config
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showAdvancedConfig = !showAdvancedConfig }
                            .padding(vertical = 4.dp)
                            .testTag("oauth_advanced_toggle"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Key,
                                contentDescription = null,
                                tint = palette.textSecondary,
                                modifier = Modifier.size(15.dp),
                            )
                            Text(
                                text = "OAuth Client ID & Bridge Proxy Settings",
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        Icon(
                            imageVector = if (showAdvancedConfig) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                            contentDescription = "Toggle OAuth configuration",
                            tint = palette.textSecondary,
                            modifier = Modifier.size(18.dp),
                        )
                    }

                    AnimatedVisibility(visible = showAdvancedConfig) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = clientIdInput,
                                onValueChange = { clientIdInput = it },
                                label = { Text("GitHub OAuth App Client ID", fontSize = 12.sp) },
                                placeholder = { Text("Ov23li…", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("oauth_client_id_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = palette.accent,
                                    unfocusedBorderColor = palette.borderDefault,
                                    focusedTextColor = palette.textPrimary,
                                    unfocusedTextColor = palette.textPrimary,
                                    focusedContainerColor = palette.surfaceSubtle,
                                    unfocusedContainerColor = palette.surfaceSubtle,
                                ),
                            )
                            OutlinedTextField(
                                value = proxyUrlInput,
                                onValueChange = { proxyUrlInput = it },
                                label = { Text("Optional Bridge OAuth Proxy Base URL", fontSize = 12.sp) },
                                placeholder = { Text("https://<codespace>-8765.app.github.dev", fontSize = 11.5.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("oauth_proxy_url_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = palette.accent,
                                    unfocusedBorderColor = palette.borderDefault,
                                    focusedTextColor = palette.textPrimary,
                                    unfocusedTextColor = palette.textPrimary,
                                    focusedContainerColor = palette.surfaceSubtle,
                                    unfocusedContainerColor = palette.surfaceSubtle,
                                ),
                            )
                            Text(
                                text = "Leave proxy blank to connect directly over HTTPS to github.com, or point to your bridge.js /github-oauth endpoint.",
                                color = palette.textTertiary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                            )
                            OutlinedButton(
                                onClick = {
                                    onUpdateOAuthConfig(clientIdInput, proxyUrlInput)
                                    onShowMessage("Saved OAuth configuration.")
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                            ) {
                                Text("Save OAuth Config", color = palette.textPrimary, fontSize = 12.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (deviceOAuth != null && deviceOAuth.showInAppWebView) {
        InAppGitHubDeviceAuthDialog(
            verificationUri = deviceOAuth.verificationUri,
            userCode = deviceOAuth.userCode,
            onCopyCode = {
                clipboard.setText(AnnotatedString(deviceOAuth.userCode))
                onShowMessage("Copied ${deviceOAuth.userCode}")
            },
            onDismiss = { onSetOAuthWebViewVisible(false) },
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun InAppGitHubDeviceAuthDialog(
    verificationUri: String,
    userCode: String,
    onCopyCode: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val safeUrl = remember(verificationUri) {
        val parsed = Uri.parse(verificationUri)
        if (parsed.scheme == "https" && parsed.host?.endsWith("github.com") == true) {
            verificationUri
        } else {
            "https://github.com/login/device"
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            color = palette.surfaceElevated,
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.sidebar)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = null,
                            tint = palette.success,
                            modifier = Modifier.size(16.dp),
                        )
                        Column {
                            Text(
                                text = "GitHub Device Authorization",
                                color = palette.textPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = "Enter code: $userCode",
                                color = palette.accent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = JetBrainsMonoFontFamily,
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = onCopyCode) {
                            Text("Copy Code", color = palette.accent, fontSize = 12.sp)
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_oauth_webview")) {
                            Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                        }
                    }
                }
                HorizontalDivider(color = palette.borderDefault)

                AndroidView(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                ): Boolean {
                                    val host = request?.url?.host?.lowercase().orEmpty()
                                    val allowed = host == "github.com" || host.endsWith(".github.com")
                                    return !allowed
                                }
                            }
                            loadUrl(safeUrl)
                        }
                    },
                )
            }
        }
    }
}
