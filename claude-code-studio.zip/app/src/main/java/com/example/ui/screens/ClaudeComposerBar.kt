package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiModelOption
import com.example.model.AttachmentType
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.EffortLevel
import com.example.model.FsEntry
import com.example.model.ModelProviderGroup
import com.example.ui.components.EffortSignalBars
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClaudeComposerBar(
    composerText: String,
    pendingAttachments: List<ContextAttachment>,
    knownFiles: List<FsEntry>,
    availableModels: List<AiModelOption>,
    isRefreshingModels: Boolean,
    selectedModel: AiModelOption,
    selectedEffort: EffortLevel,
    contextBreakdown: ContextBreakdown,
    isStreaming: Boolean,
    onComposerTextChange: (String) -> Unit,
    onSendPrompt: () -> Unit,
    onStopGeneration: () -> Unit,
    onSelectModel: (String) -> Unit,
    onRefreshModels: () -> Unit,
    onSelectEffort: (EffortLevel) -> Unit,
    onCompactContext: () -> Unit,
    onClearConversation: () -> Unit,
    onExportMarkdown: () -> Unit,
    onAddAttachment: (AttachmentType, String, String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var showModelMenu by remember { mutableStateOf(false) }
    var showEffortMenu by remember { mutableStateOf(false) }
    var showContextMenu by remember { mutableStateOf(false) }
    var showFilePickerMenu by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) {
            val label = uri.lastPathSegment?.substringAfterLast('/') ?: "image.png"
            onAddAttachment(AttachmentType.Image, label, uri.toString())
        }
    }

    // Inline @file autocomplete backed by real loaded Codespace files
    val mentionQuery = remember(composerText) {
        val lastAt = composerText.lastIndexOf('@')
        if (lastAt >= 0 && !composerText.substring(lastAt + 1).contains(' ')) {
            composerText.substring(lastAt + 1)
        } else {
            null
        }
    }
    val mentionMatches = remember(mentionQuery, knownFiles) {
        if (mentionQuery == null) emptyList()
        else knownFiles.filter {
            it.name.contains(mentionQuery, ignoreCase = true) ||
                it.path.contains(mentionQuery, ignoreCase = true)
        }.take(6)
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (mentionMatches.isNotEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = palette.surfaceElevated,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, palette.borderFocused, RoundedCornerShape(12.dp)),
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    mentionMatches.forEach { entry ->
                        val rel = entry.path.removePrefix("/workspaces/").removePrefix("/")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val lastAt = composerText.lastIndexOf('@')
                                    val prefix = if (lastAt >= 0) composerText.substring(0, lastAt) else composerText
                                    onComposerTextChange("$prefix@$rel ")
                                    onAddAttachment(AttachmentType.File, entry.name, entry.path)
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Description,
                                contentDescription = null,
                                tint = palette.accent,
                                modifier = Modifier.size(15.dp),
                            )
                            Text(
                                text = rel,
                                color = palette.textPrimary,
                                fontSize = 12.sp,
                                fontFamily = JetBrainsMonoFontFamily,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = palette.surfaceElevated,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, palette.borderFocused, RoundedCornerShape(16.dp)),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (pendingAttachments.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        pendingAttachments.forEach { att ->
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.surfaceSubtle)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(8.dp))
                                    .padding(start = 8.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Icon(
                                    imageVector = if (att.type == AttachmentType.Image) Icons.Outlined.Image else Icons.Outlined.Description,
                                    contentDescription = null,
                                    tint = palette.accent,
                                    modifier = Modifier.size(13.dp),
                                )
                                Text(
                                    text = att.label,
                                    color = palette.textPrimary,
                                    fontSize = 11.5.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                )
                                Icon(
                                    imageVector = Icons.Outlined.Close,
                                    contentDescription = "Remove attachment",
                                    tint = palette.textTertiary,
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clickable { onRemoveAttachment(att.id) },
                                )
                            }
                        }
                    }
                }

                // Multi-line prompt input
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 38.dp, max = 140.dp)
                        .padding(horizontal = 2.dp, vertical = 4.dp),
                ) {
                    if (composerText.isEmpty()) {
                        Text(
                            text = "Ask Claude Code to edit, build, or debug… (@ to reference files)",
                            color = palette.textTertiary,
                            fontSize = 14.sp,
                            fontFamily = InterFontFamily,
                        )
                    }
                    BasicTextField(
                        value = composerText,
                        onValueChange = onComposerTextChange,
                        textStyle = TextStyle(
                            color = palette.textPrimary,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            fontFamily = InterFontFamily,
                        ),
                        cursorBrush = SolidColor(palette.accent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("claude_prompt_input"),
                    )
                }

                // Bottom Action Strip (Dynamic Model Selector, Thinking Effort, Context Ring, Attach, Send/Stop)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        // Dynamic Live Model Selector
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.surfaceSubtle)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(8.dp))
                                    .clickable { showModelMenu = true }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("model_selector_pill"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(
                                    text = selectedModel.displayName,
                                    color = palette.textPrimary,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.width(120.dp),
                                )
                                Icon(
                                    imageVector = Icons.Outlined.ExpandMore,
                                    contentDescription = "Select model",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(14.dp),
                                )
                            }

                            DropdownMenu(
                                expanded = showModelMenu,
                                onDismissRequest = { showModelMenu = false },
                                modifier = Modifier
                                    .background(palette.surfaceElevated)
                                    .width(280.dp),
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        ) {
                                            if (isRefreshingModels) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(14.dp),
                                                    strokeWidth = 1.8.dp,
                                                    color = palette.accent,
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Outlined.Refresh,
                                                    contentDescription = null,
                                                    tint = palette.accent,
                                                    modifier = Modifier.size(15.dp),
                                                )
                                            }
                                            Text(
                                                text = "Refresh Models (:8082/v1/models)",
                                                color = palette.accent,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                            )
                                        }
                                    },
                                    onClick = { onRefreshModels() },
                                )
                                HorizontalDivider(color = palette.borderDefault)

                                val routerModels = availableModels.filter { it.group == ModelProviderGroup.FccRouter }
                                val claudeModels = availableModels.filter { it.group == ModelProviderGroup.Claude }

                                if (routerModels.isNotEmpty()) {
                                    Text(
                                        text = ModelProviderGroup.FccRouter.label,
                                        color = palette.textTertiary,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    )
                                    routerModels.forEach { model ->
                                        ModelDropdownRow(
                                            model = model,
                                            isSelected = model.id == selectedModel.id,
                                            onSelect = {
                                                onSelectModel(model.id)
                                                showModelMenu = false
                                            },
                                        )
                                    }
                                    HorizontalDivider(color = palette.borderDefault)
                                }

                                Text(
                                    text = ModelProviderGroup.Claude.label,
                                    color = palette.textTertiary,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                )
                                claudeModels.forEach { model ->
                                    ModelDropdownRow(
                                        model = model,
                                        isSelected = model.id == selectedModel.id,
                                        onSelect = {
                                            onSelectModel(model.id)
                                            showModelMenu = false
                                        },
                                    )
                                }
                            }
                        }

                        // Real Thinking Effort Selector (Off, Low, Medium, High, Max)
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.surfaceSubtle)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(8.dp))
                                    .clickable { showEffortMenu = true }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("effort_selector_pill"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                EffortSignalBars(level = selectedEffort.bars)
                                Text(
                                    text = selectedEffort.label,
                                    color = palette.textPrimary,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Medium,
                                )
                            }

                            DropdownMenu(
                                expanded = showEffortMenu,
                                onDismissRequest = { showEffortMenu = false },
                                modifier = Modifier.background(palette.surfaceElevated),
                            ) {
                                EffortLevel.entries.forEach { level ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            ) {
                                                EffortSignalBars(level = level.bars)
                                                Text(
                                                    text = level.label,
                                                    color = palette.textPrimary,
                                                    fontSize = 12.5.sp,
                                                )
                                                if (level == selectedEffort) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Check,
                                                        contentDescription = null,
                                                        tint = palette.accent,
                                                        modifier = Modifier.size(14.dp),
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            onSelectEffort(level)
                                            showEffortMenu = false
                                        },
                                    )
                                }
                            }
                        }

                        // Context Ring Menu (Compact / Clear / Export)
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showContextMenu = true }
                                    .padding(horizontal = 6.dp, vertical = 6.dp)
                                    .testTag("context_ring_button"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                            ) {
                                val ringColor = when {
                                    contextBreakdown.usagePercent >= 85 -> palette.danger
                                    contextBreakdown.usagePercent >= 65 -> palette.warning
                                    else -> palette.accent
                                }
                                Canvas(modifier = Modifier.size(16.dp)) {
                                    drawArc(
                                        color = palette.borderFocused,
                                        startAngle = 0f,
                                        sweepAngle = 360f,
                                        useCenter = false,
                                        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round),
                                    )
                                    drawArc(
                                        color = ringColor,
                                        startAngle = -90f,
                                        sweepAngle = (contextBreakdown.usageFraction * 360f).coerceAtLeast(8f),
                                        useCenter = false,
                                        style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round),
                                    )
                                }
                                Text(
                                    text = "${contextBreakdown.usagePercent}%",
                                    color = palette.textSecondary,
                                    fontSize = 11.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                )
                            }

                            DropdownMenu(
                                expanded = showContextMenu,
                                onDismissRequest = { showContextMenu = false },
                                modifier = Modifier.background(palette.surfaceElevated),
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.Compress, null, tint = palette.accent, modifier = Modifier.size(16.dp)) },
                                    text = { Text("Compact Context (/compact)", color = palette.textPrimary, fontSize = 12.5.sp) },
                                    onClick = {
                                        showContextMenu = false
                                        onCompactContext()
                                    },
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.Download, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp)) },
                                    text = { Text("Export Session (.md)", color = palette.textPrimary, fontSize = 12.5.sp) },
                                    onClick = {
                                        showContextMenu = false
                                        onExportMarkdown()
                                    },
                                )
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null, tint = palette.danger, modifier = Modifier.size(16.dp)) },
                                    text = { Text("Clear Conversation (/clear)", color = palette.danger, fontSize = 12.5.sp) },
                                    onClick = {
                                        showContextMenu = false
                                        onClearConversation()
                                    },
                                )
                            }
                        }
                    }

                    // Right Actions: Attach + Send/Stop
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Box {
                            IconButton(
                                onClick = { showFilePickerMenu = true },
                                modifier = Modifier
                                    .size(38.dp)
                                    .testTag("attach_context_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AttachFile,
                                    contentDescription = "Attach file or screenshot",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                            DropdownMenu(
                                expanded = showFilePickerMenu,
                                onDismissRequest = { showFilePickerMenu = false },
                                modifier = Modifier.background(palette.surfaceElevated),
                            ) {
                                DropdownMenuItem(
                                    leadingIcon = { Icon(Icons.Outlined.Image, null, tint = palette.accent, modifier = Modifier.size(16.dp)) },
                                    text = { Text("Attach Image (Photo Picker)", color = palette.textPrimary, fontSize = 12.5.sp) },
                                    onClick = {
                                        showFilePickerMenu = false
                                        photoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                                        )
                                    },
                                )
                                if (knownFiles.isNotEmpty()) {
                                    HorizontalDivider(color = palette.borderDefault)
                                    knownFiles.take(8).forEach { file ->
                                        DropdownMenuItem(
                                            leadingIcon = { Icon(Icons.Outlined.Description, null, tint = palette.textSecondary, modifier = Modifier.size(15.dp)) },
                                            text = {
                                                Text(
                                                    text = file.path.removePrefix("/workspaces/"),
                                                    color = palette.textPrimary,
                                                    fontSize = 11.5.sp,
                                                    fontFamily = JetBrainsMonoFontFamily,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            },
                                            onClick = {
                                                showFilePickerMenu = false
                                                onAddAttachment(AttachmentType.File, file.name, file.path)
                                            },
                                        )
                                    }
                                }
                            }
                        }

                        if (isStreaming) {
                            IconButton(
                                onClick = onStopGeneration,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(palette.dangerBg)
                                    .border(1.dp, palette.danger.copy(alpha = 0.6f), CircleShape)
                                    .testTag("stop_generation_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Stop,
                                    contentDescription = "Stop generation",
                                    tint = palette.danger,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        } else {
                            val canSend = composerText.isNotBlank()
                            IconButton(
                                onClick = onSendPrompt,
                                enabled = canSend,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (canSend) palette.accent else palette.surfaceSubtle)
                                    .testTag("send_prompt_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Send,
                                    contentDescription = "Send prompt",
                                    tint = if (canSend) Color.White else palette.textTertiary,
                                    modifier = Modifier.size(17.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelDropdownRow(
    model: AiModelOption,
    isSelected: Boolean,
    onSelect: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    DropdownMenuItem(
        text = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = model.displayName,
                        color = palette.textPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        fontFamily = JetBrainsMonoFontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${model.provider} • ${model.contextWindowK}K ctx",
                        color = palette.textTertiary,
                        fontSize = 10.5.sp,
                    )
                }
                if (isSelected) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Outlined.Check,
                        contentDescription = null,
                        tint = palette.accent,
                        modifier = Modifier.size(15.dp),
                    )
                }
            }
        },
        onClick = onSelect,
    )
}
