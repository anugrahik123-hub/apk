package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.CloudQueue
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SettingsEthernet
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun CodespacesDashboardScreen(
    githubUserLogin: String,
    isDarkMode: Boolean,
    isLoading: Boolean,
    dashboardMessage: String?,
    codespaces: List<CodespaceInfo>,
    onToggleTheme: () -> Unit,
    onRefresh: () -> Unit,
    onConnect: (CodespaceInfo) -> Unit,
    onStart: (CodespaceInfo) -> Unit,
    onStop: (CodespaceInfo) -> Unit,
    onConfigureBridge: (CodespaceInfo) -> Unit,
    onSignOut: () -> Unit,
) {
    val palette = LocalStudioPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.sidebar)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ClaudeSparkleEmblem(size = 24.dp, tint = palette.accent)
                Column {
                    Text(
                        text = "Codespaces Control Center",
                        color = palette.textPrimary,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = InterFontFamily,
                    )
                    Text(
                        text = "@${githubUserLogin.ifBlank { "github" }} • GitHub OAuth",
                        color = palette.textSecondary,
                        fontSize = 11.5.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("dashboard_refresh_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = "Refresh Codespaces",
                        tint = palette.textSecondary,
                    )
                }
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier.testTag("dashboard_theme_toggle"),
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                        contentDescription = "Toggle theme",
                        tint = palette.textSecondary,
                    )
                }
                IconButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("dashboard_sign_out_button"),
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Logout,
                        contentDescription = "Sign out",
                        tint = palette.textSecondary,
                    )
                }
            }
        }
        HorizontalDivider(color = palette.borderDefault)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize(),
            ) {
                if (!dashboardMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.surfaceElevated)
                            .border(1.dp, palette.borderDefault, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                    ) {
                        Text(
                            text = dashboardMessage,
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontFamily = InterFontFamily,
                        )
                    }
                }

                if (isLoading && codespaces.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            CircularProgressIndicator(color = palette.accent)
                            Text(
                                text = "Fetching your GitHub Codespaces…",
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                            )
                        }
                    }
                } else if (codespaces.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CloudQueue,
                                contentDescription = null,
                                tint = palette.textTertiary,
                                modifier = Modifier.size(40.dp),
                            )
                            Text(
                                text = "No Codespaces Found",
                                color = palette.textPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = "Create a Codespace on GitHub with alishahryar1/free-claude-code, then tap Refresh.",
                                color = palette.textSecondary,
                                fontSize = 12.5.sp,
                            )
                            OutlinedButton(onClick = onRefresh) {
                                Text("Refresh", color = palette.textPrimary)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(codespaces, key = { it.id }) { cs ->
                            CodespaceCard(
                                cs = cs,
                                onConnect = { onConnect(cs) },
                                onStart = { onStart(cs) },
                                onStop = { onStop(cs) },
                                onConfigureBridge = { onConfigureBridge(cs) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CodespaceCard(
    cs: CodespaceInfo,
    onConnect: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onConfigureBridge: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val (statusColor, statusBg, pulsing) = when (cs.status) {
        CodespaceStatus.Available -> Triple(palette.success, palette.successBg, true)
        CodespaceStatus.Starting, CodespaceStatus.Rebuilding -> Triple(palette.warning, palette.warningBg, true)
        CodespaceStatus.Shutdown -> Triple(palette.textTertiary, palette.surfaceSubtle, false)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, palette.borderDefault, RoundedCornerShape(14.dp))
            .testTag("codespace_card_${cs.name}"),
        shape = RoundedCornerShape(14.dp),
        color = palette.surfaceElevated,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = cs.repoFullName,
                        color = palette.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "${cs.displayName} • ${cs.branch}",
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                StudioPillBadge(
                    text = cs.status.label,
                    textColor = statusColor,
                    backgroundColor = statusBg,
                    leadingDotColor = statusColor,
                    pulsingDot = pulsing,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = cs.machineSpecs,
                    color = palette.textTertiary,
                    fontSize = 11.5.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${cs.region} • ${cs.lastUsed}",
                    color = palette.textTertiary,
                    fontSize = 11.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                )
            }

            HorizontalDivider(color = palette.borderDefault)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (cs.status == CodespaceStatus.Available) {
                    Button(
                        onClick = onConnect,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("connect_codespace_${cs.name}"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color.White,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Terminal,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Workspace (:8765 & :8082)", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                    OutlinedButton(
                        onClick = onStop,
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("stop_codespace_${cs.name}"),
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Stop,
                            contentDescription = "Stop Codespace",
                            tint = palette.danger,
                            modifier = Modifier.size(16.dp),
                        )
                    }
                } else {
                    Button(
                        onClick = onStart,
                        enabled = cs.status != CodespaceStatus.Starting,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("start_codespace_${cs.name}"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = Color.White,
                        ),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (cs.status == CodespaceStatus.Starting) "Starting…" else "Wake Codespace",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }

                IconButton(
                    onClick = onConfigureBridge,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp))
                        .testTag("configure_bridge_${cs.name}"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SettingsEthernet,
                        contentDescription = "Configure bridge endpoints",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        }
    }
}
