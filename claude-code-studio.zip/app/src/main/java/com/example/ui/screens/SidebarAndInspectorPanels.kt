package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AlternateEmail
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.NoteAdd
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.ChatSession
import com.example.model.EditorDocumentState
import com.example.model.FileDiffEntry
import com.example.model.FsEntry
import com.example.model.InspectorTab
import com.example.model.RawActivityEntry
import com.example.model.SidebarTab
import com.example.ui.components.FileDiffCard
import com.example.ui.components.highlightSyntax
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class FsDialogAction {
    NewFile,
    NewFolder,
    Rename,
    Delete,
}

private data class PendingFsDialog(
    val action: FsDialogAction,
    val targetPath: String,
    val currentName: String = "",
)

@Composable
fun LeftWorkspaceSidebar(
    activeTab: SidebarTab,
    sessions: List<ChatSession>,
    activeSessionId: String,
    fsRootPath: String,
    fsEntriesByDir: Map<String, List<FsEntry>>,
    fsExpandedDirs: Set<String>,
    fsLoadingDirs: Set<String>,
    fsError: String?,
    showHiddenFiles: Boolean,
    activeEditorPath: String,
    onSelectTab: (SidebarTab) -> Unit,
    onNewSession: () -> Unit,
    onSelectSession: (String) -> Unit,
    onTogglePinSession: (String) -> Unit,
    onDeleteSession: (String) -> Unit,
    onRefreshDirectory: (String) -> Unit,
    onToggleDirectory: (String) -> Unit,
    onToggleHiddenFiles: () -> Unit,
    onOpenFile: (String) -> Unit,
    onCreateFile: (parentDir: String, name: String) -> Unit,
    onCreateFolder: (parentDir: String, name: String) -> Unit,
    onRenameEntry: (oldPath: String, newName: String) -> Unit,
    onDeleteEntry: (path: String) -> Unit,
    onInsertPathIntoChat: (path: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    var pendingDialog by remember { mutableStateOf<PendingFsDialog?>(null) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(palette.sidebar),
    ) {
        // Segmented Sidebar Tab Bar (Sessions / Files)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(palette.surfaceElevated)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            SidebarTab.entries.forEach { tab ->
                val selected = tab == activeTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(7.dp))
                        .background(if (selected) palette.surfaceSubtle else Color.Transparent)
                        .clickable { onSelectTab(tab) }
                        .padding(vertical = 7.dp)
                        .testTag("sidebar_tab_${tab.name.lowercase()}"),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = tab.label,
                        color = if (selected) palette.textPrimary else palette.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        fontFamily = InterFontFamily,
                    )
                }
            }
        }

        HorizontalDivider(color = palette.borderDefault)

        if (activeTab == SidebarTab.Sessions) {
            Column(modifier = Modifier.fillMaxSize()) {
                Button(
                    onClick = onNewSession,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                        .height(42.dp)
                        .testTag("new_session_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.accent,
                        contentColor = Color.White,
                    ),
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Session", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(sessions, key = { it.id }) { session ->
                        val isActive = session.id == activeSessionId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isActive) palette.surfaceSubtle else Color.Transparent)
                                .clickable { onSelectSession(session.id) }
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                ) {
                                    if (session.isPinned) {
                                        Icon(
                                            imageVector = Icons.Outlined.PushPin,
                                            contentDescription = "Pinned",
                                            tint = palette.accent,
                                            modifier = Modifier.size(12.dp),
                                        )
                                    }
                                    Text(
                                        text = session.title,
                                        color = if (isActive) palette.textPrimary else palette.textSecondary,
                                        fontSize = 12.5.sp,
                                        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Text(
                                    text = session.modelId,
                                    color = palette.textTertiary,
                                    fontSize = 10.5.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(
                                onClick = { onTogglePinSession(session.id) },
                                modifier = Modifier.size(28.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.PushPin,
                                    contentDescription = "Pin session",
                                    tint = if (session.isPinned) palette.accent else palette.textTertiary,
                                    modifier = Modifier.size(14.dp),
                                )
                            }
                            IconButton(
                                onClick = { onDeleteSession(session.id) },
                                modifier = Modifier.size(28.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteOutline,
                                    contentDescription = "Delete session",
                                    tint = palette.textTertiary,
                                    modifier = Modifier.size(14.dp),
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Complete Real Codespace File Explorer
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = fsRootPath,
                        color = palette.textSecondary,
                        fontSize = 11.5.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { pendingDialog = PendingFsDialog(FsDialogAction.NewFile, fsRootPath) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("fs_toolbar_new_file"),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.NoteAdd,
                                contentDescription = "New File",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        IconButton(
                            onClick = { pendingDialog = PendingFsDialog(FsDialogAction.NewFolder, fsRootPath) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("fs_toolbar_new_folder"),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CreateNewFolder,
                                contentDescription = "New Folder",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        IconButton(
                            onClick = onToggleHiddenFiles,
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("fs_toolbar_toggle_hidden"),
                        ) {
                            Icon(
                                imageVector = if (showHiddenFiles) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                                contentDescription = "Toggle dotfiles",
                                tint = if (showHiddenFiles) palette.accent else palette.textTertiary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        IconButton(
                            onClick = { onRefreshDirectory(fsRootPath) },
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("fs_toolbar_refresh"),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Refresh,
                                contentDescription = "Refresh files",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
                HorizontalDivider(color = palette.borderDefault)

                if (!fsError.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.dangerBg)
                            .padding(10.dp),
                    ) {
                        Text(
                            text = fsError,
                            color = palette.danger,
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp,
                        )
                    }
                }

                val flattened = remember(fsRootPath, fsEntriesByDir, fsExpandedDirs) {
                    buildFlattenedTree(fsRootPath, fsEntriesByDir, fsExpandedDirs, depth = 0)
                }

                if (flattened.isEmpty() && fsLoadingDirs.contains(fsRootPath)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = palette.accent,
                        )
                    }
                } else if (flattened.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "Connect bridge.js to browse /workspaces",
                                color = palette.textTertiary,
                                fontSize = 12.sp,
                            )
                            TextButton(onClick = { onRefreshDirectory(fsRootPath) }) {
                                Text("Reload Files", color = palette.accent, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("codespace_file_tree"),
                        contentPadding = PaddingValues(vertical = 6.dp),
                    ) {
                        items(flattened, key = { it.entry.path }) { node ->
                            val isExpanded = node.entry.path in fsExpandedDirs
                            val isLoading = node.entry.path in fsLoadingDirs
                            val isOpenInEditor = node.entry.path == activeEditorPath
                            FsTreeRow(
                                node = node,
                                isExpanded = isExpanded,
                                isLoading = isLoading,
                                isOpenInEditor = isOpenInEditor,
                                onTap = {
                                    if (node.entry.isDirectory) {
                                        onToggleDirectory(node.entry.path)
                                    } else {
                                        onOpenFile(node.entry.path)
                                    }
                                },
                                onNewFileHere = {
                                    val dir = if (node.entry.isDirectory) node.entry.path
                                    else node.entry.path.substringBeforeLast('/', fsRootPath)
                                    pendingDialog = PendingFsDialog(FsDialogAction.NewFile, dir)
                                },
                                onNewFolderHere = {
                                    val dir = if (node.entry.isDirectory) node.entry.path
                                    else node.entry.path.substringBeforeLast('/', fsRootPath)
                                    pendingDialog = PendingFsDialog(FsDialogAction.NewFolder, dir)
                                },
                                onRename = {
                                    pendingDialog = PendingFsDialog(
                                        action = FsDialogAction.Rename,
                                        targetPath = node.entry.path,
                                        currentName = node.entry.name,
                                    )
                                },
                                onDelete = {
                                    pendingDialog = PendingFsDialog(
                                        action = FsDialogAction.Delete,
                                        targetPath = node.entry.path,
                                        currentName = node.entry.name,
                                    )
                                },
                                onInsertIntoChat = { onInsertPathIntoChat(node.entry.path) },
                            )
                        }
                    }
                }
            }
        }
    }

    pendingDialog?.let { dlg ->
        FsCrudDialog(
            pending = dlg,
            onDismiss = { pendingDialog = null },
            onConfirm = { inputValue ->
                when (dlg.action) {
                    FsDialogAction.NewFile -> onCreateFile(dlg.targetPath, inputValue)
                    FsDialogAction.NewFolder -> onCreateFolder(dlg.targetPath, inputValue)
                    FsDialogAction.Rename -> onRenameEntry(dlg.targetPath, inputValue)
                    FsDialogAction.Delete -> onDeleteEntry(dlg.targetPath)
                }
                pendingDialog = null
            },
        )
    }
}

private data class FlattenedFsNode(
    val entry: FsEntry,
    val depth: Int,
)

private fun buildFlattenedTree(
    dirPath: String,
    entriesByDir: Map<String, List<FsEntry>>,
    expandedDirs: Set<String>,
    depth: Int,
): List<FlattenedFsNode> {
    val children = entriesByDir[dirPath].orEmpty()
    val result = mutableListOf<FlattenedFsNode>()
    for (entry in children) {
        result += FlattenedFsNode(entry, depth)
        if (entry.isDirectory && entry.path in expandedDirs) {
            result += buildFlattenedTree(entry.path, entriesByDir, expandedDirs, depth + 1)
        }
    }
    return result
}

@Composable
private fun FsTreeRow(
    node: FlattenedFsNode,
    isExpanded: Boolean,
    isLoading: Boolean,
    isOpenInEditor: Boolean,
    onTap: () -> Unit,
    onNewFileHere: () -> Unit,
    onNewFolderHere: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onInsertIntoChat: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isOpenInEditor) palette.accentSubtle else Color.Transparent)
            .clickable(onClick = onTap)
            .padding(start = (10 + node.depth * 14).dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (node.entry.isDirectory) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 1.6.dp,
                    color = palette.accent,
                )
            } else {
                Icon(
                    imageVector = if (isExpanded) Icons.Outlined.ExpandMore else Icons.Outlined.ChevronRight,
                    contentDescription = null,
                    tint = palette.textTertiary,
                    modifier = Modifier.size(15.dp),
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = if (isExpanded) Icons.Outlined.FolderOpen else Icons.Outlined.Folder,
                contentDescription = null,
                tint = palette.accent,
                modifier = Modifier.size(16.dp),
            )
        } else {
            Spacer(modifier = Modifier.width(19.dp))
            Icon(
                imageVector = Icons.Outlined.Description,
                contentDescription = null,
                tint = if (isOpenInEditor) palette.accent else palette.textSecondary,
                modifier = Modifier.size(15.dp),
            )
        }

        Spacer(modifier = Modifier.width(7.dp))
        Text(
            text = node.entry.name,
            color = if (isOpenInEditor) palette.textPrimary else palette.textSecondary,
            fontSize = 12.5.sp,
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = if (isOpenInEditor) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )

        Box {
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier.size(30.dp),
            ) {
                Icon(
                    imageVector = Icons.Outlined.MoreVert,
                    contentDescription = "File actions",
                    tint = palette.textTertiary,
                    modifier = Modifier.size(15.dp),
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(palette.surfaceElevated),
            ) {
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.AlternateEmail, null, tint = palette.accent, modifier = Modifier.size(16.dp)) },
                    text = { Text("Insert @path into Chat", color = palette.textPrimary, fontSize = 12.5.sp) },
                    onClick = {
                        menuExpanded = false
                        onInsertIntoChat()
                    },
                )
                if (node.entry.isDirectory) {
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Outlined.NoteAdd, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp)) },
                        text = { Text("New File", color = palette.textPrimary, fontSize = 12.5.sp) },
                        onClick = {
                            menuExpanded = false
                            onNewFileHere()
                        },
                    )
                    DropdownMenuItem(
                        leadingIcon = { Icon(Icons.Outlined.CreateNewFolder, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp)) },
                        text = { Text("New Folder", color = palette.textPrimary, fontSize = 12.5.sp) },
                        onClick = {
                            menuExpanded = false
                            onNewFolderHere()
                        },
                    )
                }
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.DriveFileRenameOutline, null, tint = palette.textSecondary, modifier = Modifier.size(16.dp)) },
                    text = { Text("Rename", color = palette.textPrimary, fontSize = 12.5.sp) },
                    onClick = {
                        menuExpanded = false
                        onRename()
                    },
                )
                DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Outlined.DeleteOutline, null, tint = palette.danger, modifier = Modifier.size(16.dp)) },
                    text = { Text("Delete", color = palette.danger, fontSize = 12.5.sp) },
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    },
                )
            }
        }
    }
}

@Composable
private fun FsCrudDialog(
    pending: PendingFsDialog,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    val palette = LocalStudioPalette.current
    var input by remember(pending) {
        mutableStateOf(if (pending.action == FsDialogAction.Rename) pending.currentName else "")
    }

    val title = when (pending.action) {
        FsDialogAction.NewFile -> "New File in ${pending.targetPath.substringAfterLast('/')}"
        FsDialogAction.NewFolder -> "New Folder in ${pending.targetPath.substringAfterLast('/')}"
        FsDialogAction.Rename -> "Rename ${pending.currentName}"
        FsDialogAction.Delete -> "Delete ${pending.currentName}?"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.surfaceElevated,
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textSecondary,
        title = { Text(title, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold) },
        text = {
            if (pending.action == FsDialogAction.Delete) {
                Text(
                    text = "This permanently deletes '${pending.targetPath}' in your Codespace.",
                    fontSize = 13.sp,
                )
            } else {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    singleLine = true,
                    placeholder = {
                        Text(
                            when (pending.action) {
                                FsDialogAction.NewFile -> "e.g. App.tsx"
                                FsDialogAction.NewFolder -> "e.g. components"
                                else -> pending.currentName
                            },
                            fontSize = 12.5.sp,
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.accent,
                        unfocusedBorderColor = palette.borderDefault,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary,
                    ),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(input) },
                enabled = pending.action == FsDialogAction.Delete || input.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (pending.action == FsDialogAction.Delete) palette.danger else palette.accent,
                    contentColor = Color.White,
                ),
            ) {
                Text(
                    when (pending.action) {
                        FsDialogAction.Delete -> "Delete"
                        FsDialogAction.Rename -> "Rename"
                        else -> "Create"
                    },
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        },
    )
}

@Composable
fun RightInspectorPanel(
    activeTab: InspectorTab,
    editorDoc: EditorDocumentState,
    fileChanges: List<FileDiffEntry>,
    codeFontSizeSp: Float,
    onSelectTab: (InspectorTab) -> Unit,
    onUpdateEditorContent: (String) -> Unit,
    onSaveEditorFile: () -> Unit,
    onInsertEditorPathIntoChat: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    var previewHighlighted by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(palette.sidebar),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InspectorTab.entries.forEach { tab ->
                    val selected = tab == activeTab
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) palette.surfaceSubtle else Color.Transparent)
                            .clickable { onSelectTab(tab) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text = tab.label,
                            color = if (selected) palette.textPrimary else palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                        )
                    }
                }
            }
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Outlined.Close, contentDescription = "Close inspector", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
            }
        }
        HorizontalDivider(color = palette.borderDefault)

        if (activeTab == InspectorTab.Editor) {
            if (editorDoc.path.isBlank()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(20.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "Select any file from the Codespace File Explorer to view & edit it here.",
                        color = palette.textTertiary,
                        fontSize = 12.5.sp,
                    )
                }
            } else {
                // Editor File Header with unsaved dot indicator + Save button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.surfaceElevated)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        if (editorDoc.isDirty) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(palette.accent),
                            )
                        }
                        Text(
                            text = editorDoc.path.removePrefix("/workspaces/"),
                            color = palette.textPrimary,
                            fontSize = 11.5.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(
                            onClick = { previewHighlighted = !previewHighlighted },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        ) {
                            Text(
                                text = if (previewHighlighted) "Edit" else "Highlight",
                                color = palette.textSecondary,
                                fontSize = 11.sp,
                            )
                        }
                        IconButton(
                            onClick = { onInsertEditorPathIntoChat(editorDoc.path) },
                            modifier = Modifier.size(30.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AlternateEmail,
                                contentDescription = "Insert @path into chat",
                                tint = palette.textSecondary,
                                modifier = Modifier.size(15.dp),
                            )
                        }
                        Button(
                            onClick = onSaveEditorFile,
                            enabled = editorDoc.isDirty && !editorDoc.isSaving,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(30.dp)
                                .testTag("editor_save_button"),
                            shape = RoundedCornerShape(7.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.accent,
                                contentColor = Color.White,
                            ),
                        ) {
                            Icon(Icons.Outlined.Save, null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (editorDoc.isSaving) "Saving…" else "Save", fontSize = 11.sp)
                        }
                    }
                }
                HorizontalDivider(color = palette.borderDefault)

                if (!editorDoc.error.isNullOrBlank()) {
                    Text(
                        text = editorDoc.error,
                        color = palette.danger,
                        fontSize = 11.5.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(palette.dangerBg)
                            .padding(8.dp),
                    )
                }

                if (editorDoc.isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.accent)
                    }
                } else {
                    val lineCount = remember(editorDoc.currentContent) {
                        editorDoc.currentContent.count { it == '\n' } + 1
                    }
                    val lineNumbersText = remember(lineCount) {
                        (1..lineCount).joinToString("\n")
                    }
                    val vScroll = rememberScrollState()
                    val hScroll = rememberScrollState()
                    val lang = remember(editorDoc.path) { editorDoc.path.substringAfterLast('.', "") }

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(palette.codeBlockBg)
                            .verticalScroll(vScroll)
                            .padding(vertical = 10.dp),
                    ) {
                        Text(
                            text = lineNumbersText,
                            color = palette.textTertiary,
                            fontSize = codeFontSizeSp.sp,
                            lineHeight = (codeFontSizeSp + 6f).sp,
                            fontFamily = JetBrainsMonoFontFamily,
                            modifier = Modifier.padding(horizontal = 10.dp),
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(hScroll)
                                .padding(end = 12.dp),
                        ) {
                            if (previewHighlighted) {
                                val highlighted = remember(editorDoc.currentContent, lang, palette) {
                                    highlightSyntax(editorDoc.currentContent, lang, palette)
                                }
                                Text(
                                    text = highlighted,
                                    fontSize = codeFontSizeSp.sp,
                                    lineHeight = (codeFontSizeSp + 6f).sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                )
                            } else {
                                BasicTextField(
                                    value = editorDoc.currentContent,
                                    onValueChange = onUpdateEditorContent,
                                    textStyle = TextStyle(
                                        color = palette.textPrimary,
                                        fontSize = codeFontSizeSp.sp,
                                        lineHeight = (codeFontSizeSp + 6f).sp,
                                        fontFamily = JetBrainsMonoFontFamily,
                                    ),
                                    cursorBrush = SolidColor(palette.accent),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("inapp_code_editor_input"),
                                )
                            }
                        }
                    }
                }
            }
        } else {
            if (fileChanges.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(20.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "No diff entries recorded in this session yet.",
                        color = palette.textTertiary,
                        fontSize = 12.5.sp,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(fileChanges, key = { it.path }) { diff ->
                        FileDiffCard(entry = diff)
                    }
                }
            }
        }
    }
}

@Composable
fun RawActivityDrawerDialog(
    entries: List<RawActivityEntry>,
    onClear: () -> Unit,
    onDismiss: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .border(1.dp, palette.borderDefault, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            color = palette.surfaceElevated,
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.sidebar)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Terminal,
                            contentDescription = null,
                            tint = palette.accent,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = "Raw Activity (${entries.size})",
                            color = palette.textPrimary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (entries.isNotEmpty()) {
                            TextButton(onClick = onClear) {
                                Text("Clear", color = palette.textSecondary, fontSize = 12.sp)
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Outlined.Close, contentDescription = "Close", tint = palette.textSecondary)
                        }
                    }
                }
                HorizontalDivider(color = palette.borderDefault)

                if (entries.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No raw CLI or tool events captured yet.",
                            color = palette.textTertiary,
                            fontSize = 13.sp,
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(entries, key = { it.id }) { item ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.codeBlockBg)
                                    .border(1.dp, palette.borderDefault, RoundedCornerShape(10.dp))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "${item.kind.uppercase()} • ${item.label}",
                                        color = palette.accent,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = JetBrainsMonoFontFamily,
                                    )
                                    Text(
                                        text = timeFmt.format(Date(item.timestampMs)),
                                        color = palette.textTertiary,
                                        fontSize = 10.5.sp,
                                        fontFamily = JetBrainsMonoFontFamily,
                                    )
                                }
                                if (item.detail.isNotBlank()) {
                                    Text(
                                        text = item.detail,
                                        color = palette.textSecondary,
                                        fontSize = 11.5.sp,
                                        lineHeight = 16.sp,
                                        fontFamily = JetBrainsMonoFontFamily,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
