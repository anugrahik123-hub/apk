package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AnsiColorRole
import com.example.model.TerminalTabSession
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette

@Composable
fun TerminalView(
    tabs: List<TerminalTabSession>,
    activeTabId: String,
    codeFontSizeSp: Float,
    onSelectTab: (String) -> Unit,
    onAddTab: () -> Unit,
    onCloseTab: (String) -> Unit,
    onRunCommand: (String) -> Unit,
    onSendSigInt: () -> Unit,
    onClearTerminal: () -> Unit,
    onResizeTerminal: (cols: Int, rows: Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val palette = LocalStudioPalette.current
    val activeTab = tabs.firstOrNull { it.id == activeTabId } ?: tabs.first()
    var inputCommand by remember(activeTab.id) { mutableStateOf("") }
    var historyIndex by remember(activeTab.id) { mutableIntStateOf(-1) }
    val listState = rememberLazyListState()

    LaunchedEffect(activeTab.lines.size) {
        if (activeTab.lines.isNotEmpty()) {
            listState.scrollToItem(activeTab.lines.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.terminalBg),
    ) {
        // Terminal Tab Bar + Live PTY Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.sidebar)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                tabs.forEach { tab ->
                    val selected = tab.id == activeTab.id
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) palette.surfaceElevated else Color.Transparent)
                            .border(
                                1.dp,
                                if (selected) palette.borderFocused else Color.Transparent,
                                RoundedCornerShape(8.dp),
                            )
                            .clickable { onSelectTab(tab.id) }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = tab.title,
                            color = if (selected) palette.textPrimary else palette.textSecondary,
                            fontSize = 11.5.sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                        if (tabs.size > 1) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Close tab",
                                tint = palette.textTertiary,
                                modifier = Modifier
                                    .size(13.dp)
                                    .clickable { onCloseTab(tab.id) },
                            )
                        }
                    }
                }
                IconButton(
                    onClick = onAddTab,
                    modifier = Modifier
                        .size(30.dp)
                        .testTag("terminal_add_tab"),
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "New terminal tab", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = "Ctrl+C",
                    color = palette.warning,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = JetBrainsMonoFontFamily,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(palette.warningBg)
                        .clickable { onSendSigInt() }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("terminal_ctrl_c"),
                )
                IconButton(
                    onClick = onClearTerminal,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(Icons.Outlined.DeleteSweep, contentDescription = "Clear terminal", tint = palette.textSecondary, modifier = Modifier.size(16.dp))
                }
            }
        }
        HorizontalDivider(color = palette.borderDefault)

        // ANSI-Compatible Live Terminal Output Stream with Dynamic pty_resize
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
        ) {
            val cols = remember(maxWidth, codeFontSizeSp) {
                ((maxWidth.value - 24f) / (codeFontSizeSp * 0.62f)).toInt().coerceIn(40, 220)
            }
            val rows = remember(maxHeight, codeFontSizeSp) {
                ((maxHeight.value - 16f) / (codeFontSizeSp + 6f)).toInt().coerceIn(12, 80)
            }

            LaunchedEffect(activeTab.id, cols, rows) {
                onResizeTerminal(cols, rows)
            }

            if (activeTab.lines.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = "Codespace Interactive Terminal (${cols}×${rows})",
                        color = palette.accent,
                        fontSize = codeFontSizeSp.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "Type any shell command below (e.g. fcc-server, git status, npm test). Output streams live over WebSocket PTY.",
                        color = palette.textTertiary,
                        fontSize = (codeFontSizeSp - 0.5f).sp,
                        fontFamily = JetBrainsMonoFontFamily,
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("terminal_output_list"),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    items(activeTab.lines, key = { it.id }) { line ->
                        val annotated = remember(line.id, palette) {
                            buildAnnotatedString {
                                line.segments.forEach { seg ->
                                    val color = when (seg.colorRole) {
                                        AnsiColorRole.Default -> palette.textPrimary
                                        AnsiColorRole.Accent -> palette.accent
                                        AnsiColorRole.Green -> palette.success
                                        AnsiColorRole.Red -> palette.danger
                                        AnsiColorRole.Amber -> palette.warning
                                        AnsiColorRole.Blue -> palette.info
                                        AnsiColorRole.Cyan -> Color(0xFF22D3EE)
                                        AnsiColorRole.Magenta -> Color(0xFFC084FC)
                                        AnsiColorRole.Muted -> palette.textTertiary
                                        AnsiColorRole.Bold -> palette.textPrimary
                                    }
                                    withStyle(
                                        SpanStyle(
                                            color = color,
                                            fontWeight = if (seg.colorRole == AnsiColorRole.Bold) FontWeight.Bold else FontWeight.Normal,
                                        ),
                                    ) {
                                        append(seg.text)
                                    }
                                }
                            }
                        }
                        Text(
                            text = annotated,
                            fontSize = codeFontSizeSp.sp,
                            lineHeight = (codeFontSizeSp + 5f).sp,
                            fontFamily = JetBrainsMonoFontFamily,
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = palette.borderDefault)

        // Interactive Command Input Row with History Arrows
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.sidebar)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "$",
                color = palette.accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = JetBrainsMonoFontFamily,
            )
            Spacer(modifier = Modifier.width(8.dp))
            BasicTextField(
                value = inputCommand,
                onValueChange = {
                    inputCommand = it
                    historyIndex = -1
                },
                singleLine = true,
                textStyle = TextStyle(
                    color = palette.textPrimary,
                    fontSize = 13.5.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                ),
                cursorBrush = SolidColor(palette.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputCommand.isNotBlank()) {
                            onRunCommand(inputCommand)
                            inputCommand = ""
                            historyIndex = -1
                        }
                    },
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
            )

            IconButton(
                onClick = {
                    if (activeTab.commandHistory.isNotEmpty()) {
                        val next = (historyIndex + 1).coerceAtMost(activeTab.commandHistory.lastIndex)
                        historyIndex = next
                        inputCommand = activeTab.commandHistory[next]
                    }
                },
                modifier = Modifier.size(34.dp),
            ) {
                Icon(Icons.Outlined.KeyboardArrowUp, contentDescription = "Previous command", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
            }
            IconButton(
                onClick = {
                    if (historyIndex > 0) {
                        historyIndex -= 1
                        inputCommand = activeTab.commandHistory[historyIndex]
                    } else {
                        historyIndex = -1
                        inputCommand = ""
                    }
                },
                modifier = Modifier.size(34.dp),
            ) {
                Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = "Next command", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
            }
            IconButton(
                onClick = {
                    if (inputCommand.isNotBlank()) {
                        onRunCommand(inputCommand)
                        inputCommand = ""
                        historyIndex = -1
                    }
                },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("terminal_send_button"),
            ) {
                Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Run command", tint = palette.accent, modifier = Modifier.size(17.dp))
            }
        }
    }
}
