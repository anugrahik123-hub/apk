package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BridgeIncomingEvent
import com.example.data.DeviceTokenPollResult
import com.example.data.GitHubCodespacesRepository
import com.example.data.LiveCodespaceBridgeService
import com.example.data.StudioPreferencesStore
import com.example.model.AiModelOption
import com.example.model.AnsiColorRole
import com.example.model.AnsiSegment
import com.example.model.AppScreen
import com.example.model.AttachmentType
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.example.model.ConnectionState
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.DeviceOAuthFlowState
import com.example.model.EditorDocumentState
import com.example.model.EffortLevel
import com.example.model.FccServerStatus
import com.example.model.FsEntry
import com.example.model.InspectorTab
import com.example.model.MessageRole
import com.example.model.RawActivityEntry
import com.example.model.RealModelsCatalog
import com.example.model.SidebarTab
import com.example.model.StudioSettings
import com.example.model.TerminalLine
import com.example.model.TerminalTabSession
import com.example.model.WorkspaceTab
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID
import java.util.concurrent.TimeUnit

data class StudioUiState(
    val currentScreen: AppScreen = AppScreen.Login,
    val isInitializing: Boolean = true,
    val isAuthenticating: Boolean = false,
    val authError: String? = null,
    val githubUserLogin: String = "",
    val deviceOAuth: DeviceOAuthFlowState? = null,

    // Codespaces Dashboard
    val codespaces: List<CodespaceInfo> = emptyList(),
    val isLoadingCodespaces: Boolean = false,
    val dashboardMessage: String? = null,
    val activeCodespace: CodespaceInfo? = null,
    val bridgeConfigs: Map<String, BridgeConfig> = emptyMap(),
    val bridgeConfigDialogTarget: CodespaceInfo? = null,
    val bridgeTestResult: BridgeTestResult? = null,
    val isTestingBridge: Boolean = false,

    // Workspace Shell
    val activeWorkspaceTab: WorkspaceTab = WorkspaceTab.ClaudeCode,
    val activeSidebarTab: SidebarTab = SidebarTab.Sessions,
    val activeInspectorTab: InspectorTab = InspectorTab.Editor,
    val connectionState: ConnectionState = ConnectionState.Disconnected,
    val connectionErrorBanner: String? = null,
    val showLeftDrawerMobile: Boolean = false,
    val showRightInspector: Boolean = false,
    val showRawActivityDrawer: Boolean = false,
    val showSettingsDialog: Boolean = false,
    val showCommandPalette: Boolean = false,
    val snackbarMessage: String? = null,

    // Claude Code Sessions & Controls (Zero fake models, zero permission prompts)
    val sessions: List<ChatSession> = emptyList(),
    val activeSessionId: String = "",
    val availableModels: List<AiModelOption> = RealModelsCatalog.cliDefaultModels,
    val isRefreshingModels: Boolean = false,
    val selectedModelId: String = "claude-sonnet-4-6",
    val selectedEffort: EffortLevel = EffortLevel.High,
    val composerText: String = "",
    val pendingAttachments: List<ContextAttachment> = emptyList(),
    val isAssistantStreaming: Boolean = false,
    val rawActivityLog: List<RawActivityEntry> = emptyList(),

    // Real Codespace File Explorer & In-App Code Editor
    val fsRootPath: String = "/workspaces",
    val fsEntriesByDir: Map<String, List<FsEntry>> = emptyMap(),
    val fsExpandedDirs: Set<String> = setOf("/workspaces"),
    val fsLoadingDirs: Set<String> = emptySet(),
    val fsError: String? = null,
    val editorDoc: EditorDocumentState = EditorDocumentState(),

    // FCC Admin (:8082)
    val fccServerStatus: FccServerStatus = FccServerStatus.Unknown,
    val fccWebViewReloadNonce: Int = 0,

    // Embedded Native Terminal
    val terminalTabs: List<TerminalTabSession> = listOf(
        TerminalTabSession(id = "term-bash-1", title = "bash", cwd = "/workspaces"),
    ),
    val activeTerminalTabId: String = "term-bash-1",

    // Global Settings
    val settings: StudioSettings = StudioSettings(),
) {
    val activeSession: ChatSession?
        get() = sessions.firstOrNull { it.id == activeSessionId } ?: sessions.firstOrNull()

    val selectedModel: AiModelOption
        get() = availableModels.firstOrNull { it.id == selectedModelId }
            ?: AiModelOption(
                id = selectedModelId,
                displayName = selectedModelId,
                provider = if (selectedModelId.startsWith("claude-")) "Anthropic" else "fcc-server",
                group = if (selectedModelId.startsWith("claude-")) {
                    com.example.model.ModelProviderGroup.Claude
                } else {
                    com.example.model.ModelProviderGroup.FccRouter
                },
            )

    val activeBridgeConfig: BridgeConfig
        get() {
            val cs = activeCodespace
            return if (cs != null) {
                bridgeConfigs[cs.name] ?: RealModelsCatalog.defaultBridgeConfig(cs.name)
            } else {
                BridgeConfig(codespaceName = "", wsUrl = "", fccServerUrl = "")
            }
        }

    val allKnownFiles: List<FsEntry>
        get() = fsEntriesByDir.values.flatten().filter { !it.isDirectory }.distinctBy { it.path }
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val prefsStore = StudioPreferencesStore(application.applicationContext)
    private val githubRepo = GitHubCodespacesRepository()
    private val liveBridge = LiveCodespaceBridgeService()

    private val fccProbeClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private var githubAccessToken: String = ""
    private var deviceOAuthPollJob: Job? = null

    // 60fps (16ms) delta batching buffers — zero polling when idle
    private val deltaLock = Any()
    private val pendingThinkingDeltas = HashMap<String, StringBuilder>()
    private val pendingTextDeltas = HashMap<String, StringBuilder>()
    private var flushLoopJob: Job? = null

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    init {
        observeBridgeConnection()
        observeBridgeStreamEvents()
        observeTerminalOutputEvents()
        bootstrapPersistedState()
    }

    private fun bootstrapPersistedState() {
        viewModelScope.launch {
            val persisted = prefsStore.loadAll()
            githubAccessToken = persisted.githubAccessToken

            val initialSessions = persisted.savedSessions.map { s ->
                // Recover cleanly if the app was killed mid-stream
                s.copy(
                    messages = s.messages.map { m ->
                        if (m.isStreaming) {
                            val frozen = m.elapsedMs ?: (System.currentTimeMillis() - m.startedAtMs).coerceAtLeast(0L)
                            m.copy(isStreaming = false, liveStatusLabel = "", elapsedMs = frozen)
                        } else {
                            m
                        }
                    },
                )
            }.ifEmpty {
                listOf(createEmptySession(persisted.settings.defaultModelId))
            }

            val validDefaultModel = persisted.settings.defaultModelId.takeIf {
                it.isNotBlank() && !it.contains("fable", ignoreCase = true)
            } ?: "claude-sonnet-4-6"

            val cleanedSettings = persisted.settings.copy(defaultModelId = validDefaultModel)

            _uiState.update {
                it.copy(
                    isInitializing = false,
                    settings = cleanedSettings,
                    bridgeConfigs = persisted.bridgeConfigs,
                    sessions = initialSessions,
                    activeSessionId = initialSessions.first().id,
                    selectedModelId = validDefaultModel,
                    selectedEffort = cleanedSettings.defaultEffort,
                    githubUserLogin = persisted.githubUserLogin,
                )
            }

            if (githubAccessToken.isNotBlank()) {
                verifySavedSessionAndLoadCodespaces()
            }
        }
    }

    private fun verifySavedSessionAndLoadCodespaces() {
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthenticating = true, authError = null) }
            githubRepo.fetchAuthenticatedUser(githubAccessToken).fold(
                onSuccess = { user ->
                    prefsStore.saveGitHubAuth(githubAccessToken, user.login)
                    _uiState.update {
                        it.copy(
                            isAuthenticating = false,
                            githubUserLogin = user.login,
                            currentScreen = AppScreen.Dashboard,
                        )
                    }
                    refreshCodespaces()
                },
                onFailure = { err ->
                    githubAccessToken = ""
                    prefsStore.clearGitHubAuth()
                    _uiState.update {
                        it.copy(
                            isAuthenticating = false,
                            currentScreen = AppScreen.Login,
                            authError = err.message,
                        )
                    }
                },
            )
        }
    }

    private fun observeBridgeConnection() {
        viewModelScope.launch {
            liveBridge.connectionState.collect { state ->
                val err = liveBridge.lastConnectionError.value
                _uiState.update { cur ->
                    // NEVER reset active chat state, clear streaming messages, or cancel running tasks on reconnect!
                    cur.copy(
                        connectionState = state,
                        connectionErrorBanner = if (state == ConnectionState.Disconnected && !err.isNullOrBlank()) err else null,
                    )
                }
                if (state == ConnectionState.Connected) {
                    // Refresh live directory & router models automatically once connected
                    refreshLiveModels(silent = true)
                    if (_uiState.value.fsEntriesByDir[_uiState.value.fsRootPath].isNullOrEmpty()) {
                        loadDirectory(_uiState.value.fsRootPath)
                    }
                    checkFccServerHealth()
                }
            }
        }
    }

    private fun observeBridgeStreamEvents() {
        viewModelScope.launch {
            liveBridge.streamEvents.collect { event ->
                when (event) {
                    is BridgeIncomingEvent.ThinkingDelta -> {
                        enqueueDelta(event.sessionId, thinking = event.delta, text = null)
                    }
                    is BridgeIncomingEvent.TextDelta -> {
                        enqueueDelta(event.sessionId, thinking = null, text = event.delta)
                    }
                    is BridgeIncomingEvent.StatusUpdate -> {
                        updateStreamingAssistantMessage(event.sessionId) { msg ->
                            msg.copy(liveStatusLabel = event.label)
                        }
                    }
                    is BridgeIncomingEvent.RawActivity -> {
                        val entry = RawActivityEntry(
                            id = "act-${UUID.randomUUID().toString().take(8)}",
                            timestampMs = System.currentTimeMillis(),
                            kind = event.kind,
                            label = event.label,
                            detail = event.detail,
                        )
                        _uiState.update {
                            it.copy(rawActivityLog = (listOf(entry) + it.rawActivityLog).take(200))
                        }
                    }
                    is BridgeIncomingEvent.Done -> {
                        flushPendingDeltasNow()
                        finalizeAssistantTurn(
                            sessionId = event.sessionId,
                            inputTokens = event.inputTokens,
                            outputTokens = event.outputTokens,
                            errorNotice = null,
                        )
                    }
                    is BridgeIncomingEvent.Error -> {
                        flushPendingDeltasNow()
                        finalizeAssistantTurn(
                            sessionId = event.sessionId,
                            inputTokens = 0,
                            outputTokens = 0,
                            errorNotice = event.message,
                        )
                    }
                }
            }
        }
    }

    private fun observeTerminalOutputEvents() {
        viewModelScope.launch {
            liveBridge.terminalOutputEvents.collect { output ->
                _uiState.update { state ->
                    val hasTab = state.terminalTabs.any { it.id == output.tabId }
                    val targetId = if (hasTab) output.tabId else state.activeTerminalTabId
                    state.copy(
                        terminalTabs = state.terminalTabs.map { tab ->
                            if (tab.id == targetId) {
                                tab.copy(lines = (tab.lines + output.lines).takeLast(1200))
                            } else {
                                tab
                            }
                        },
                    )
                }
            }
        }
    }

    // region 60fps Token Batching (Zero Idle Polling)

    private fun enqueueDelta(sessionId: String, thinking: String?, text: String?) {
        synchronized(deltaLock) {
            if (!thinking.isNullOrEmpty()) {
                pendingThinkingDeltas.getOrPut(sessionId) { StringBuilder() }.append(thinking)
            }
            if (!text.isNullOrEmpty()) {
                pendingTextDeltas.getOrPut(sessionId) { StringBuilder() }.append(text)
            }
            if (flushLoopJob?.isActive != true) {
                flushLoopJob = viewModelScope.launch {
                    while (isActive) {
                        delay(16L) // ~60fps batch cadence
                        val hadWork = flushPendingDeltasNow()
                        if (!hadWork) break
                    }
                }
            }
        }
    }

    private fun flushPendingDeltasNow(): Boolean {
        val thinkingSnapshot: Map<String, String>
        val textSnapshot: Map<String, String>
        synchronized(deltaLock) {
            if (pendingThinkingDeltas.isEmpty() && pendingTextDeltas.isEmpty()) {
                return false
            }
            thinkingSnapshot = pendingThinkingDeltas.mapValues { it.value.toString() }
            textSnapshot = pendingTextDeltas.mapValues { it.value.toString() }
            pendingThinkingDeltas.clear()
            pendingTextDeltas.clear()
        }

        val touchedSessions = thinkingSnapshot.keys + textSnapshot.keys
        _uiState.update { state ->
            state.copy(
                sessions = state.sessions.map { session ->
                    if (session.id !in touchedSessions) return@map session
                    val tDelta = thinkingSnapshot[session.id].orEmpty()
                    val cDelta = textSnapshot[session.id].orEmpty()
                    val idx = session.messages.indexOfLast { it.role == MessageRole.Assistant && it.isStreaming }
                    if (idx < 0) return@map session
                    val updatedMsgs = session.messages.toMutableList()
                    val target = updatedMsgs[idx]
                    val nextStatus = when {
                        cDelta.isNotEmpty() -> ""
                        tDelta.isNotEmpty() -> "Thinking…"
                        else -> target.liveStatusLabel
                    }
                    updatedMsgs[idx] = target.copy(
                        thinkingText = if (tDelta.isNotEmpty()) target.thinkingText + tDelta else target.thinkingText,
                        text = if (cDelta.isNotEmpty()) target.text + cDelta else target.text,
                        liveStatusLabel = nextStatus,
                    )
                    session.copy(messages = updatedMsgs, updatedAtMs = System.currentTimeMillis())
                },
            )
        }
        return true
    }

    private fun updateStreamingAssistantMessage(
        sessionId: String,
        transform: (ChatMessage) -> ChatMessage,
    ) {
        _uiState.update { state ->
            state.copy(
                sessions = state.sessions.map { session ->
                    if (session.id != sessionId) return@map session
                    val idx = session.messages.indexOfLast { it.role == MessageRole.Assistant && it.isStreaming }
                    if (idx < 0) return@map session
                    val updated = session.messages.toMutableList()
                    updated[idx] = transform(updated[idx])
                    session.copy(messages = updated)
                },
            )
        }
    }

    private fun finalizeAssistantTurn(
        sessionId: String,
        inputTokens: Int,
        outputTokens: Int,
        errorNotice: String?,
    ) {
        val now = System.currentTimeMillis()
        _uiState.update { state ->
            val updatedSessions = state.sessions.map { session ->
                if (session.id != sessionId) return@map session
                val idx = session.messages.indexOfLast { it.role == MessageRole.Assistant && it.isStreaming }
                if (idx < 0) return@map session
                val updated = session.messages.toMutableList()
                val msg = updated[idx]
                val frozenDuration = (now - msg.startedAtMs).coerceAtLeast(0L)
                val finalText = when {
                    !errorNotice.isNullOrBlank() && msg.text.isBlank() -> "**Error:** $errorNotice"
                    !errorNotice.isNullOrBlank() -> "${msg.text}\n\n---\n**Bridge Error:** $errorNotice"
                    else -> msg.text
                }
                updated[idx] = msg.copy(
                    text = finalText,
                    isStreaming = false,
                    liveStatusLabel = "",
                    elapsedMs = frozenDuration,
                    inputTokens = if (inputTokens > 0) inputTokens else msg.inputTokens,
                    outputTokens = if (outputTokens > 0) outputTokens else msg.outputTokens,
                )
                val nextBreakdown = if (inputTokens > 0 || outputTokens > 0) {
                    session.contextBreakdown.copy(
                        messagesTokens = session.contextBreakdown.messagesTokens + inputTokens + outputTokens,
                    )
                } else {
                    session.contextBreakdown
                }
                session.copy(
                    messages = updated,
                    contextBreakdown = nextBreakdown,
                    updatedAtMs = now,
                )
            }
            val stillStreaming = updatedSessions.any { s -> s.messages.any { it.isStreaming } }
            state.copy(
                sessions = updatedSessions,
                isAssistantStreaming = stillStreaming,
            )
        }
        persistSessions()
    }

    // endregion

    // region Real GitHub OAuth Device Flow

    fun updateOAuthConfiguration(clientId: String, oauthProxyUrl: String) {
        updateSettings {
            it.copy(
                githubOAuthClientId = clientId.trim(),
                oauthProxyUrl = oauthProxyUrl.trim(),
            )
        }
    }

    fun startGitHubDeviceOAuth() {
        val settings = _uiState.value.settings
        deviceOAuthPollJob?.cancel()
        viewModelScope.launch {
            _uiState.update { it.copy(isAuthenticating = true, authError = null, deviceOAuth = null) }
            githubRepo.startDeviceOAuthFlow(
                clientId = settings.githubOAuthClientId,
                oauthProxyUrl = settings.oauthProxyUrl,
            ).fold(
                onSuccess = { resp ->
                    _uiState.update {
                        it.copy(
                            isAuthenticating = false,
                            deviceOAuth = DeviceOAuthFlowState(
                                deviceCode = resp.deviceCode,
                                userCode = resp.userCode,
                                verificationUri = resp.verificationUri,
                                expiresInSec = resp.expiresIn,
                                intervalSec = resp.interval,
                                isPolling = true,
                                statusText = "Waiting for GitHub authorization…",
                                showInAppWebView = false,
                            ),
                        )
                    }
                    beginDeviceOAuthPolling(
                        clientId = settings.githubOAuthClientId,
                        deviceCode = resp.deviceCode,
                        initialIntervalSec = resp.interval,
                        oauthProxyUrl = settings.oauthProxyUrl,
                    )
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isAuthenticating = false,
                            authError = err.message ?: "Unable to start GitHub OAuth Device Flow.",
                        )
                    }
                },
            )
        }
    }

    private fun beginDeviceOAuthPolling(
        clientId: String,
        deviceCode: String,
        initialIntervalSec: Int,
        oauthProxyUrl: String,
    ) {
        deviceOAuthPollJob?.cancel()
        deviceOAuthPollJob = viewModelScope.launch {
            var intervalSec = initialIntervalSec.coerceAtLeast(5)
            while (isActive) {
                delay(intervalSec * 1000L)
                when (
                    val poll = githubRepo.pollDeviceOAuthToken(
                        clientId = clientId,
                        deviceCode = deviceCode,
                        currentIntervalSec = intervalSec,
                        oauthProxyUrl = oauthProxyUrl,
                    )
                ) {
                    is DeviceTokenPollResult.Pending -> Unit
                    is DeviceTokenPollResult.SlowDown -> {
                        intervalSec = poll.nextIntervalSec
                        _uiState.update { st ->
                            st.copy(
                                deviceOAuth = st.deviceOAuth?.copy(
                                    intervalSec = intervalSec,
                                    statusText = "Waiting for GitHub authorization (polling every ${intervalSec}s)…",
                                ),
                            )
                        }
                    }
                    is DeviceTokenPollResult.Success -> {
                        githubAccessToken = poll.accessToken
                        _uiState.update {
                            it.copy(
                                deviceOAuth = it.deviceOAuth?.copy(
                                    isPolling = false,
                                    showInAppWebView = false,
                                    statusText = "Authorized! Loading your GitHub account…",
                                ),
                            )
                        }
                        githubRepo.fetchAuthenticatedUser(githubAccessToken).fold(
                            onSuccess = { user ->
                                prefsStore.saveGitHubAuth(githubAccessToken, user.login)
                                _uiState.update {
                                    it.copy(
                                        githubUserLogin = user.login,
                                        deviceOAuth = null,
                                        authError = null,
                                        currentScreen = AppScreen.Dashboard,
                                    )
                                }
                                refreshCodespaces()
                            },
                            onFailure = { err ->
                                _uiState.update {
                                    it.copy(
                                        deviceOAuth = null,
                                        authError = err.message ?: "Authorized, but failed to fetch GitHub profile.",
                                    )
                                }
                            },
                        )
                        break
                    }
                    is DeviceTokenPollResult.Failure -> {
                        _uiState.update {
                            it.copy(
                                deviceOAuth = null,
                                authError = poll.message,
                            )
                        }
                        break
                    }
                }
            }
        }
    }

    fun setOAuthWebViewVisible(visible: Boolean) {
        _uiState.update { st ->
            st.copy(deviceOAuth = st.deviceOAuth?.copy(showInAppWebView = visible))
        }
    }

    fun cancelGitHubDeviceOAuth() {
        deviceOAuthPollJob?.cancel()
        _uiState.update { it.copy(deviceOAuth = null, isAuthenticating = false) }
    }

    fun signOut() {
        deviceOAuthPollJob?.cancel()
        liveBridge.disconnect()
        githubAccessToken = ""
        viewModelScope.launch {
            prefsStore.clearGitHubAuth()
        }
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Login,
                githubUserLogin = "",
                codespaces = emptyList(),
                activeCodespace = null,
                connectionState = ConnectionState.Disconnected,
                authError = null,
                deviceOAuth = null,
            )
        }
    }

    // endregion

    // region In-App Codespaces Control Center

    fun refreshCodespaces() {
        if (githubAccessToken.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingCodespaces = true, dashboardMessage = null) }
            githubRepo.fetchCodespaces(githubAccessToken).fold(
                onSuccess = { list ->
                    _uiState.update {
                        it.copy(
                            isLoadingCodespaces = false,
                            codespaces = list,
                            dashboardMessage = if (list.isEmpty()) {
                                "No Codespaces found on @${it.githubUserLogin}."
                            } else {
                                null
                            },
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            isLoadingCodespaces = false,
                            dashboardMessage = err.message ?: "Unable to fetch Codespaces.",
                        )
                    }
                },
            )
        }
    }

    fun startCodespace(cs: CodespaceInfo) {
        if (githubAccessToken.isBlank()) return
        viewModelScope.launch {
            updateCodespaceStatus(cs.name, CodespaceStatus.Starting)
            githubRepo.startCodespace(githubAccessToken, cs.name).fold(
                onSuccess = { updated ->
                    replaceCodespaceInfo(updated)
                    showSnackbar("Starting ${cs.displayName}…")
                },
                onFailure = { err ->
                    updateCodespaceStatus(cs.name, cs.status)
                    showSnackbar(err.message ?: "Failed to start Codespace.")
                },
            )
        }
    }

    fun stopCodespace(cs: CodespaceInfo) {
        if (githubAccessToken.isBlank()) return
        viewModelScope.launch {
            githubRepo.stopCodespace(githubAccessToken, cs.name).fold(
                onSuccess = { updated ->
                    replaceCodespaceInfo(updated)
                    if (_uiState.value.activeCodespace?.name == cs.name) {
                        liveBridge.disconnect()
                    }
                    showSnackbar("Stopped ${cs.displayName}.")
                },
                onFailure = { err ->
                    showSnackbar(err.message ?: "Failed to stop Codespace.")
                },
            )
        }
    }

    fun connectToCodespace(cs: CodespaceInfo) {
        val cfg = _uiState.value.bridgeConfigs[cs.name] ?: RealModelsCatalog.defaultBridgeConfig(cs.name)
        val activeSid = _uiState.value.activeSessionId.ifBlank {
            val fresh = createEmptySession(_uiState.value.selectedModelId)
            _uiState.update { it.copy(sessions = listOf(fresh), activeSessionId = fresh.id) }
            fresh.id
        }
        liveBridge.setActiveSessionForResume(activeSid, resetEventCursor = false)
        _uiState.update {
            it.copy(
                activeCodespace = cs,
                currentScreen = AppScreen.Workspace,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
                fsEntriesByDir = emptyMap(),
                fsExpandedDirs = setOf("/workspaces"),
                fsError = null,
                editorDoc = EditorDocumentState(),
            )
        }
        liveBridge.connect(cfg)
    }

    fun returnToDashboard() {
        liveBridge.disconnect()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Dashboard,
                showLeftDrawerMobile = false,
                showRightInspector = false,
                showRawActivityDrawer = false,
            )
        }
        refreshCodespaces()
    }

    fun openBridgeConfigDialog(cs: CodespaceInfo) {
        _uiState.update { it.copy(bridgeConfigDialogTarget = cs, bridgeTestResult = null) }
    }

    fun closeBridgeConfigDialog() {
        _uiState.update { it.copy(bridgeConfigDialogTarget = null, bridgeTestResult = null, isTestingBridge = false) }
    }

    fun saveBridgeConfig(config: BridgeConfig) {
        val nextMap = _uiState.value.bridgeConfigs + (config.codespaceName to config)
        _uiState.update { it.copy(bridgeConfigs = nextMap) }
        viewModelScope.launch {
            prefsStore.saveBridgeConfigs(nextMap)
        }
        if (_uiState.value.activeCodespace?.name == config.codespaceName && _uiState.value.currentScreen == AppScreen.Workspace) {
            liveBridge.connect(config)
        }
        showSnackbar("Saved bridge endpoints for ${config.codespaceName}.")
    }

    fun testBridgeConfig(config: BridgeConfig) {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingBridge = true, bridgeTestResult = null) }
            val result = liveBridge.testConnection(config)
            _uiState.update { it.copy(isTestingBridge = false, bridgeTestResult = result) }
        }
    }

    fun reconnectActiveBridge() {
        val cfg = _uiState.value.activeBridgeConfig
        if (cfg.wsUrl.isNotBlank()) {
            liveBridge.connect(cfg)
        }
    }

    private fun updateCodespaceStatus(name: String, status: CodespaceStatus) {
        _uiState.update { st ->
            st.copy(codespaces = st.codespaces.map { if (it.name == name) it.copy(status = status) else it })
        }
    }

    private fun replaceCodespaceInfo(updated: CodespaceInfo) {
        _uiState.update { st ->
            st.copy(codespaces = st.codespaces.map { if (it.name == updated.name) updated else it })
        }
    }

    // endregion

    // region Workspace Shell Navigation & Toggles

    fun selectWorkspaceTab(tab: WorkspaceTab) {
        _uiState.update { it.copy(activeWorkspaceTab = tab) }
        if (tab == WorkspaceTab.FccAdmin) {
            checkFccServerHealth()
        }
    }

    fun selectSidebarTab(tab: SidebarTab) {
        _uiState.update { it.copy(activeSidebarTab = tab) }
        if (tab == SidebarTab.Files && _uiState.value.fsEntriesByDir[_uiState.value.fsRootPath].isNullOrEmpty()) {
            loadDirectory(_uiState.value.fsRootPath)
        }
    }

    fun selectInspectorTab(tab: InspectorTab) {
        _uiState.update { it.copy(activeInspectorTab = tab) }
    }

    fun setLeftDrawerMobile(open: Boolean) {
        _uiState.update { it.copy(showLeftDrawerMobile = open) }
    }

    fun toggleRightInspector() {
        _uiState.update { it.copy(showRightInspector = !it.showRightInspector) }
    }

    fun setRawActivityDrawer(open: Boolean) {
        _uiState.update { it.copy(showRawActivityDrawer = open) }
    }

    fun clearRawActivityLog() {
        _uiState.update { it.copy(rawActivityLog = emptyList()) }
    }

    fun setSettingsDialog(open: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = open) }
    }

    fun setCommandPalette(open: Boolean) {
        _uiState.update { it.copy(showCommandPalette = open) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    // endregion

    // region Claude Code Sessions, Dynamic Models & Full-Auto Streaming

    fun refreshLiveModels(silent: Boolean = false) {
        val cfg = _uiState.value.activeBridgeConfig
        if (cfg.fccServerUrl.isBlank() && cfg.wsUrl.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingModels = true) }
            val models = liveBridge.fetchLiveModels(cfg)
            _uiState.update { st ->
                val activeId = if (models.any { it.id == st.selectedModelId }) {
                    st.selectedModelId
                } else {
                    models.firstOrNull()?.id ?: "claude-sonnet-4-6"
                }
                st.copy(
                    availableModels = models,
                    selectedModelId = activeId,
                    isRefreshingModels = false,
                )
            }
            if (!silent) {
                showSnackbar("Loaded ${models.size} live models from Codespace.")
            }
        }
    }

    fun selectModel(modelId: String) {
        _uiState.update { st ->
            st.copy(
                selectedModelId = modelId,
                sessions = st.sessions.map { s ->
                    if (s.id == st.activeSessionId) s.copy(modelId = modelId) else s
                },
            )
        }
        liveBridge.dispatchControl("/model $modelId")
        recordCliActivity("Model switched", "/model $modelId")
        persistSessions()
    }

    fun selectEffort(effort: EffortLevel) {
        _uiState.update { it.copy(selectedEffort = effort) }
        liveBridge.dispatchControl("/effort ${effort.cliValue}")
        recordCliActivity("Effort updated", "/effort ${effort.cliValue}")
    }

    fun createNewSession() {
        val fresh = createEmptySession(_uiState.value.selectedModelId)
        liveBridge.setActiveSessionForResume(fresh.id, resetEventCursor = true)
        _uiState.update {
            it.copy(
                sessions = listOf(fresh) + it.sessions,
                activeSessionId = fresh.id,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
                showLeftDrawerMobile = false,
            )
        }
        persistSessions()
    }

    fun selectSession(sessionId: String) {
        val session = _uiState.value.sessions.firstOrNull { it.id == sessionId } ?: return
        liveBridge.setActiveSessionForResume(session.id, resetEventCursor = false)
        _uiState.update {
            it.copy(
                activeSessionId = session.id,
                selectedModelId = session.modelId,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
                showLeftDrawerMobile = false,
            )
        }
    }

    fun togglePinSession(sessionId: String) {
        _uiState.update { st ->
            st.copy(
                sessions = st.sessions.map {
                    if (it.id == sessionId) it.copy(isPinned = !it.isPinned) else it
                }.sortedByDescending { it.isPinned },
            )
        }
        persistSessions()
    }

    fun deleteSession(sessionId: String) {
        _uiState.update { st ->
            val remaining = st.sessions.filterNot { it.id == sessionId }
                .ifEmpty { listOf(createEmptySession(st.selectedModelId)) }
            val nextId = if (st.activeSessionId == sessionId) remaining.first().id else st.activeSessionId
            liveBridge.setActiveSessionForResume(nextId, resetEventCursor = false)
            st.copy(sessions = remaining, activeSessionId = nextId)
        }
        persistSessions()
    }

    fun updateComposerText(text: String) {
        _uiState.update { it.copy(composerText = text) }
    }

    fun insertFilePathIntoComposer(path: String) {
        val cleanPath = path.removePrefix("/workspaces/").removePrefix("/")
        val mention = "@$cleanPath"
        _uiState.update { st ->
            val current = st.composerText
            val updatedText = if (current.isBlank()) "$mention " else "$current $mention "
            val alreadyAttached = st.pendingAttachments.any { it.pathOrUri == path }
            val nextAttachments = if (alreadyAttached) {
                st.pendingAttachments
            } else {
                st.pendingAttachments + ContextAttachment(
                    id = "att-${UUID.randomUUID().toString().take(8)}",
                    type = AttachmentType.File,
                    label = cleanPath.substringAfterLast('/'),
                    pathOrUri = path,
                )
            }
            st.copy(
                composerText = updatedText,
                pendingAttachments = nextAttachments,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
                showLeftDrawerMobile = false,
            )
        }
        showSnackbar("Inserted $mention into chat.")
    }

    fun addContextAttachment(type: AttachmentType, label: String, pathOrUri: String) {
        val att = ContextAttachment(
            id = "att-${UUID.randomUUID().toString().take(8)}",
            type = type,
            label = label,
            pathOrUri = pathOrUri,
        )
        _uiState.update { st ->
            if (st.pendingAttachments.any { it.pathOrUri == pathOrUri }) st
            else st.copy(pendingAttachments = st.pendingAttachments + att)
        }
    }

    fun removeContextAttachment(attachmentId: String) {
        _uiState.update { st ->
            st.copy(pendingAttachments = st.pendingAttachments.filterNot { it.id == attachmentId })
        }
    }

    fun sendUserPrompt() {
        val state = _uiState.value
        val promptText = state.composerText.trim()
        if (promptText.isEmpty() || state.isAssistantStreaming) return

        val session = state.activeSession ?: createEmptySession(state.selectedModelId)
        val now = System.currentTimeMillis()
        val attachments = state.pendingAttachments

        val userMsg = ChatMessage(
            id = "msg-u-${UUID.randomUUID().toString().take(8)}",
            role = MessageRole.User,
            text = promptText,
            timestampMs = now,
            startedAtMs = now,
            attachments = attachments,
        )

        val assistantStartMs = System.currentTimeMillis()
        val assistantMsg = ChatMessage(
            id = "msg-a-${UUID.randomUUID().toString().take(8)}",
            role = MessageRole.Assistant,
            text = "",
            timestampMs = assistantStartMs,
            startedAtMs = assistantStartMs,
            elapsedMs = null,
            isStreaming = true,
            liveStatusLabel = "Working on project…",
        )

        val nextTitle = if (session.messages.isEmpty()) {
            promptText.take(44).let { if (promptText.length > 44) "$it…" else it }
        } else {
            session.title
        }

        val fullPrompt = if (attachments.isEmpty()) {
            promptText
        } else {
            val refs = attachments.joinToString(" ") { "@${it.pathOrUri.removePrefix("/workspaces/")}" }
            "$promptText\n\nReferenced files: $refs"
        }

        _uiState.update { st ->
            val exists = st.sessions.any { it.id == session.id }
            val updatedSessions = if (exists) {
                st.sessions.map { s ->
                    if (s.id == session.id) {
                        s.copy(
                            title = nextTitle,
                            modelId = st.selectedModelId,
                            messages = s.messages + userMsg + assistantMsg,
                            updatedAtMs = now,
                        )
                    } else {
                        s
                    }
                }
            } else {
                listOf(
                    session.copy(
                        title = nextTitle,
                        modelId = st.selectedModelId,
                        messages = listOf(userMsg, assistantMsg),
                        updatedAtMs = now,
                    ),
                ) + st.sessions
            }

            st.copy(
                sessions = updatedSessions,
                activeSessionId = session.id,
                composerText = "",
                pendingAttachments = emptyList(),
                isAssistantStreaming = true,
            )
        }

        val dispatched = liveBridge.sendPrompt(
            sessionId = session.id,
            prompt = fullPrompt,
            modelId = state.selectedModelId,
            effort = state.selectedEffort,
        )

        if (!dispatched) {
            finalizeAssistantTurn(
                sessionId = session.id,
                inputTokens = 0,
                outputTokens = 0,
                errorNotice = liveBridge.lastConnectionError.value
                    ?: "Codespace bridge is not connected. Open Settings -> Bridge Setup and run bridge.js on port 8765.",
            )
        } else {
            persistSessions()
        }
    }

    fun stopGeneration() {
        val sid = _uiState.value.activeSessionId
        if (sid.isNotBlank()) {
            liveBridge.cancelPrompt(sid)
            flushPendingDeltasNow()
            finalizeAssistantTurn(
                sessionId = sid,
                inputTokens = 0,
                outputTokens = 0,
                errorNotice = null,
            )
            recordCliActivity("Generation stopped", "Sent cancel_prompt for session $sid")
        }
    }

    fun toggleThinkingDrawer(messageId: String) {
        _uiState.update { st ->
            st.copy(
                sessions = st.sessions.map { s ->
                    if (s.id != st.activeSessionId) s
                    else s.copy(
                        messages = s.messages.map { m ->
                            if (m.id == messageId) m.copy(isThinkingExpanded = !m.isThinkingExpanded) else m
                        },
                    )
                },
            )
        }
    }

    fun compactContext() {
        liveBridge.dispatchControl("/compact")
        recordCliActivity("Compact context", "/compact")
        _uiState.update { st ->
            st.copy(
                sessions = st.sessions.map { s ->
                    if (s.id != st.activeSessionId) s
                    else s.copy(
                        contextBreakdown = s.contextBreakdown.copy(
                            messagesTokens = (s.contextBreakdown.messagesTokens * 0.35f).toInt(),
                            toolOutputTokens = (s.contextBreakdown.toolOutputTokens * 0.25f).toInt(),
                        ),
                    )
                },
            )
        }
        showSnackbar("Sent /compact to Claude Code.")
    }

    fun clearActiveSessionConversation() {
        val sid = _uiState.value.activeSessionId
        liveBridge.dispatchControl("/clear")
        recordCliActivity("Clear session", "/clear")
        _uiState.update { st ->
            st.copy(
                sessions = st.sessions.map { s ->
                    if (s.id != sid) s
                    else s.copy(messages = emptyList(), contextBreakdown = ContextBreakdown())
                },
                isAssistantStreaming = false,
            )
        }
        persistSessions()
    }

    fun exportActiveSessionMarkdown(): String {
        val session = _uiState.value.activeSession ?: return ""
        return buildString {
            appendLine("# ${session.title}")
            appendLine("Model: ${session.modelId}")
            appendLine()
            for (msg in session.messages) {
                val heading = if (msg.role == MessageRole.User) "## User" else "## Claude"
                appendLine(heading)
                if (msg.thinkingText.isNotBlank()) {
                    appendLine("<details><summary>Thinking</summary>")
                    appendLine(msg.thinkingText)
                    appendLine("</details>")
                    appendLine()
                }
                appendLine(msg.text)
                appendLine()
            }
        }
    }

    private fun recordCliActivity(label: String, detail: String) {
        val entry = RawActivityEntry(
            id = "cli-${UUID.randomUUID().toString().take(8)}",
            timestampMs = System.currentTimeMillis(),
            kind = "cli",
            label = label,
            detail = detail,
        )
        _uiState.update {
            it.copy(rawActivityLog = (listOf(entry) + it.rawActivityLog).take(200))
        }
    }

    // endregion

    // region Real Codespace File Explorer & In-App Code Editor

    fun loadDirectory(path: String = _uiState.value.fsRootPath) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(fsLoadingDirs = it.fsLoadingDirs + path, fsError = null)
            }
            liveBridge.listDirectory(path, includeHidden = _uiState.value.settings.showHiddenFiles).fold(
                onSuccess = { entries ->
                    _uiState.update {
                        it.copy(
                            fsLoadingDirs = it.fsLoadingDirs - path,
                            fsEntriesByDir = it.fsEntriesByDir + (path to entries),
                            fsError = null,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            fsLoadingDirs = it.fsLoadingDirs - path,
                            fsError = err.message ?: "Failed to list $path.",
                        )
                    }
                },
            )
        }
    }

    fun toggleDirectoryExpanded(dirPath: String) {
        val currentlyExpanded = dirPath in _uiState.value.fsExpandedDirs
        if (currentlyExpanded) {
            _uiState.update { it.copy(fsExpandedDirs = it.fsExpandedDirs - dirPath) }
        } else {
            _uiState.update { it.copy(fsExpandedDirs = it.fsExpandedDirs + dirPath) }
            if (_uiState.value.fsEntriesByDir[dirPath] == null) {
                loadDirectory(dirPath)
            }
        }
    }

    fun toggleShowHiddenFiles() {
        val next = !_uiState.value.settings.showHiddenFiles
        updateSettings { it.copy(showHiddenFiles = next) }
        val dirsToReload = _uiState.value.fsExpandedDirs.ifEmpty { setOf(_uiState.value.fsRootPath) }
        dirsToReload.forEach { loadDirectory(it) }
    }

    fun createFileInCodespace(parentDir: String, rawFileName: String) {
        val cleanName = rawFileName.trim().trim('/')
        if (cleanName.isEmpty() || cleanName.contains("..")) {
            showSnackbar("Invalid file name.")
            return
        }
        val fullPath = "${parentDir.trimEnd('/')}/$cleanName"
        viewModelScope.launch {
            liveBridge.writeFile(fullPath, "").fold(
                onSuccess = {
                    loadDirectory(parentDir)
                    openFileInEditor(fullPath)
                    showSnackbar("Created $cleanName")
                },
                onFailure = { err ->
                    showSnackbar(err.message ?: "Failed to create file.")
                },
            )
        }
    }

    fun createFolderInCodespace(parentDir: String, rawFolderName: String) {
        val cleanName = rawFolderName.trim().trim('/')
        if (cleanName.isEmpty() || cleanName.contains("..")) {
            showSnackbar("Invalid folder name.")
            return
        }
        val fullPath = "${parentDir.trimEnd('/')}/$cleanName"
        viewModelScope.launch {
            liveBridge.createDirectory(fullPath).fold(
                onSuccess = {
                    _uiState.update { it.copy(fsExpandedDirs = it.fsExpandedDirs + parentDir) }
                    loadDirectory(parentDir)
                    showSnackbar("Created folder $cleanName")
                },
                onFailure = { err ->
                    showSnackbar(err.message ?: "Failed to create folder.")
                },
            )
        }
    }

    fun renameFsEntry(oldPath: String, rawNewName: String) {
        val cleanName = rawNewName.trim().trim('/')
        if (cleanName.isEmpty() || cleanName.contains('/') || cleanName.contains("..")) {
            showSnackbar("Enter a valid name without path separators.")
            return
        }
        val parentDir = oldPath.substringBeforeLast('/', _uiState.value.fsRootPath)
        val newPath = "${parentDir.trimEnd('/')}/$cleanName"
        viewModelScope.launch {
            liveBridge.renamePath(oldPath, newPath).fold(
                onSuccess = {
                    loadDirectory(parentDir)
                    if (_uiState.value.editorDoc.path == oldPath) {
                        _uiState.update { it.copy(editorDoc = it.editorDoc.copy(path = newPath)) }
                    }
                    showSnackbar("Renamed to $cleanName")
                },
                onFailure = { err ->
                    showSnackbar(err.message ?: "Failed to rename.")
                },
            )
        }
    }

    fun deleteFsEntry(path: String) {
        val parentDir = path.substringBeforeLast('/', _uiState.value.fsRootPath)
        viewModelScope.launch {
            liveBridge.deletePath(path).fold(
                onSuccess = {
                    loadDirectory(parentDir)
                    if (_uiState.value.editorDoc.path == path) {
                        _uiState.update { it.copy(editorDoc = EditorDocumentState()) }
                    }
                    showSnackbar("Deleted ${path.substringAfterLast('/')}")
                },
                onFailure = { err ->
                    showSnackbar(err.message ?: "Failed to delete.")
                },
            )
        }
    }

    fun openFileInEditor(path: String) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    showRightInspector = true,
                    activeInspectorTab = InspectorTab.Editor,
                    showLeftDrawerMobile = false,
                    editorDoc = EditorDocumentState(path = path, isLoading = true),
                )
            }
            liveBridge.readFile(path).fold(
                onSuccess = { content ->
                    _uiState.update {
                        it.copy(
                            editorDoc = EditorDocumentState(
                                path = path,
                                originalContent = content,
                                currentContent = content,
                                isLoading = false,
                            ),
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            editorDoc = EditorDocumentState(
                                path = path,
                                isLoading = false,
                                error = err.message ?: "Unable to read file.",
                            ),
                        )
                    }
                },
            )
        }
    }

    fun updateEditorContent(newContent: String) {
        _uiState.update {
            it.copy(editorDoc = it.editorDoc.copy(currentContent = newContent, error = null))
        }
    }

    fun saveEditorFile() {
        val doc = _uiState.value.editorDoc
        if (doc.path.isBlank() || doc.isSaving) return
        viewModelScope.launch {
            _uiState.update { it.copy(editorDoc = it.editorDoc.copy(isSaving = true, error = null)) }
            liveBridge.writeFile(doc.path, doc.currentContent).fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            editorDoc = it.editorDoc.copy(
                                originalContent = doc.currentContent,
                                isSaving = false,
                                error = null,
                            ),
                        )
                    }
                    showSnackbar("Saved ${doc.path.substringAfterLast('/')}")
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            editorDoc = it.editorDoc.copy(
                                isSaving = false,
                                error = err.message ?: "Failed to save file.",
                            ),
                        )
                    }
                },
            )
        }
    }

    // endregion

    // region FCC Server (:8082) Live Health & Process Controls

    fun checkFccServerHealth() {
        val baseUrl = _uiState.value.activeBridgeConfig.fccServerUrl.trim().trimEnd('/')
        if (baseUrl.isBlank()) {
            _uiState.update { it.copy(fccServerStatus = FccServerStatus.Stopped) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(fccServerStatus = FccServerStatus.Unknown) }
            val running = withContext(Dispatchers.IO) {
                runCatching {
                    val req = Request.Builder().url("$baseUrl/v1/models").get().build()
                    fccProbeClient.newCall(req).execute().use { it.code in 200..499 }
                }.getOrDefault(false)
            }
            _uiState.update {
                it.copy(fccServerStatus = if (running) FccServerStatus.Running else FccServerStatus.Stopped)
            }
        }
    }

    fun startFccServerInTerminal() {
        _uiState.update { it.copy(fccServerStatus = FccServerStatus.Starting) }
        runTerminalCommand("fcc-server &")
        viewModelScope.launch {
            delay(2500L)
            checkFccServerHealth()
            refreshLiveModels(silent = true)
        }
    }

    fun stopFccServerInTerminal() {
        runTerminalCommand("pkill -f fcc-server || true")
        viewModelScope.launch {
            delay(1500L)
            checkFccServerHealth()
        }
    }

    fun reloadFccWebView() {
        _uiState.update { it.copy(fccWebViewReloadNonce = it.fccWebViewReloadNonce + 1) }
        checkFccServerHealth()
    }

    // endregion

    // region Real Embedded Native Terminal

    fun selectTerminalTab(tabId: String) {
        _uiState.update { it.copy(activeTerminalTabId = tabId) }
    }

    fun addTerminalTab() {
        val nextNum = _uiState.value.terminalTabs.size + 1
        val tab = TerminalTabSession(
            id = "term-bash-$nextNum",
            title = "bash $nextNum",
            cwd = "/workspaces",
        )
        _uiState.update {
            it.copy(
                terminalTabs = it.terminalTabs + tab,
                activeTerminalTabId = tab.id,
            )
        }
    }

    fun closeTerminalTab(tabId: String) {
        _uiState.update { st ->
            if (st.terminalTabs.size <= 1) return@update st
            val remaining = st.terminalTabs.filterNot { it.id == tabId }
            val nextId = if (st.activeTerminalTabId == tabId) remaining.first().id else st.activeTerminalTabId
            st.copy(terminalTabs = remaining, activeTerminalTabId = nextId)
        }
    }

    fun clearActiveTerminal() {
        val tabId = _uiState.value.activeTerminalTabId
        _uiState.update { st ->
            st.copy(
                terminalTabs = st.terminalTabs.map {
                    if (it.id == tabId) it.copy(lines = emptyList()) else it
                },
            )
        }
    }

    fun resizeTerminal(cols: Int, rows: Int) {
        val tabId = _uiState.value.activeTerminalTabId
        liveBridge.sendPtyResize(tabId, cols, rows)
    }

    fun runTerminalCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return
        val tabId = _uiState.value.activeTerminalTabId
        val echoLine = TerminalLine(
            id = "echo-${UUID.randomUUID().toString().take(8)}",
            segments = listOf(
                AnsiSegment("$ ", AnsiColorRole.Accent),
                AnsiSegment(trimmed, AnsiColorRole.Bold),
            ),
        )

        _uiState.update { st ->
            st.copy(
                terminalTabs = st.terminalTabs.map { tab ->
                    if (tab.id == tabId) {
                        tab.copy(
                            lines = (tab.lines + echoLine).takeLast(1200),
                            commandHistory = (listOf(trimmed) + tab.commandHistory.filterNot { it == trimmed }).take(100),
                        )
                    } else {
                        tab
                    }
                },
            )
        }

        val sent = liveBridge.sendPtyInput(tabId, "$trimmed\n")
        if (!sent) {
            val errLine = TerminalLine(
                id = "err-${UUID.randomUUID().toString().take(8)}",
                segments = listOf(
                    AnsiSegment(
                        "Bridge WebSocket disconnected. Start bridge.js on port 8765 to stream live PTY output.",
                        AnsiColorRole.Red,
                    ),
                ),
            )
            _uiState.update { st ->
                st.copy(
                    terminalTabs = st.terminalTabs.map { tab ->
                        if (tab.id == tabId) tab.copy(lines = tab.lines + errLine) else tab
                    },
                )
            }
        }
    }

    fun sendTerminalSigInt() {
        val tabId = _uiState.value.activeTerminalTabId
        liveBridge.sendPtySignal(tabId, "SIGINT")
        val line = TerminalLine(
            id = "sig-${UUID.randomUUID().toString().take(8)}",
            segments = listOf(AnsiSegment("^C", AnsiColorRole.Amber)),
        )
        _uiState.update { st ->
            st.copy(
                terminalTabs = st.terminalTabs.map { tab ->
                    if (tab.id == tabId) tab.copy(lines = tab.lines + line) else tab
                },
            )
        }
    }

    // endregion

    // region Settings & Persistence

    fun updateSettings(transform: (StudioSettings) -> StudioSettings) {
        val updated = transform(_uiState.value.settings)
        _uiState.update { it.copy(settings = updated) }
        viewModelScope.launch {
            prefsStore.saveSettings(updated)
        }
    }

    private fun createEmptySession(modelId: String): ChatSession = ChatSession(
        id = "sess-${UUID.randomUUID().toString().take(8)}",
        title = "New session",
        group = "Today",
        modelId = modelId,
        updatedAtMs = System.currentTimeMillis(),
    )

    private fun persistSessions() {
        val snapshot = _uiState.value.sessions
        viewModelScope.launch {
            prefsStore.saveSessions(snapshot)
        }
    }

    override fun onCleared() {
        super.onCleared()
        deviceOAuthPollJob?.cancel()
        flushLoopJob?.cancel()
        liveBridge.disconnect()
    }
    // endregion
}
