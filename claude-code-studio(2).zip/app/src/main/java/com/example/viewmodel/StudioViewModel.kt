package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BridgeStreamEvent
import com.example.data.CodespaceBridgeService
import com.example.data.DemoCodespaceBridgeService
import com.example.data.DemoDataFactory
import com.example.data.GitHubCodespacesRepository
import com.example.data.LiveCodespaceBridgeService
import com.example.data.StudioPreferencesStore
import com.example.data.ToolApprovalDecision
import com.example.model.AiModelOption
import com.example.model.AnsiColorRole
import com.example.model.AnsiSegment
import com.example.model.AppScreen
import com.example.model.AttachmentType
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.CodespaceInfo
import com.example.model.CodespaceStatus
import com.example.model.ConnectionState
import com.example.model.ContextAttachment
import com.example.model.ContextBreakdown
import com.example.model.DiffLine
import com.example.model.DiffLineType
import com.example.model.EffortLevel
import com.example.model.FccModelSlots
import com.example.model.FccProviderConfig
import com.example.model.FccRequestLog
import com.example.model.FccServerStatus
import com.example.model.FileDiffEntry
import com.example.model.FileNode
import com.example.model.InspectorTab
import com.example.model.MessageRole
import com.example.model.PermissionMode
import com.example.model.SidebarTab
import com.example.model.SilentCliEvent
import com.example.model.StudioSettings
import com.example.model.TerminalLine
import com.example.model.TerminalTabSession
import com.example.model.ToolCallStatus
import com.example.model.ToolType
import com.example.model.WorkspaceTab
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class StudioUiState(
    val currentScreen: AppScreen = AppScreen.Login,
    val isDemoMode: Boolean = true,
    val githubPat: String = "",
    val githubUserLogin: String = "",
    val authLoading: Boolean = false,
    val authError: String? = null,
    val codespaces: List<CodespaceInfo> = emptyList(),
    val codespacesLoading: Boolean = false,
    val codespacesError: String? = null,
    val activeCodespace: CodespaceInfo? = null,
    val bridgeConfigs: Map<String, BridgeConfig> = emptyMap(),
    val bridgeModalCodespace: CodespaceInfo? = null,
    val bridgeTesting: Boolean = false,
    val bridgeTestResult: BridgeTestResult? = null,
    val connectionState: ConnectionState = ConnectionState.DemoMode,
    val activeWorkspaceTab: WorkspaceTab = WorkspaceTab.ClaudeCode,
    val showLeftSidebar: Boolean = false,
    val sidebarTab: SidebarTab = SidebarTab.Sessions,
    val showRightInspector: Boolean = false,
    val inspectorTab: InspectorTab = InspectorTab.Changes,
    val showBottomTerminal: Boolean = false,
    val showSettingsModal: Boolean = false,
    val showCommandPalette: Boolean = false,
    val settings: StudioSettings = StudioSettings(),
    // Claude Code state
    val availableModels: List<AiModelOption> = DemoDataFactory.defaultModels,
    val selectedModelId: String = "claude-sonnet-4-6",
    val selectedEffort: EffortLevel = EffortLevel.High,
    val extendedThinkingEnabled: Boolean = true,
    val permissionMode: PermissionMode = PermissionMode.AskBeforeEdits,
    val sessionAutoAllowedTools: Set<ToolType> = emptySet(),
    val sessions: List<ChatSession> = emptyList(),
    val activeSessionId: String = "",
    val sessionSearchQuery: String = "",
    val pendingAttachments: List<ContextAttachment> = emptyList(),
    val isStreaming: Boolean = false,
    val queuedPrompt: String? = null,
    val lastSilentCliEvent: SilentCliEvent? = null,
    val repoFiles: List<FileNode> = DemoDataFactory.createDemoFileTree(),
    val selectedFilePath: String = "src/fcc_server/router.py",
    // FCC Admin state
    val fccServerStatus: FccServerStatus = FccServerStatus.Running,
    val fccShowLiveEmbed: Boolean = false,
    val fccProviders: List<FccProviderConfig> = DemoDataFactory.createDemoFccProviders(),
    val fccSlots: FccModelSlots = DemoDataFactory.createDemoFccSlots(),
    val fccLogs: List<FccRequestLog> = DemoDataFactory.createDemoFccLogs(),
    // Terminal state
    val terminalTabs: List<TerminalTabSession> = DemoDataFactory.createInitialTerminalTabs(),
    val activeTerminalTabId: String = "term-bash-1",
    val terminalFontSizeSp: Float = 12f,
    // Snackbar feedback
    val bannerToast: String? = null,
) {
    val activeSession: ChatSession?
        get() = sessions.firstOrNull { it.id == activeSessionId } ?: sessions.firstOrNull()

    val activeBridgeConfig: BridgeConfig?
        get() = activeCodespace?.let { cs ->
            bridgeConfigs[cs.name] ?: DemoDataFactory.defaultBridgeConfig(cs.name)
        }

    val flatRepoFiles: List<FileNode>
        get() = DemoDataFactory.flattenFiles(repoFiles)

    val selectedFileNode: FileNode?
        get() = flatRepoFiles.firstOrNull { it.path == selectedFilePath } ?: flatRepoFiles.firstOrNull()
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {
    private val prefsStore = StudioPreferencesStore(application)
    private val githubRepo = GitHubCodespacesRepository()
    private val demoBridge = DemoCodespaceBridgeService()
    private val liveBridge = LiveCodespaceBridgeService()

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private var activeBridge: CodespaceBridgeService = demoBridge
    private var streamingJob: Job? = null

    init {
        loadPersistedState()
        observeLiveBridge()
    }

    private fun observeLiveBridge() {
        viewModelScope.launch {
            liveBridge.connectionState.collect { conn ->
                if (!_uiState.value.isDemoMode) {
                    _uiState.update { it.copy(connectionState = conn) }
                }
            }
        }
        viewModelScope.launch {
            liveBridge.lastConnectionError.collect { err ->
                if (!_uiState.value.isDemoMode && !err.isNullOrBlank() && _uiState.value.currentScreen == AppScreen.Workspace) {
                    showToast(err)
                }
            }
        }
        viewModelScope.launch {
            liveBridge.terminalOutputEvents.collect { event ->
                if (_uiState.value.isDemoMode) return@collect
                _uiState.update { state ->
                    val targetExists = state.terminalTabs.any { it.id == event.tabId }
                    val targetTabId = if (targetExists) event.tabId else state.activeTerminalTabId
                    state.copy(
                        terminalTabs = state.terminalTabs.map { tab ->
                            if (tab.id == targetTabId) {
                                tab.copy(lines = (tab.lines + event.lines).takeLast(400))
                            } else {
                                tab
                            }
                        },
                    )
                }
            }
        }
    }

    private fun loadPersistedState() {
        viewModelScope.launch {
            val saved = prefsStore.loadAll()
            val sessions = if (saved.savedSessions.isNotEmpty()) {
                saved.savedSessions
            } else {
                DemoDataFactory.createDemoSessions()
            }
            _uiState.update { state ->
                state.copy(
                    githubPat = saved.githubPat,
                    githubUserLogin = saved.githubUserLogin,
                    settings = saved.settings,
                    bridgeConfigs = saved.bridgeConfigs,
                    selectedModelId = saved.settings.defaultModelId,
                    selectedEffort = saved.settings.defaultEffort,
                    permissionMode = saved.settings.defaultPermissionMode,
                    sessions = sessions,
                    activeSessionId = sessions.firstOrNull()?.id.orEmpty(),
                    terminalFontSizeSp = saved.settings.codeFontSizeSp,
                )
            }
        }
    }

    // region Auth & Codespaces

    fun enterDemoMode() {
        activeBridge.disconnect()
        activeBridge = demoBridge
        val demoCs = DemoDataFactory.demoCodespaces
        _uiState.update { state ->
            val updatedBridges = state.bridgeConfigs.toMutableMap()
            demoCs.forEach { cs ->
                updatedBridges.putIfAbsent(cs.name, DemoDataFactory.defaultBridgeConfig(cs.name))
            }
            val sessions = state.sessions.ifEmpty { DemoDataFactory.createDemoSessions() }
            state.copy(
                isDemoMode = true,
                authError = null,
                codespaces = demoCs,
                bridgeConfigs = updatedBridges,
                connectionState = ConnectionState.DemoMode,
                currentScreen = AppScreen.Dashboard,
                sessions = sessions,
                activeSessionId = state.activeSessionId.ifBlank { sessions.first().id },
                fccShowLiveEmbed = false,
            )
        }
    }

    fun connectWithGitHubPat(rawPat: String) {
        val pat = rawPat.trim()
        if (pat.isBlank()) {
            _uiState.update { it.copy(authError = "Please enter your GitHub Personal Access Token.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(authLoading = true, authError = null) }
            val userResult = githubRepo.verifyPat(pat)
            userResult.fold(
                onSuccess = { user ->
                    prefsStore.saveGitHubAuth(pat, user.login)
                    activeBridge.disconnect()
                    activeBridge = liveBridge
                    _uiState.update {
                        it.copy(
                            isDemoMode = false,
                            githubPat = pat,
                            githubUserLogin = user.login,
                            authLoading = false,
                            authError = null,
                            currentScreen = AppScreen.Dashboard,
                            connectionState = ConnectionState.Disconnected,
                        )
                    }
                    refreshCodespaces()
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            authLoading = false,
                            authError = err.message ?: "Unable to verify GitHub token.",
                        )
                    }
                },
            )
        }
    }

    fun logoutGitHub() {
        streamingJob?.cancel()
        activeBridge.disconnect()
        viewModelScope.launch {
            prefsStore.clearGitHubAuth()
            _uiState.update {
                it.copy(
                    githubPat = "",
                    githubUserLogin = "",
                    activeCodespace = null,
                    showSettingsModal = false,
                    currentScreen = AppScreen.Login,
                    connectionState = ConnectionState.Disconnected,
                )
            }
        }
    }

    fun refreshCodespaces() {
        val state = _uiState.value
        if (state.isDemoMode) {
            _uiState.update { it.copy(codespaces = DemoDataFactory.demoCodespaces, codespacesError = null) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(codespacesLoading = true, codespacesError = null) }
            val result = githubRepo.fetchCodespaces(state.githubPat)
            result.fold(
                onSuccess = { list ->
                    _uiState.update { current ->
                        val updatedBridges = current.bridgeConfigs.toMutableMap()
                        list.forEach { cs ->
                            updatedBridges.putIfAbsent(cs.name, DemoDataFactory.defaultBridgeConfig(cs.name))
                        }
                        current.copy(
                            codespaces = list,
                            bridgeConfigs = updatedBridges,
                            codespacesLoading = false,
                            codespacesError = null,
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            codespacesLoading = false,
                            codespacesError = err.message ?: "Failed to load Codespaces.",
                        )
                    }
                },
            )
        }
    }

    fun startCodespace(codespace: CodespaceInfo) {
        updateCodespaceStatus(codespace.name, CodespaceStatus.Starting)
        if (_uiState.value.isDemoMode) {
            viewModelScope.launch {
                delay(1_100)
                updateCodespaceStatus(codespace.name, CodespaceStatus.Available)
                showToast("${codespace.displayName} is now running.")
            }
            return
        }
        viewModelScope.launch {
            githubRepo.startCodespace(_uiState.value.githubPat, codespace.name).fold(
                onSuccess = { updated ->
                    _uiState.update { s ->
                        s.copy(codespaces = s.codespaces.map { if (it.name == updated.name) updated else it })
                    }
                    showToast("Start command sent to ${codespace.displayName}.")
                },
                onFailure = { err ->
                    updateCodespaceStatus(codespace.name, CodespaceStatus.Shutdown)
                    showToast(err.message ?: "Failed to start Codespace.")
                },
            )
        }
    }

    fun stopCodespace(codespace: CodespaceInfo) {
        if (_uiState.value.isDemoMode) {
            updateCodespaceStatus(codespace.name, CodespaceStatus.Shutdown)
            showToast("${codespace.displayName} stopped.")
            return
        }
        viewModelScope.launch {
            githubRepo.stopCodespace(_uiState.value.githubPat, codespace.name).fold(
                onSuccess = { updated ->
                    _uiState.update { s ->
                        s.copy(codespaces = s.codespaces.map { if (it.name == updated.name) updated else it })
                    }
                    showToast("Stop command sent to ${codespace.displayName}.")
                },
                onFailure = { err ->
                    showToast(err.message ?: "Failed to stop Codespace.")
                },
            )
        }
    }

    private fun updateCodespaceStatus(name: String, status: CodespaceStatus) {
        _uiState.update { s ->
            s.copy(
                codespaces = s.codespaces.map { if (it.name == name) it.copy(status = status) else it },
                activeCodespace = s.activeCodespace?.let { active ->
                    if (active.name == name) active.copy(status = status) else active
                },
            )
        }
    }

    fun connectToCodespace(codespace: CodespaceInfo) {
        val state = _uiState.value
        val config = state.bridgeConfigs[codespace.name] ?: DemoDataFactory.defaultBridgeConfig(codespace.name)
        activeBridge = if (state.isDemoMode) demoBridge else liveBridge
        activeBridge.connect(config)

        _uiState.update { current ->
            val updatedCodespaces = if (current.isDemoMode) {
                current.codespaces.map {
                    if (it.name == codespace.name) it.copy(status = CodespaceStatus.Available) else it
                }
            } else {
                current.codespaces
            }
            val activeCs = updatedCodespaces.firstOrNull { it.name == codespace.name } ?: codespace
            current.copy(
                codespaces = updatedCodespaces,
                activeCodespace = activeCs,
                currentScreen = AppScreen.Workspace,
                connectionState = if (current.isDemoMode) ConnectionState.DemoMode else liveBridge.connectionState.value,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
                fccShowLiveEmbed = !current.isDemoMode,
            )
        }

        if (!state.isDemoMode) {
            viewModelScope.launch {
                val liveModels = activeBridge.fetchLiveFccModels(config)
                _uiState.update { it.copy(availableModels = liveModels) }
            }
        }
    }

    fun returnToDashboard() {
        _uiState.update { it.copy(currentScreen = AppScreen.Dashboard) }
    }

    fun openBridgeConfigModal(codespace: CodespaceInfo) {
        _uiState.update { it.copy(bridgeModalCodespace = codespace, bridgeTestResult = null) }
    }

    fun dismissBridgeConfigModal() {
        _uiState.update { it.copy(bridgeModalCodespace = null, bridgeTestResult = null, bridgeTesting = false) }
    }

    fun saveBridgeConfig(config: BridgeConfig) {
        viewModelScope.launch {
            val updated = _uiState.value.bridgeConfigs.toMutableMap()
            updated[config.codespaceName] = config
            prefsStore.saveBridgeConfigs(updated)
            _uiState.update { it.copy(bridgeConfigs = updated) }
            if (_uiState.value.activeCodespace?.name == config.codespaceName && !_uiState.value.isDemoMode) {
                activeBridge.connect(config)
            }
            showToast("Bridge configuration saved for ${config.codespaceName}.")
        }
    }

    fun testBridgeConnection(config: BridgeConfig) {
        viewModelScope.launch {
            _uiState.update { it.copy(bridgeTesting = true, bridgeTestResult = null) }
            val result = activeBridge.testConnection(config)
            _uiState.update { it.copy(bridgeTesting = false, bridgeTestResult = result) }
        }
    }

    // endregion

    // region Workspace Shell Toggles

    fun selectWorkspaceTab(tab: WorkspaceTab) {
        _uiState.update { it.copy(activeWorkspaceTab = tab) }
    }

    fun toggleLeftSidebar() {
        _uiState.update { it.copy(showLeftSidebar = !it.showLeftSidebar) }
    }

    fun setLeftSidebarVisible(visible: Boolean) {
        _uiState.update { it.copy(showLeftSidebar = visible) }
    }

    fun selectSidebarTab(tab: SidebarTab) {
        _uiState.update { it.copy(sidebarTab = tab) }
    }

    fun toggleRightInspector() {
        _uiState.update { it.copy(showRightInspector = !it.showRightInspector) }
    }

    fun setRightInspectorVisible(visible: Boolean) {
        _uiState.update { it.copy(showRightInspector = visible) }
    }

    fun selectInspectorTab(tab: InspectorTab) {
        _uiState.update { it.copy(inspectorTab = tab) }
    }

    fun toggleBottomTerminal() {
        _uiState.update { it.copy(showBottomTerminal = !it.showBottomTerminal) }
    }

    fun setShowSettingsModal(show: Boolean) {
        _uiState.update { it.copy(showSettingsModal = show) }
    }

    fun setShowCommandPalette(show: Boolean) {
        _uiState.update { it.copy(showCommandPalette = show) }
    }

    fun clearToast() {
        _uiState.update { it.copy(bannerToast = null) }
    }

    private fun showToast(message: String) {
        _uiState.update { it.copy(bannerToast = message) }
    }

    // endregion

    // region Claude Code GUI Controls (Silent GUI-to-CLI Translation)

    private fun recordSilentCli(command: String) {
        _uiState.update {
            it.copy(
                lastSilentCliEvent = SilentCliEvent(
                    id = UUID.randomUUID().toString(),
                    command = command,
                    timestampMs = System.currentTimeMillis(),
                ),
            )
        }
    }

    fun selectModel(modelId: String) {
        val dispatched = activeBridge.setModel(modelId)
        val model = _uiState.value.availableModels.firstOrNull { it.id == modelId }
        val maxTokens = (model?.contextWindowK ?: 200) * 1000
        _uiState.update { state ->
            val updatedSessions = state.sessions.map { sess ->
                if (sess.id == state.activeSessionId) {
                    sess.copy(
                        modelId = modelId,
                        contextBreakdown = sess.contextBreakdown.copy(maxTokens = maxTokens),
                    )
                } else {
                    sess
                }
            }
            state.copy(selectedModelId = modelId, sessions = updatedSessions)
        }
        recordSilentCli(dispatched)
        showToast("Model synced → ${model?.displayName ?: modelId}")
        persistSessionsAsync()
    }

    fun selectEffort(effort: EffortLevel) {
        val dispatched = activeBridge.setEffort(effort, _uiState.value.extendedThinkingEnabled)
        _uiState.update { it.copy(selectedEffort = effort) }
        recordSilentCli(dispatched)
        showToast("Effort synced → ${effort.label}")
    }

    fun toggleExtendedThinking(enabled: Boolean) {
        val dispatched = activeBridge.setEffort(_uiState.value.selectedEffort, enabled)
        _uiState.update { it.copy(extendedThinkingEnabled = enabled) }
        recordSilentCli(dispatched)
    }

    fun selectPermissionMode(mode: PermissionMode) {
        val dispatched = activeBridge.setPermissionMode(mode)
        _uiState.update { it.copy(permissionMode = mode) }
        recordSilentCli(dispatched)
        showToast("Permission mode → ${mode.label}")
    }

    fun compactContext() {
        viewModelScope.launch {
            val cmd = activeBridge.compactContext()
            recordSilentCli(cmd)
            updateActiveSession { session ->
                val old = session.contextBreakdown
                val compactedMessages = (old.messagesTokens * 0.35f).toInt().coerceAtLeast(1_200)
                val compactedTools = (old.toolOutputTokens * 0.25f).toInt().coerceAtLeast(400)
                session.copy(
                    contextBreakdown = old.copy(
                        messagesTokens = compactedMessages,
                        toolOutputTokens = compactedTools,
                    ),
                )
            }
            persistSessionsAsync()
            showToast("Context compacted — older turns summarized.")
        }
    }

    fun clearConversation() {
        streamingJob?.cancel()
        activeBridge.dispatchSilentCommand("/clear")
        recordSilentCli("/clear")
        updateActiveSession { session ->
            session.copy(
                messages = emptyList(),
                tasks = emptyList(),
                contextBreakdown = ContextBreakdown(
                    systemTokens = 4_200,
                    filesTokens = 0,
                    messagesTokens = 0,
                    toolOutputTokens = 0,
                    maxTokens = session.contextBreakdown.maxTokens,
                ),
            )
        }
        _uiState.update { it.copy(isStreaming = false, queuedPrompt = null, sessionAutoAllowedTools = emptySet()) }
        persistSessionsAsync()
        showToast("Conversation cleared.")
    }

    fun buildActiveTranscriptMarkdown(): String {
        val session = _uiState.value.activeSession ?: return "# Empty Session"
        val sb = StringBuilder()
        sb.appendLine("# ${session.title}")
        sb.appendLine("- Model: `${session.modelId}`")
        sb.appendLine("- Context: `${session.contextBreakdown.totalTokens} / ${session.contextBreakdown.maxTokens} tokens`")
        sb.appendLine()
        for (msg in session.messages) {
            val heading = if (msg.role == MessageRole.User) "## User" else "## Claude"
            sb.appendLine(heading)
            if (msg.thinkingText.isNotBlank()) {
                sb.appendLine("<details><summary>Thought for ${msg.thinkingDurationMs / 1000.0}s</summary>")
                sb.appendLine()
                sb.appendLine(msg.thinkingText)
                sb.appendLine("</details>")
                sb.appendLine()
            }
            sb.appendLine(msg.text)
            sb.appendLine()
            for (tc in msg.toolCalls) {
                sb.appendLine("> **Tool:** ${tc.actionLabel} `${tc.targetPathOrCommand}` (${tc.status})")
            }
            sb.appendLine()
        }
        return sb.toString()
    }

    // endregion

    // region Messaging, Streaming, Tool Approvals & Queueing

    fun addFileToContext(file: FileNode) {
        if (file.isDirectory) return
        val existing = _uiState.value.pendingAttachments.any { it.pathOrUri == file.path }
        if (existing) {
            showToast("${file.name} is already attached.")
            return
        }
        val attachment = ContextAttachment(
            id = "att-${UUID.randomUUID().toString().take(8)}",
            type = AttachmentType.File,
            label = file.name,
            pathOrUri = file.path,
            previewContent = file.content.orEmpty().take(240),
        )
        _uiState.update { it.copy(pendingAttachments = it.pendingAttachments + attachment) }
        showToast("Attached ${file.name} to prompt context.")
    }

    fun addImageAttachment(uriString: String, label: String) {
        val attachment = ContextAttachment(
            id = "img-${UUID.randomUUID().toString().take(8)}",
            type = AttachmentType.Image,
            label = label,
            pathOrUri = uriString,
        )
        _uiState.update { it.copy(pendingAttachments = it.pendingAttachments + attachment) }
    }

    fun removeAttachment(id: String) {
        _uiState.update { s -> s.copy(pendingAttachments = s.pendingAttachments.filterNot { it.id == id }) }
    }

    fun sendPrompt(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() && _uiState.value.pendingAttachments.isEmpty()) return

        if (_uiState.value.isStreaming) {
            _uiState.update { it.copy(queuedPrompt = text) }
            showToast("Message queued — will send automatically when current turn finishes.")
            return
        }

        val state = _uiState.value
        val attachments = state.pendingAttachments
        val userMessage = ChatMessage(
            id = "u-${UUID.randomUUID().toString().take(8)}",
            role = MessageRole.User,
            text = text,
            timestampMs = System.currentTimeMillis(),
            attachments = attachments,
        )
        val assistantId = "a-${UUID.randomUUID().toString().take(8)}"
        val placeholderAssistant = ChatMessage(
            id = assistantId,
            role = MessageRole.Assistant,
            text = "",
            timestampMs = System.currentTimeMillis(),
            isThinkingComplete = false,
            isThinkingExpanded = false,
            isStreaming = true,
        )

        updateActiveSession { session ->
            val newTitle = if (session.messages.isEmpty()) {
                text.take(46).ifBlank { "New Claude Session" }
            } else {
                session.title
            }
            session.copy(
                title = newTitle,
                updatedAtMs = System.currentTimeMillis(),
                messages = session.messages + userMessage + placeholderAssistant,
            )
        }

        _uiState.update { it.copy(pendingAttachments = emptyList(), isStreaming = true) }

        streamingJob?.cancel()
        streamingJob = viewModelScope.launch {
            val current = _uiState.value
            activeBridge.streamPrompt(
                prompt = text,
                attachments = attachments,
                modelId = current.selectedModelId,
                effort = current.selectedEffort,
                extendedThinking = current.extendedThinkingEnabled,
                permissionMode = current.permissionMode,
                sessionAutoAllowedTools = current.sessionAutoAllowedTools,
                repoFiles = current.repoFiles,
            ).catch { err ->
                updateAssistantMessage(assistantId) { msg ->
                    msg.copy(
                        text = msg.text + "\n\n> **Bridge notice:** ${err.message ?: "Stream interrupted."}",
                        isStreaming = false,
                        isThinkingComplete = true,
                    )
                }
                finishStreamTurn()
            }.collect { event ->
                when (event) {
                    is BridgeStreamEvent.ThinkingDelta -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(
                                thinkingText = msg.thinkingText + event.delta,
                                thinkingDurationMs = event.elapsedMs,
                            )
                        }
                    }
                    is BridgeStreamEvent.ThinkingComplete -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(
                                thinkingDurationMs = event.totalMs,
                                isThinkingComplete = true,
                            )
                        }
                    }
                    is BridgeStreamEvent.TextDelta -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(text = msg.text + event.delta)
                        }
                    }
                    is BridgeStreamEvent.ToolCallProposed -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(toolCalls = msg.toolCalls + event.toolCall)
                        }
                    }
                    is BridgeStreamEvent.ToolCallUpdated -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(
                                toolCalls = msg.toolCalls.map { tc ->
                                    if (tc.id == event.toolCallId) {
                                        tc.copy(
                                            status = event.status,
                                            stdoutOutput = event.stdoutOutput,
                                            rejectionFeedback = event.rejectionFeedback,
                                        )
                                    } else {
                                        tc
                                    }
                                },
                            )
                        }
                    }
                    is BridgeStreamEvent.TaskPlanUpdated -> {
                        updateActiveSession { it.copy(tasks = event.tasks) }
                    }
                    is BridgeStreamEvent.DiffUpdated -> {
                        updateActiveSession { session ->
                            val existing = session.fileChanges.filterNot { it.path == event.diffEntry.path }
                            session.copy(fileChanges = listOf(event.diffEntry) + existing)
                        }
                        markFileGitStatus(event.diffEntry.path, "M")
                    }
                    is BridgeStreamEvent.Completed -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(
                                isStreaming = false,
                                isThinkingComplete = true,
                                inputTokens = event.inputTokens,
                                outputTokens = event.outputTokens,
                                latencyMs = event.latencyMs,
                            )
                        }
                        updateActiveSession { session ->
                            val cb = session.contextBreakdown
                            session.copy(
                                contextBreakdown = cb.copy(
                                    messagesTokens = cb.messagesTokens + event.inputTokens / 3 + event.outputTokens,
                                    toolOutputTokens = cb.toolOutputTokens + 420,
                                ),
                            )
                        }
                        appendFccLog(current.selectedModelId, event.latencyMs.toInt(), event.inputTokens + event.outputTokens)
                        finishStreamTurn()
                    }
                    is BridgeStreamEvent.Error -> {
                        updateAssistantMessage(assistantId) { msg ->
                            msg.copy(
                                text = event.message,
                                isStreaming = false,
                                isThinkingComplete = true,
                            )
                        }
                        finishStreamTurn()
                    }
                }
            }
        }
    }

    private fun finishStreamTurn() {
        val nextQueued = _uiState.value.queuedPrompt
        _uiState.update { it.copy(isStreaming = false, queuedPrompt = null) }
        persistSessionsAsync()
        if (!nextQueued.isNullOrBlank()) {
            sendPrompt(nextQueued)
        }
    }

    fun stopGeneration() {
        streamingJob?.cancel()
        streamingJob = null
        activeBridge.cancelPrompt()
        updateActiveSession { session ->
            session.copy(
                messages = session.messages.map { msg ->
                    if (msg.isStreaming) {
                        msg.copy(
                            isStreaming = false,
                            isThinkingComplete = true,
                            text = if (msg.text.isBlank()) "_Generation stopped._" else msg.text,
                        )
                    } else {
                        msg
                    }
                },
            )
        }
        _uiState.update { it.copy(isStreaming = false, queuedPrompt = null) }
        persistSessionsAsync()
    }

    fun editAndResendUserMessage(messageId: String, updatedText: String) {
        val session = _uiState.value.activeSession ?: return
        val idx = session.messages.indexOfFirst { it.id == messageId }
        if (idx < 0) return
        val kept = session.messages.take(idx)
        updateActiveSession { it.copy(messages = kept) }
        sendPrompt(updatedText)
    }

    fun retryAssistantMessage(assistantMessageId: String) {
        val session = _uiState.value.activeSession ?: return
        val idx = session.messages.indexOfFirst { it.id == assistantMessageId }
        if (idx <= 0) return
        val precedingUser = session.messages.take(idx).lastOrNull { it.role == MessageRole.User } ?: return
        val userIdx = session.messages.indexOfFirst { it.id == precedingUser.id }
        updateActiveSession { it.copy(messages = session.messages.take(userIdx)) }
        sendPrompt(precedingUser.text)
    }

    fun toggleThinkingExpanded(messageId: String) {
        updateAssistantMessage(messageId) { it.copy(isThinkingExpanded = !it.isThinkingExpanded) }
    }

    fun toggleToolOutputExpanded(messageId: String, toolCallId: String) {
        updateAssistantMessage(messageId) { msg ->
            msg.copy(
                toolCalls = msg.toolCalls.map { tc ->
                    if (tc.id == toolCallId) tc.copy(isOutputExpanded = !tc.isOutputExpanded) else tc
                },
            )
        }
    }

    fun approveToolCall(messageId: String, toolCallId: String, alwaysAllowForSession: Boolean) {
        val toolType = _uiState.value.activeSession?.messages
            ?.firstOrNull { it.id == messageId }
            ?.toolCalls
            ?.firstOrNull { it.id == toolCallId }
            ?.toolType

        if (alwaysAllowForSession && toolType != null) {
            _uiState.update { it.copy(sessionAutoAllowedTools = it.sessionAutoAllowedTools + toolType) }
        }
        activeBridge.submitToolApproval(
            toolCallId = toolCallId,
            decision = if (alwaysAllowForSession) ToolApprovalDecision.AlwaysAllowSession else ToolApprovalDecision.ApproveOnce,
        )
        recordSilentCli("approve:$toolCallId")
    }

    fun rejectToolCall(messageId: String, toolCallId: String, feedback: String) {
        activeBridge.submitToolApproval(
            toolCallId = toolCallId,
            decision = ToolApprovalDecision.Reject,
            feedback = feedback.ifBlank { "Rejected by developer" },
        )
        recordSilentCli("reject:$toolCallId")
    }

    fun applyCodeBlockToFile(suggestedFileName: String?, code: String) {
        val targetPath = suggestedFileName?.takeIf { it.isNotBlank() } ?: _uiState.value.selectedFilePath
        saveQuickFileEdit(targetPath, code)
        showToast("Applied code block to $targetPath")
    }

    // endregion

    // region Sessions & Files & Inspector

    fun createNewSession() {
        streamingJob?.cancel()
        val newSess = ChatSession(
            id = "sess-${UUID.randomUUID().toString().take(8)}",
            title = "New Session",
            group = "Today",
            modelId = _uiState.value.selectedModelId,
            updatedAtMs = System.currentTimeMillis(),
            messages = emptyList(),
            contextBreakdown = ContextBreakdown(
                systemTokens = 4_200,
                filesTokens = 0,
                messagesTokens = 0,
                toolOutputTokens = 0,
            ),
        )
        _uiState.update {
            it.copy(
                sessions = listOf(newSess) + it.sessions,
                activeSessionId = newSess.id,
                isStreaming = false,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
            )
        }
        persistSessionsAsync()
    }

    fun selectSession(sessionId: String) {
        val session = _uiState.value.sessions.firstOrNull { it.id == sessionId } ?: return
        _uiState.update {
            it.copy(
                activeSessionId = sessionId,
                selectedModelId = session.modelId,
                activeWorkspaceTab = WorkspaceTab.ClaudeCode,
            )
        }
    }

    fun renameSession(sessionId: String, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        _uiState.update { s ->
            s.copy(sessions = s.sessions.map { if (it.id == sessionId) it.copy(title = trimmed) else it })
        }
        persistSessionsAsync()
    }

    fun togglePinSession(sessionId: String) {
        _uiState.update { s ->
            s.copy(sessions = s.sessions.map { if (it.id == sessionId) it.copy(isPinned = !it.isPinned) else it })
        }
        persistSessionsAsync()
    }

    fun deleteSession(sessionId: String) {
        _uiState.update { s ->
            val remaining = s.sessions.filterNot { it.id == sessionId }
            if (remaining.isEmpty()) {
                val fresh = ChatSession(
                    id = "sess-${UUID.randomUUID().toString().take(8)}",
                    title = "New Session",
                    group = "Today",
                    modelId = s.selectedModelId,
                    updatedAtMs = System.currentTimeMillis(),
                )
                s.copy(sessions = listOf(fresh), activeSessionId = fresh.id)
            } else {
                val nextActive = if (s.activeSessionId == sessionId) remaining.first().id else s.activeSessionId
                s.copy(sessions = remaining, activeSessionId = nextActive)
            }
        }
        persistSessionsAsync()
    }

    fun updateSessionSearch(query: String) {
        _uiState.update { it.copy(sessionSearchQuery = query) }
    }

    fun openFileInInspector(filePath: String) {
        _uiState.update {
            it.copy(
                selectedFilePath = filePath,
                showRightInspector = true,
                inspectorTab = InspectorTab.FileViewer,
            )
        }
    }

    fun saveQuickFileEdit(filePath: String, newContent: String) {
        val oldContent = _uiState.value.flatRepoFiles.firstOrNull { it.path == filePath }?.content.orEmpty()
        fun updateNodes(nodes: List<FileNode>): List<FileNode> = nodes.map { node ->
            when {
                node.path == filePath -> node.copy(content = newContent, gitStatus = "M")
                node.children.isNotEmpty() -> node.copy(children = updateNodes(node.children))
                else -> node
            }
        }
        _uiState.update { it.copy(repoFiles = updateNodes(it.repoFiles)) }

        val diffLines = buildSimpleDiff(oldContent, newContent)
        val added = diffLines.count { it.type == DiffLineType.Added }
        val removed = diffLines.count { it.type == DiffLineType.Removed }
        if (added > 0 || removed > 0) {
            val entry = FileDiffEntry(filePath, added, removed, false, diffLines)
            updateActiveSession { s ->
                s.copy(fileChanges = listOf(entry) + s.fileChanges.filterNot { it.path == filePath })
            }
            persistSessionsAsync()
        }
    }

    fun stageAllFileChanges() {
        updateActiveSession { s ->
            s.copy(fileChanges = s.fileChanges.map { it.copy(isStaged = true) })
        }
        persistSessionsAsync()
        showToast("Staged all modified files in workspace.")
    }

    fun revertFileChange(path: String) {
        updateActiveSession { s ->
            s.copy(fileChanges = s.fileChanges.filterNot { it.path == path })
        }
        markFileGitStatus(path, null)
        persistSessionsAsync()
        showToast("Reverted $path to HEAD.")
    }

    private fun markFileGitStatus(path: String, status: String?) {
        fun walk(nodes: List<FileNode>): List<FileNode> = nodes.map { node ->
            when {
                node.path == path -> node.copy(gitStatus = status)
                node.children.isNotEmpty() -> node.copy(children = walk(node.children))
                else -> node
            }
        }
        _uiState.update { it.copy(repoFiles = walk(it.repoFiles)) }
    }

    private fun buildSimpleDiff(oldText: String, newText: String): List<DiffLine> {
        val oldLines = oldText.lines()
        val newLines = newText.lines()
        val out = mutableListOf<DiffLine>()
        val maxLen = maxOf(oldLines.size, newLines.size).coerceAtMost(40)
        for (i in 0 until maxLen) {
            val o = oldLines.getOrNull(i)
            val n = newLines.getOrNull(i)
            when {
                o == n && o != null -> out += DiffLine(DiffLineType.Context, i + 1, i + 1, o)
                else -> {
                    if (o != null) out += DiffLine(DiffLineType.Removed, i + 1, null, o)
                    if (n != null) out += DiffLine(DiffLineType.Added, null, i + 1, n)
                }
            }
        }
        return out
    }

    // endregion

    // region FCC Admin Server Controls

    fun startFccServer() {
        _uiState.update { it.copy(fccServerStatus = FccServerStatus.Starting) }
        viewModelScope.launch {
            runCommandInNamedTerminal("fcc-server", "fcc-server")
            delay(500)
            _uiState.update { it.copy(fccServerStatus = FccServerStatus.Running) }
            showToast("fcc-server started on port :8082")
        }
    }

    fun restartFccServer() {
        _uiState.update { it.copy(fccServerStatus = FccServerStatus.Starting) }
        viewModelScope.launch {
            sendTerminalSigInt("term-fcc-server")
            delay(250)
            runCommandInNamedTerminal("fcc-server", "fcc-server --reload")
            delay(450)
            _uiState.update { it.copy(fccServerStatus = FccServerStatus.Running) }
            showToast("fcc-server restarted cleanly.")
        }
    }

    fun stopFccServer() {
        sendTerminalSigInt("term-fcc-server")
        _uiState.update { it.copy(fccServerStatus = FccServerStatus.Stopped) }
        showToast("fcc-server stopped.")
    }

    fun setFccShowLiveEmbed(showEmbed: Boolean) {
        _uiState.update { it.copy(fccShowLiveEmbed = showEmbed) }
    }

    fun toggleFccProvider(providerId: String) {
        _uiState.update { s ->
            s.copy(
                fccProviders = s.fccProviders.map { p ->
                    if (p.id == providerId) p.copy(enabled = !p.enabled) else p
                },
            )
        }
    }

    fun updateFccSlot(slot: String, modelId: String) {
        _uiState.update { s ->
            val updatedSlots = when (slot) {
                "fable" -> s.fccSlots.copy(fableModelId = modelId)
                "opus" -> s.fccSlots.copy(opusModelId = modelId)
                "sonnet" -> s.fccSlots.copy(sonnetModelId = modelId)
                "haiku" -> s.fccSlots.copy(haikuModelId = modelId)
                else -> s.fccSlots
            }
            s.copy(fccSlots = updatedSlots)
        }
        appendFccLog(modelId, 18, 0, method = "PUT /admin/slots/$slot", slot = slot)
        showToast("Mapped $slot slot → $modelId")
    }

    private fun appendFccLog(
        modelId: String,
        latencyMs: Int,
        tokens: Int,
        method: String = "POST /v1/messages",
        slot: String = when {
            modelId.contains("fable", ignoreCase = true) -> "fable"
            modelId.contains("opus", ignoreCase = true) || modelId.contains("deepseek", ignoreCase = true) -> "opus"
            modelId.contains("haiku", ignoreCase = true) || modelId.contains("groq", ignoreCase = true) -> "haiku"
            else -> "sonnet"
        },
    ) {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        val entry = FccRequestLog(
            id = "log-${UUID.randomUUID().toString().take(6)}",
            timestamp = fmt.format(Date()),
            method = method,
            slot = slot,
            targetModel = modelId,
            statusCode = 200,
            latencyMs = latencyMs,
            tokens = tokens,
        )
        _uiState.update { s -> s.copy(fccLogs = (listOf(entry) + s.fccLogs).take(30)) }
    }

    // endregion

    // region Terminal Controls

    fun addTerminalTab() {
        val nextNum = _uiState.value.terminalTabs.size + 1
        val newTab = TerminalTabSession(
            id = "term-${UUID.randomUUID().toString().take(6)}",
            title = "bash $nextNum",
            lines = listOf(
                TerminalLine(
                    id = "init-$nextNum",
                    segments = listOf(
                        AnsiSegment("Opened new Codespace shell session (bash $nextNum).", AnsiColorRole.Muted),
                    ),
                ),
            ),
        )
        _uiState.update {
            it.copy(
                terminalTabs = it.terminalTabs + newTab,
                activeTerminalTabId = newTab.id,
            )
        }
    }

    fun selectTerminalTab(tabId: String) {
        _uiState.update { it.copy(activeTerminalTabId = tabId) }
    }

    fun closeTerminalTab(tabId: String) {
        _uiState.update { s ->
            if (s.terminalTabs.size <= 1) return@update s
            val remaining = s.terminalTabs.filterNot { it.id == tabId }
            val nextActive = if (s.activeTerminalTabId == tabId) remaining.first().id else s.activeTerminalTabId
            s.copy(terminalTabs = remaining, activeTerminalTabId = nextActive)
        }
    }

    fun clearActiveTerminal() {
        val activeId = _uiState.value.activeTerminalTabId
        _uiState.update { s ->
            s.copy(
                terminalTabs = s.terminalTabs.map { tab ->
                    if (tab.id == activeId) tab.copy(lines = emptyList()) else tab
                },
            )
        }
    }

    fun adjustTerminalFontSize(deltaSp: Float) {
        _uiState.update { s ->
            s.copy(terminalFontSizeSp = (s.terminalFontSizeSp + deltaSp).coerceIn(10f, 18f))
        }
    }

    fun runTerminalCommand(command: String) {
        val tabId = _uiState.value.activeTerminalTabId
        val trimmed = command.trim()
        if (trimmed == "clear") {
            clearActiveTerminal()
            return
        }
        viewModelScope.launch {
            executeInTab(tabId, trimmed)
        }
    }

    fun sendTerminalSigInt(tabId: String = _uiState.value.activeTerminalTabId) {
        val line = activeBridge.sendSigInt(tabId)
        _uiState.update { s ->
            s.copy(
                terminalTabs = s.terminalTabs.map { tab ->
                    if (tab.id == tabId) tab.copy(lines = tab.lines + line) else tab
                },
            )
        }
    }

    fun runQuickTerminalAction(command: String, preferFccTab: Boolean = false) {
        viewModelScope.launch {
            if (preferFccTab) {
                runCommandInNamedTerminal("fcc-server", command)
                if (command.startsWith("fcc-server")) {
                    _uiState.update { it.copy(fccServerStatus = FccServerStatus.Running) }
                }
            } else {
                executeInTab(_uiState.value.activeTerminalTabId, command)
            }
        }
    }

    private suspend fun runCommandInNamedTerminal(tabTitle: String, command: String) {
        val target = _uiState.value.terminalTabs.firstOrNull { it.title == tabTitle }
            ?: _uiState.value.terminalTabs.first()
        _uiState.update { it.copy(activeTerminalTabId = target.id) }
        executeInTab(target.id, command)
    }

    private suspend fun executeInTab(tabId: String, command: String) {
        val tab = _uiState.value.terminalTabs.firstOrNull { it.id == tabId } ?: return
        val promptLine = TerminalLine(
            id = "cmd-${UUID.randomUUID().toString().take(8)}",
            segments = listOf(
                AnsiSegment("codespace", AnsiColorRole.Green),
                AnsiSegment(" ➜ ", AnsiColorRole.Muted),
                AnsiSegment(tab.cwd, AnsiColorRole.Blue),
                AnsiSegment(" $ ", AnsiColorRole.Accent),
                AnsiSegment(command, AnsiColorRole.Default),
            ),
        )
        _uiState.update { s ->
            s.copy(
                terminalTabs = s.terminalTabs.map { t ->
                    if (t.id == tabId) {
                        t.copy(
                            lines = t.lines + promptLine,
                            commandHistory = if (command.isNotBlank()) (t.commandHistory + command).takeLast(50) else t.commandHistory,
                        )
                    } else {
                        t
                    }
                },
            )
        }
        val output = activeBridge.executeTerminalCommand(
            tabId = tabId,
            command = command,
            cwd = tab.cwd,
            repoFiles = _uiState.value.repoFiles,
        )
        if (output.isNotEmpty()) {
            _uiState.update { s ->
                s.copy(
                    terminalTabs = s.terminalTabs.map { t ->
                        if (t.id == tabId) t.copy(lines = (t.lines + output).takeLast(400)) else t
                    },
                )
            }
        }
    }

    // endregion

    // region Settings Persistence

    fun toggleDarkMode() {
        updateSettings(_uiState.value.settings.copy(darkMode = !_uiState.value.settings.darkMode))
    }

    fun updateSettings(newSettings: StudioSettings) {
        _uiState.update {
            it.copy(
                settings = newSettings,
                terminalFontSizeSp = newSettings.codeFontSizeSp,
            )
        }
        viewModelScope.launch {
            prefsStore.saveSettings(newSettings)
        }
    }

    private fun updateActiveSession(transform: (ChatSession) -> ChatSession) {
        _uiState.update { state ->
            val targetId = state.activeSessionId.ifBlank { state.sessions.firstOrNull()?.id.orEmpty() }
            state.copy(
                sessions = state.sessions.map { sess ->
                    if (sess.id == targetId) transform(sess) else sess
                },
            )
        }
    }

    private fun updateAssistantMessage(messageId: String, transform: (ChatMessage) -> ChatMessage) {
        updateActiveSession { session ->
            session.copy(
                messages = session.messages.map { msg ->
                    if (msg.id == messageId) transform(msg) else msg
                },
            )
        }
    }

    private fun persistSessionsAsync() {
        val snapshot = _uiState.value.sessions
        viewModelScope.launch {
            prefsStore.saveSessions(snapshot)
        }
    }

    override fun onCleared() {
        streamingJob?.cancel()
        activeBridge.disconnect()
        super.onCleared()
    }

    // endregion
}
