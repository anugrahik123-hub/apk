package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.ViewSidebar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionState
import com.example.model.WorkspaceTab
import com.example.ui.components.ClaudeSparkleEmblem
import com.example.ui.components.StatusDot
import com.example.ui.components.StudioPillBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalStudioPalette
import com.example.viewmodel.StudioUiState
import com.example.viewmodel.StudioViewModel
import kotlinx.coroutines.delay

@Composable
fun WorkspaceShellScreen(
    state: StudioUiState,
    viewModel: StudioViewModel,
) {
    val palette = LocalStudioPalette.current
    val context = LocalContext.current
    val activeCodespace = state.activeCodespace ?: return

    BackHandler {
        when {
            state.showCommandPalette -> viewModel.setShowCommandPalette(false)
            state.showSettingsModal -> viewModel.setShowSettingsModal(false)
            state.showRightInspector -> viewModel.setRightInspectorVisible(false)
            state.showLeftSidebar -> viewModel.setLeftSidebarVisible(false)
            state.showBottomTerminal -> viewModel.toggleBottomTerminal()
            else -> viewModel.returnToDashboard()
        }
    }

    // Auto-dismiss transient feedback toast
    LaunchedEffect(state.bannerToast) {
        if (state.bannerToast != null) {
            delay(2_600)
            viewModel.clearToast()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.canvas)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        // Top Workspace Bar (Adaptive single-row on tablets, compact two-tier on narrow phones)
        WorkspaceTopBar(
            state = state,
            onToggleSidebar = viewModel::toggleLeftSidebar,
            onSelectTab = viewModel::selectWorkspaceTab,
            onSwitchCodespace = viewModel::connectToCodespace,
            onReturnToDashboard = viewModel::returnToDashboard,
            onToggleInspector = viewModel::toggleRightInspector,
            onToggleBottomTerminal = viewModel::toggleBottomTerminal,
            onOpenCommandPalette = { viewModel.setShowCommandPalette(true) },
            onToggleTheme = viewModel::toggleDarkMode,
            onOpenSettings = { viewModel.setShowSettingsModal(true) },
        )

        // Subtle Feedback Toast Banner
        AnimatedVisibility(visible = state.bannerToast != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.accentSubtle)
                    .padding(horizontal = 14.dp, vertical = 6.dp),
            ) {
                Text(
                    text = state.bannerToast.orEmpty(),
                    color = palette.accent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }

        // Main Adaptive Workspace Canvas
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            val isExpanded = maxWidth >= 840.dp

            Row(modifier = Modifier.fillMaxSize()) {
                // Persistent Left Sidebar on Wide Screens
                if (isExpanded && state.showLeftSidebar) {
                    LeftSidebarPanel(
                        sidebarTab = state.sidebarTab,
                        sessions = state.sessions,
                        activeSessionId = state.activeSessionId,
                        sessionSearchQuery = state.sessionSearchQuery,
                        repoFiles = state.repoFiles,
                        selectedFilePath = state.selectedFilePath,
                        showCloseButton = false,
                        onSelectTab = viewModel::selectSidebarTab,
                        onNewSession = viewModel::createNewSession,
                        onSelectSession = viewModel::selectSession,
                        onRenameSession = viewModel::renameSession,
                        onTogglePinSession = viewModel::togglePinSession,
                        onDeleteSession = viewModel::deleteSession,
                        onSearchChange = viewModel::updateSessionSearch,
                        onOpenFile = viewModel::openFileInInspector,
                        onAddFileToContext = viewModel::addFileToContext,
                        onClose = { viewModel.setLeftSidebarVisible(false) },
                        modifier = Modifier.width(260.dp),
                    )
                }

                // Center Workspace Pane + Optional Bottom Terminal Drawer
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                    ) {
                        when (state.activeWorkspaceTab) {
                            WorkspaceTab.ClaudeCode -> {
                                ClaudeCodeView(
                                    repoFullName = activeCodespace.repoFullName,
                                    session = state.activeSession,
                                    availableModels = state.availableModels,
                                    selectedModelId = state.selectedModelId,
                                    selectedEffort = state.selectedEffort,
                                    extendedThinkingEnabled = state.extendedThinkingEnabled,
                                    permissionMode = state.permissionMode,
                                    pendingAttachments = state.pendingAttachments,
                                    flatRepoFiles = state.flatRepoFiles,
                                    isStreaming = state.isStreaming,
                                    queuedPrompt = state.queuedPrompt,
                                    lastSilentCliEvent = state.lastSilentCliEvent,
                                    onSendPrompt = viewModel::sendPrompt,
                                    onStopGeneration = viewModel::stopGeneration,
                                    onSelectModel = viewModel::selectModel,
                                    onSelectEffort = viewModel::selectEffort,
                                    onToggleExtendedThinking = viewModel::toggleExtendedThinking,
                                    onSelectPermissionMode = viewModel::selectPermissionMode,
                                    onCompactContext = viewModel::compactContext,
                                    onClearConversation = viewModel::clearConversation,
                                    onExportTranscript = {
                                        val md = viewModel.buildActiveTranscriptMarkdown()
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/markdown"
                                            putExtra(Intent.EXTRA_SUBJECT, "Claude Code Studio Transcript")
                                            putExtra(Intent.EXTRA_TEXT, md)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Export Markdown Transcript"))
                                    },
                                    onAttachFile = viewModel::addFileToContext,
                                    onAttachImage = viewModel::addImageAttachment,
                                    onRemoveAttachment = viewModel::removeAttachment,
                                    onEditAndResend = viewModel::editAndResendUserMessage,
                                    onRetryAssistant = viewModel::retryAssistantMessage,
                                    onToggleThinking = viewModel::toggleThinkingExpanded,
                                    onToggleToolOutput = viewModel::toggleToolOutputExpanded,
                                    onApproveTool = viewModel::approveToolCall,
                                    onRejectTool = viewModel::rejectToolCall,
                                    onApplyCodeToFile = viewModel::applyCodeBlockToFile,
                                    onOpenFile = viewModel::openFileInInspector,
                                )
                            }

                            WorkspaceTab.FccAdmin -> {
                                FccAdminView(
                                    status = state.fccServerStatus,
                                    fccServerUrl = state.activeBridgeConfig?.fccServerUrl.orEmpty(),
                                    showLiveEmbed = state.fccShowLiveEmbed,
                                    isDemoMode = state.isDemoMode,
                                    providers = state.fccProviders,
                                    slots = state.fccSlots,
                                    logs = state.fccLogs,
                                    availableModels = state.availableModels,
                                    onStartServer = viewModel::startFccServer,
                                    onRestartServer = viewModel::restartFccServer,
                                    onStopServer = viewModel::stopFccServer,
                                    onToggleShowLiveEmbed = viewModel::setFccShowLiveEmbed,
                                    onEditPortUrl = { viewModel.openBridgeConfigModal(activeCodespace) },
                                    onToggleProvider = viewModel::toggleFccProvider,
                                    onUpdateSlot = viewModel::updateFccSlot,
                                )
                            }

                            WorkspaceTab.Terminal -> {
                                IntegratedTerminalView(
                                    tabs = state.terminalTabs,
                                    activeTabId = state.activeTerminalTabId,
                                    fontSizeSp = state.terminalFontSizeSp,
                                    isDrawerMode = false,
                                    onSelectTab = viewModel::selectTerminalTab,
                                    onAddTab = viewModel::addTerminalTab,
                                    onCloseTab = viewModel::closeTerminalTab,
                                    onRunCommand = viewModel::runTerminalCommand,
                                    onQuickAction = viewModel::runQuickTerminalAction,
                                    onSendSigInt = { viewModel.sendTerminalSigInt() },
                                    onClear = viewModel::clearActiveTerminal,
                                    onAdjustFontSize = viewModel::adjustTerminalFontSize,
                                    onClickFilePath = viewModel::openFileInInspector,
                                )
                            }
                        }
                    }

                    // Collapsible Bottom Terminal Drawer (while in Claude Code or FCC Admin tab)
                    AnimatedVisibility(
                        visible = state.showBottomTerminal && state.activeWorkspaceTab != WorkspaceTab.Terminal,
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(250.dp)
                                .border(width = 1.dp, color = palette.borderFocused),
                        ) {
                            IntegratedTerminalView(
                                tabs = state.terminalTabs,
                                activeTabId = state.activeTerminalTabId,
                                fontSizeSp = state.terminalFontSizeSp,
                                isDrawerMode = true,
                                onSelectTab = viewModel::selectTerminalTab,
                                onAddTab = viewModel::addTerminalTab,
                                onCloseTab = viewModel::closeTerminalTab,
                                onRunCommand = viewModel::runTerminalCommand,
                                onQuickAction = viewModel::runQuickTerminalAction,
                                onSendSigInt = { viewModel.sendTerminalSigInt() },
                                onClear = viewModel::clearActiveTerminal,
                                onAdjustFontSize = viewModel::adjustTerminalFontSize,
                                onClickFilePath = viewModel::openFileInInspector,
                                onCloseDrawer = viewModel::toggleBottomTerminal,
                            )
                        }
                    }
                }

                // Persistent Right Inspector Panel on Wide Screens
                if (isExpanded && state.showRightInspector) {
                    RightInspectorPanel(
                        inspectorTab = state.inspectorTab,
                        fileChanges = state.activeSession?.fileChanges.orEmpty(),
                        selectedFile = state.selectedFileNode,
                        tasks = state.activeSession?.tasks.orEmpty(),
                        onSelectTab = viewModel::selectInspectorTab,
                        onStageAll = viewModel::stageAllFileChanges,
                        onRevertFile = viewModel::revertFileChange,
                        onSaveQuickEdit = viewModel::saveQuickFileEdit,
                        onAttachFile = viewModel::addFileToContext,
                        onClose = { viewModel.setRightInspectorVisible(false) },
                        modifier = Modifier.width(340.dp),
                    )
                }
            }

            // Compact / Phone Slide-Over Left Sidebar Overlay
            if (!isExpanded && state.showLeftSidebar) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .clickable { viewModel.setLeftSidebarVisible(false) },
                ) {
                    LeftSidebarPanel(
                        sidebarTab = state.sidebarTab,
                        sessions = state.sessions,
                        activeSessionId = state.activeSessionId,
                        sessionSearchQuery = state.sessionSearchQuery,
                        repoFiles = state.repoFiles,
                        selectedFilePath = state.selectedFilePath,
                        showCloseButton = true,
                        onSelectTab = viewModel::selectSidebarTab,
                        onNewSession = {
                            viewModel.createNewSession()
                            viewModel.setLeftSidebarVisible(false)
                        },
                        onSelectSession = {
                            viewModel.selectSession(it)
                            viewModel.setLeftSidebarVisible(false)
                        },
                        onRenameSession = viewModel::renameSession,
                        onTogglePinSession = viewModel::togglePinSession,
                        onDeleteSession = viewModel::deleteSession,
                        onSearchChange = viewModel::updateSessionSearch,
                        onOpenFile = {
                            viewModel.openFileInInspector(it)
                            viewModel.setLeftSidebarVisible(false)
                        },
                        onAddFileToContext = viewModel::addFileToContext,
                        onClose = { viewModel.setLeftSidebarVisible(false) },
                        modifier = Modifier
                            .width(290.dp)
                            .clickable(enabled = false) {},
                    )
                }
            }

            // Compact / Phone Slide-Over Right Inspector Overlay
            if (!isExpanded && state.showRightInspector) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .clickable { viewModel.setRightInspectorVisible(false) },
                    contentAlignment = Alignment.CenterEnd,
                ) {
                    RightInspectorPanel(
                        inspectorTab = state.inspectorTab,
                        fileChanges = state.activeSession?.fileChanges.orEmpty(),
                        selectedFile = state.selectedFileNode,
                        tasks = state.activeSession?.tasks.orEmpty(),
                        onSelectTab = viewModel::selectInspectorTab,
                        onStageAll = viewModel::stageAllFileChanges,
                        onRevertFile = viewModel::revertFileChange,
                        onSaveQuickEdit = viewModel::saveQuickFileEdit,
                        onAttachFile = viewModel::addFileToContext,
                        onClose = { viewModel.setRightInspectorVisible(false) },
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .clickable(enabled = false) {},
                    )
                }
            }
        }
    }
}

@Composable
private fun WorkspaceTopBar(
    state: StudioUiState,
    onToggleSidebar: () -> Unit,
    onSelectTab: (WorkspaceTab) -> Unit,
    onSwitchCodespace: (com.example.model.CodespaceInfo) -> Unit,
    onReturnToDashboard: () -> Unit,
    onToggleInspector: () -> Unit,
    onToggleBottomTerminal: () -> Unit,
    onOpenCommandPalette: () -> Unit,
    onToggleTheme: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val palette = LocalStudioPalette.current
    val cs = state.activeCodespace ?: return
    var switcherOpen by remember { mutableStateOf(false) }

    val connDotColor = when (state.connectionState) {
        ConnectionState.Connected -> palette.success
        ConnectionState.DemoMode -> palette.accent
        ConnectionState.Connecting, ConnectionState.Reconnecting -> palette.warning
        ConnectionState.Disconnected -> palette.danger
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.sidebar),
    ) {
        // Primary 48dp Workspace Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            // Left: Sidebar toggle + Logo + Codespace Switcher
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                IconButton(
                    onClick = onToggleSidebar,
                    modifier = Modifier.size(40.dp).testTag("toggle_sidebar_button"),
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Menu,
                        contentDescription = "Toggle left sidebar",
                        tint = if (state.showLeftSidebar) palette.accent else palette.textSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                }

                ClaudeSparkleEmblem(size = 18.dp, tint = palette.accent)

                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(palette.surface)
                            .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                            .clickable { switcherOpen = true }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("codespace_switcher_button"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        StatusDot(
                            color = connDotColor,
                            pulsing = state.connectionState == ConnectionState.Connecting ||
                                state.connectionState == ConnectionState.Reconnecting,
                            size = 6.dp,
                        )
                        Text(
                            text = cs.repoFullName.substringAfterLast("/"),
                            color = palette.textPrimary,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Icon(Icons.Outlined.ExpandMore, null, tint = palette.textSecondary, modifier = Modifier.size(14.dp))
                    }

                    DropdownMenu(
                        expanded = switcherOpen,
                        onDismissRequest = { switcherOpen = false },
                        modifier = Modifier.background(palette.surfaceElevated).width(260.dp),
                    ) {
                        state.codespaces.forEach { item ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = item.displayName,
                                            color = if (item.id == cs.id) palette.accent else palette.textPrimary,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                        Text(
                                            text = "${item.repoFullName} (${item.branch})",
                                            color = palette.textSecondary,
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontSize = 10.5.sp,
                                        )
                                    }
                                },
                                onClick = {
                                    switcherOpen = false
                                    onSwitchCodespace(item)
                                },
                            )
                        }
                        HorizontalDivider(color = palette.border)
                        DropdownMenuItem(
                            text = { Text("All Codespaces Dashboard", color = palette.accent, fontSize = 12.5.sp, fontWeight = FontWeight.Medium) },
                            leadingIcon = { Icon(Icons.Outlined.Dashboard, null, tint = palette.accent, modifier = Modifier.size(16.dp)) },
                            onClick = {
                                switcherOpen = false
                                onReturnToDashboard()
                            },
                        )
                    }
                }
            }

            // Right: Quick Toggles (Command Palette, Inspector, Bottom Terminal, Theme, Settings)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenCommandPalette,
                    modifier = Modifier.size(36.dp).testTag("command_palette_button"),
                ) {
                    Icon(Icons.Outlined.Search, contentDescription = "Open Command Palette", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = onToggleBottomTerminal,
                    modifier = Modifier.size(36.dp).testTag("toggle_bottom_terminal_button"),
                ) {
                    Icon(
                        Icons.Outlined.Terminal,
                        contentDescription = "Toggle Bottom Terminal Drawer",
                        tint = if (state.showBottomTerminal) palette.accent else palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onToggleInspector,
                    modifier = Modifier.size(36.dp).testTag("toggle_inspector_button"),
                ) {
                    Icon(
                        Icons.Outlined.ViewSidebar,
                        contentDescription = "Toggle Right Diff Inspector",
                        tint = if (state.showRightInspector) palette.accent else palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onToggleTheme,
                    modifier = Modifier.size(36.dp).testTag("workspace_theme_toggle"),
                ) {
                    Icon(
                        imageVector = if (state.settings.darkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                        contentDescription = "Toggle theme",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(18.dp),
                    )
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.size(36.dp).testTag("workspace_settings_button"),
                ) {
                    Icon(Icons.Outlined.Settings, contentDescription = "Open Settings", tint = palette.textSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Secondary Row: 3-Tab Primary Mode Segmented Control + Branch & Status Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, end = 10.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                WorkspaceTab.entries.forEach { tab ->
                    val selected = state.activeWorkspaceTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (selected) palette.accentSubtle else Color.Transparent)
                            .border(
                                width = if (selected) 1.dp else 0.dp,
                                color = if (selected) palette.accent.copy(alpha = 0.5f) else Color.Transparent,
                                shape = RoundedCornerShape(7.dp),
                            )
                            .clickable { onSelectTab(tab) }
                            .padding(vertical = 6.dp)
                            .testTag("workspace_tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = tab.label,
                            color = if (selected) palette.accent else palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.surface)
                    .border(1.dp, palette.border, RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Icon(Icons.Outlined.AccountTree, contentDescription = null, tint = palette.accent, modifier = Modifier.size(12.dp))
                Text(
                    text = cs.branch.take(12),
                    color = palette.textSecondary,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.sp,
                    maxLines = 1,
                )
            }
        }
        HorizontalDivider(color = palette.border)
    }
}
