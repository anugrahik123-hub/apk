package com.example.data

import com.example.model.AgentTask
import com.example.model.AgentTaskStatus
import com.example.model.AiModelOption
import com.example.model.AnsiColorRole
import com.example.model.AnsiSegment
import com.example.model.BridgeConfig
import com.example.model.BridgeTestResult
import com.example.model.ConnectionState
import com.example.model.ContextAttachment
import com.example.model.DiffLine
import com.example.model.DiffLineType
import com.example.model.EffortLevel
import com.example.model.FileDiffEntry
import com.example.model.FileNode
import com.example.model.ModelProviderGroup
import com.example.model.PermissionMode
import com.example.model.TerminalLine
import com.example.model.ToolCallBlock
import com.example.model.ToolCallStatus
import com.example.model.ToolType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

enum class ToolApprovalDecision {
    ApproveOnce,
    AlwaysAllowSession,
    Reject,
}

sealed interface BridgeStreamEvent {
    data class ThinkingDelta(val delta: String, val elapsedMs: Long) : BridgeStreamEvent
    data class ThinkingComplete(val totalMs: Long) : BridgeStreamEvent
    data class TextDelta(val delta: String) : BridgeStreamEvent
    data class ToolCallProposed(val toolCall: ToolCallBlock) : BridgeStreamEvent
    data class ToolCallUpdated(
        val toolCallId: String,
        val status: ToolCallStatus,
        val stdoutOutput: String,
        val rejectionFeedback: String? = null,
    ) : BridgeStreamEvent
    data class TaskPlanUpdated(val tasks: List<AgentTask>) : BridgeStreamEvent
    data class DiffUpdated(val diffEntry: FileDiffEntry) : BridgeStreamEvent
    data class Completed(val inputTokens: Int, val outputTokens: Int, val latencyMs: Long) : BridgeStreamEvent
    data class Error(val message: String) : BridgeStreamEvent
}

data class TerminalOutputEvent(
    val tabId: String,
    val lines: List<TerminalLine>,
)

interface CodespaceBridgeService {
    val isDemo: Boolean
    val connectionState: StateFlow<ConnectionState>
    val lastConnectionError: StateFlow<String?>
    val terminalOutputEvents: SharedFlow<TerminalOutputEvent>
    fun connect(config: BridgeConfig)
    fun disconnect()
    fun cancelPrompt()
    fun dispatchSilentCommand(command: String): String
    fun setModel(modelId: String): String
    fun setEffort(effort: EffortLevel, extendedThinking: Boolean): String
    fun setPermissionMode(mode: PermissionMode): String
    suspend fun compactContext(): String
    fun submitToolApproval(toolCallId: String, decision: ToolApprovalDecision, feedback: String? = null)
    fun streamPrompt(
        prompt: String,
        attachments: List<ContextAttachment>,
        modelId: String,
        effort: EffortLevel,
        extendedThinking: Boolean,
        permissionMode: PermissionMode,
        sessionAutoAllowedTools: Set<ToolType>,
        repoFiles: List<FileNode>,
    ): Flow<BridgeStreamEvent>

    suspend fun executeTerminalCommand(
        tabId: String,
        command: String,
        cwd: String,
        repoFiles: List<FileNode>,
    ): List<TerminalLine>

    fun sendSigInt(tabId: String): TerminalLine

    suspend fun testConnection(config: BridgeConfig): BridgeTestResult
    suspend fun fetchLiveFccModels(config: BridgeConfig): List<AiModelOption>
}

object BridgeUrlValidator {
    fun validateWebSocketUrl(url: String): String? {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return "WebSocket URL is required."
        if (!trimmed.startsWith("wss://") && !trimmed.startsWith("ws://")) {
            return "WebSocket URL must start with wss:// or ws://."
        }
        val httpEquiv = trimmed.replaceFirst("wss://", "https://").replaceFirst("ws://", "http://")
        if (httpEquiv.toHttpUrlOrNull() == null) return "Invalid WebSocket URL format."
        return null
    }

    fun validateHttpUrl(url: String): String? {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return "fcc-server URL is required."
        if (!trimmed.startsWith("https://") && !trimmed.startsWith("http://")) {
            return "fcc-server URL must start with https:// or http://."
        }
        if (trimmed.toHttpUrlOrNull() == null) return "Invalid URL format."
        return null
    }
}

class DemoCodespaceBridgeService : CodespaceBridgeService {
    override val isDemo: Boolean = true
    override val connectionState: StateFlow<ConnectionState> = MutableStateFlow(ConnectionState.DemoMode).asStateFlow()
    override val lastConnectionError: StateFlow<String?> = MutableStateFlow<String?>(null).asStateFlow()
    override val terminalOutputEvents: SharedFlow<TerminalOutputEvent> = MutableSharedFlow<TerminalOutputEvent>().asSharedFlow()

    private val pendingApprovals = ConcurrentHashMap<String, CompletableDeferred<Pair<ToolApprovalDecision, String?>>>()

    override fun connect(config: BridgeConfig) = Unit
    override fun cancelPrompt() = Unit
    override fun disconnect() {
        pendingApprovals.values.forEach { it.cancel() }
        pendingApprovals.clear()
    }

    override fun dispatchSilentCommand(command: String): String = command

    override fun setModel(modelId: String): String = "/model $modelId"

    override fun setEffort(effort: EffortLevel, extendedThinking: Boolean): String {
        val thinkingFlag = if (extendedThinking) " --thinking=on" else " --thinking=off"
        return "/effort ${effort.cliValue}$thinkingFlag"
    }

    override fun setPermissionMode(mode: PermissionMode): String = "--permission-mode ${mode.cliFlag}"

    override suspend fun compactContext(): String {
        delay(450)
        return "/compact"
    }

    override fun submitToolApproval(
        toolCallId: String,
        decision: ToolApprovalDecision,
        feedback: String?,
    ) {
        pendingApprovals.remove(toolCallId)?.complete(decision to feedback)
    }

    override fun streamPrompt(
        prompt: String,
        attachments: List<ContextAttachment>,
        modelId: String,
        effort: EffortLevel,
        extendedThinking: Boolean,
        permissionMode: PermissionMode,
        sessionAutoAllowedTools: Set<ToolType>,
        repoFiles: List<FileNode>,
    ): Flow<BridgeStreamEvent> = flow {
        val startedAt = System.currentTimeMillis()
        val lower = prompt.lowercase()
        val attachedNames = attachments.joinToString(", ") { it.label }.ifBlank { "src/fcc_server/router.py" }

        // 1. Stream Thinking Accordion when Extended Thinking is enabled or effort >= Medium
        if (extendedThinking || effort != EffortLevel.Low) {
            val isUltracode = effort == EffortLevel.Ultracode
            val thinkingSteps = buildList {
                add("Inspecting workspace context ($attachedNames) on model $modelId with ${effort.label} effort… ")
                if (isUltracode) {
                    add("[Ultracode Multi-Agent Orchestrator] Spinning up parallel subagents: (1) Architecture Auditor, (2) Patch Synthesizer, (3) Pytest Verifier. ")
                }
                add("Checking current permission policy (${permissionMode.label}). ")
                add(
                    if (lower.contains("test")) {
                        "Locating existing pytest fixtures in tests/test_router.py and designing edge-case coverage for failover and streaming headers. "
                    } else if (lower.contains("explain") || lower.contains("architecture")) {
                        "Mapping request lifecycle from fcc-claude CLI → fcc-server FastAPI router → ProviderRegistry → OpenAI-to-Anthropic SSE adapter. "
                    } else {
                        "Tracing router.py and stream_adapter.py to isolate potential edge cases and prepare a clean, minimal patch with zero regressions. "
                    },
                )
            }
            for (chunk in thinkingSteps) {
                delay(280)
                emit(BridgeStreamEvent.ThinkingDelta(chunk, System.currentTimeMillis() - startedAt))
            }
            emit(BridgeStreamEvent.ThinkingComplete(System.currentTimeMillis() - startedAt))
        }

        // Update live agent checklist
        val initialTasks = if (effort == EffortLevel.Ultracode) {
            listOf(
                AgentTask("task-0", "Ultracode: Spawn parallel audit & verification subagents", AgentTaskStatus.Completed),
                AgentTask("task-1", "Analyze workspace context & symbols", AgentTaskStatus.Completed),
                AgentTask("task-2", "Inspect relevant source files", AgentTaskStatus.InProgress),
                AgentTask("task-3", if (permissionMode == PermissionMode.PlanMode) "Draft architecture & change plan" else "Apply patch & run verification loop", AgentTaskStatus.Pending),
            )
        } else {
            listOf(
                AgentTask("task-1", "Analyze workspace context & symbols", AgentTaskStatus.Completed),
                AgentTask("task-2", "Inspect relevant source files", AgentTaskStatus.InProgress),
                AgentTask("task-3", if (permissionMode == PermissionMode.PlanMode) "Draft architecture & change plan" else "Apply patch & verify checks", AgentTaskStatus.Pending),
            )
        }
        emit(BridgeStreamEvent.TaskPlanUpdated(initialTasks))

        // 2. Read File tool (always safe, executes immediately)
        val readToolId = "tc-${UUID.randomUUID().toString().take(8)}"
        val targetFile = attachments.firstOrNull { it.type == com.example.model.AttachmentType.File }?.pathOrUri
            ?: if (lower.contains("test")) "tests/test_router.py" else "src/fcc_server/stream_adapter.py"
        emit(
            BridgeStreamEvent.ToolCallProposed(
                ToolCallBlock(
                    id = readToolId,
                    toolType = ToolType.ReadFile,
                    actionLabel = "Read File",
                    targetPathOrCommand = targetFile,
                    status = ToolCallStatus.Running,
                ),
            ),
        )
        delay(350)
        emit(
            BridgeStreamEvent.ToolCallUpdated(
                toolCallId = readToolId,
                status = ToolCallStatus.Executed,
                stdoutOutput = "Loaded $targetFile cleanly (UTF-8, verified git HEAD).",
            ),
        )

        // 3. Plan Mode or Explain-only prompt skips write/bash tools
        val isReadOnlyRequest = permissionMode == PermissionMode.PlanMode ||
            (lower.contains("explain") && !lower.contains("fix") && !lower.contains("refactor") && !lower.contains("write"))

        if (!isReadOnlyRequest) {
            emit(
                BridgeStreamEvent.TaskPlanUpdated(
                    listOf(
                        AgentTask("task-1", "Analyze workspace context & symbols", AgentTaskStatus.Completed),
                        AgentTask("task-2", "Inspect relevant source files", AgentTaskStatus.Completed),
                        AgentTask("task-3", "Propose patch to $targetFile", AgentTaskStatus.InProgress),
                    ),
                ),
            )

            val editToolId = "tc-${UUID.randomUUID().toString().take(8)}"
            val proposedDiff = if (lower.contains("test")) {
                listOf(
                    DiffLine(DiffLineType.Context, 8, 8, "def test_resolve_model_slot(model_id: str, expected: str):"),
                    DiffLine(DiffLineType.Context, 9, 9, "    assert resolve_model_slot(model_id) == expected"),
                    DiffLine(DiffLineType.Added, null, 10, ""),
                    DiffLine(DiffLineType.Added, null, 11, "def test_resolve_unknown_defaults_to_sonnet():"),
                    DiffLine(DiffLineType.Added, null, 12, "    assert resolve_model_slot(\"custom-model-v1\") == \"sonnet\""),
                )
            } else {
                listOf(
                    DiffLine(DiffLineType.Context, 5, 5, "    yield f\"event: message_start\\\\ndata: {json.dumps({'type': 'message_start'})}\\\\n\\\\n\""),
                    DiffLine(DiffLineType.Removed, 6, null, "    async for chunk in chunks:"),
                    DiffLine(DiffLineType.Added, null, 6, "    async for chunk in chunks:"),
                    DiffLine(DiffLineType.Added, null, 7, "        if not chunk or not chunk.get(\"choices\"):"),
                    DiffLine(DiffLineType.Added, null, 8, "            continue"),
                    DiffLine(DiffLineType.Context, 7, 9, "        delta = chunk.get(\"choices\", [{}])[0].get(\"delta\", {})"),
                )
            }

            val autoApproveEdit = permissionMode == PermissionMode.AutoAcceptEdits ||
                permissionMode == PermissionMode.FullAuto ||
                ToolType.EditFile in sessionAutoAllowedTools

            emit(
                BridgeStreamEvent.ToolCallProposed(
                    ToolCallBlock(
                        id = editToolId,
                        toolType = ToolType.EditFile,
                        actionLabel = "Edit File",
                        targetPathOrCommand = targetFile,
                        diffLines = proposedDiff,
                        status = if (autoApproveEdit) ToolCallStatus.Running else ToolCallStatus.PendingApproval,
                    ),
                ),
            )

            val editApproved = if (autoApproveEdit) {
                delay(400)
                true
            } else {
                val deferred = CompletableDeferred<Pair<ToolApprovalDecision, String?>>()
                pendingApprovals[editToolId] = deferred
                val (decision, feedback) = deferred.await()
                if (decision == ToolApprovalDecision.Reject) {
                    emit(
                        BridgeStreamEvent.ToolCallUpdated(
                            toolCallId = editToolId,
                            status = ToolCallStatus.Rejected,
                            stdoutOutput = "Edit skipped per user review.",
                            rejectionFeedback = feedback,
                        ),
                    )
                    false
                } else {
                    emit(
                        BridgeStreamEvent.ToolCallUpdated(
                            toolCallId = editToolId,
                            status = ToolCallStatus.Running,
                            stdoutOutput = "Applying patch…",
                        ),
                    )
                    delay(300)
                    true
                }
            }

            if (editApproved) {
                val added = proposedDiff.count { it.type == DiffLineType.Added }
                val removed = proposedDiff.count { it.type == DiffLineType.Removed }
                emit(
                    BridgeStreamEvent.ToolCallUpdated(
                        toolCallId = editToolId,
                        status = ToolCallStatus.Executed,
                        stdoutOutput = "Updated $targetFile (+$added -$removed lines). Workspace diff inspector synced.",
                    ),
                )
                emit(
                    BridgeStreamEvent.DiffUpdated(
                        FileDiffEntry(
                            path = targetFile,
                            addedCount = added,
                            removedCount = removed,
                            isStaged = false,
                            diffLines = proposedDiff,
                        ),
                    ),
                )

                // Run verification bash command
                val bashToolId = "tc-${UUID.randomUUID().toString().take(8)}"
                val autoApproveBash = permissionMode == PermissionMode.FullAuto ||
                    ToolType.RunBash in sessionAutoAllowedTools
                emit(
                    BridgeStreamEvent.ToolCallProposed(
                        ToolCallBlock(
                            id = bashToolId,
                            toolType = ToolType.RunBash,
                            actionLabel = "Run Bash Command",
                            targetPathOrCommand = "pytest -q tests/test_router.py",
                            status = if (autoApproveBash) ToolCallStatus.Running else ToolCallStatus.PendingApproval,
                        ),
                    ),
                )
                val bashApproved = if (autoApproveBash) {
                    delay(450)
                    true
                } else {
                    val deferred = CompletableDeferred<Pair<ToolApprovalDecision, String?>>()
                    pendingApprovals[bashToolId] = deferred
                    val (decision, feedback) = deferred.await()
                    if (decision == ToolApprovalDecision.Reject) {
                        emit(
                            BridgeStreamEvent.ToolCallUpdated(
                                toolCallId = bashToolId,
                                status = ToolCallStatus.Rejected,
                                stdoutOutput = "Command execution cancelled by user.",
                                rejectionFeedback = feedback,
                            ),
                        )
                        false
                    } else {
                        emit(
                            BridgeStreamEvent.ToolCallUpdated(
                                toolCallId = bashToolId,
                                status = ToolCallStatus.Running,
                                stdoutOutput = "Running pytest…",
                            ),
                        )
                        delay(420)
                        true
                    }
                }
                if (bashApproved) {
                    emit(
                        BridgeStreamEvent.ToolCallUpdated(
                            toolCallId = bashToolId,
                            status = ToolCallStatus.Executed,
                            stdoutOutput = "....                                                                     [100%]\n4 passed in 0.19s",
                        ),
                    )
                }
            }
        }

        // 4. Stream rich editorial Markdown response
        val responseText = buildDemoResponse(prompt, targetFile, permissionMode)
        val words = responseText.split(" ")
        val chunkSize = 5
        for (i in words.indices step chunkSize) {
            val slice = words.subList(i, (i + chunkSize).coerceAtMost(words.size)).joinToString(" ")
            val suffix = if (i + chunkSize < words.size) " " else ""
            emit(BridgeStreamEvent.TextDelta(slice + suffix))
            delay(45)
        }

        emit(
            BridgeStreamEvent.TaskPlanUpdated(
                listOf(
                    AgentTask("task-1", "Analyze workspace context & symbols", AgentTaskStatus.Completed),
                    AgentTask("task-2", "Inspect relevant source files", AgentTaskStatus.Completed),
                    AgentTask("task-3", if (isReadOnlyRequest) "Delivered architectural walkthrough" else "Applied edits & verified tests", AgentTaskStatus.Completed),
                ),
            ),
        )

        val totalLatency = System.currentTimeMillis() - startedAt
        emit(
            BridgeStreamEvent.Completed(
                inputTokens = 1_640 + prompt.length * 3,
                outputTokens = (responseText.length / 4).coerceAtLeast(120),
                latencyMs = totalLatency,
            ),
        )
    }

    private fun buildDemoResponse(
        prompt: String,
        targetFile: String,
        permissionMode: PermissionMode,
    ): String {
        val lower = prompt.lowercase()
        return when {
            permissionMode == PermissionMode.PlanMode -> """### Architectural Plan (Read-Only Mode)

Because **Plan Mode** is active, no files were modified. Here is the execution blueprint for `$targetFile`:

1. **Validate incoming payload** in `src/fcc_server/router.py` before dispatching to upstream providers.
2. **Guard SSE chunks** in `src/fcc_server/stream_adapter.py` against empty `choices` frames returned by OpenRouter keep-alives.
3. **Add regression coverage** in `tests/test_router.py` for fallback slots and default routing.

Switch permission mode to **Ask Before Edits** or **Auto-Accept Edits** whenever you're ready to apply these changes."""

            lower.contains("explain") || lower.contains("architecture") -> """### `free-claude-code` Architecture Overview

Your Codespace exposes two coordinated binaries inside the workspace:

- **`fcc-server` (`:8082`)**: A FastAPI proxy that accepts native Anthropic `/v1/messages` traffic, resolves the model slot (`opus`, `sonnet`, `haiku`) via `ProviderRegistry`, and translates OpenAI-compatible SSE deltas—including `reasoning_content`—into Anthropic `thinking_delta` & `text_delta` frames.
- **`fcc-claude`**: Launches Claude Code with `ANTHROPIC_BASE_URL=http://127.0.0.1:8082`, keeping tool execution, diff patches, and session history strictly inside your Codespace.

```python
# src/fcc_server/router.py
slot = resolve_model_slot(payload.model)
provider = ProviderRegistry.get_for_slot(slot)
```

> **Tip:** You can swap which upstream model backs `opus`, `sonnet`, or `haiku` at any time in the **FCC Admin** tab without restarting your session."""

            lower.contains("test") -> """I reviewed `$targetFile` and added test coverage for unknown model slot fallback behavior.

```python
# tests/test_router.py
def test_resolve_unknown_defaults_to_sonnet():
    assert resolve_model_slot("custom-model-v1") == "sonnet"
```

All test assertions pass cleanly. You can review the exact diff in the **Changes** inspector panel."""

            else -> """I analyzed `$targetFile` and hardened the streaming loop against empty keep-alive frames from upstream OpenRouter/NVIDIA endpoints.

### Summary of Changes
- Guarded `chunk.get("choices")` before indexing `[0]` in `src/fcc_server/stream_adapter.py`.
- Preserved `thinking_delta` forwarding for reasoning models (`DeepSeek R1`, `Claude Opus 4.6`).

```python
# src/fcc_server/stream_adapter.py
async for chunk in chunks:
    if not chunk or not chunk.get("choices"):
        continue
    delta = chunk["choices"][0].get("delta", {})
```

Open the **Changes** panel on the right to review unified or side-by-side diffs, stage changes, or revert at any time."""
        }
    }

    override suspend fun executeTerminalCommand(
        tabId: String,
        command: String,
        cwd: String,
        repoFiles: List<FileNode>,
    ): List<TerminalLine> {
        delay(90)
        val trimmed = command.trim()
        val idPrefix = UUID.randomUUID().toString().take(6)
        val parts = trimmed.split(Regex("\\s+"))
        val bin = parts.firstOrNull().orEmpty()

        return when {
            trimmed.isEmpty() -> emptyList()
            bin == "help" -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("Interactive Codespace Demo Shell — available commands:", AnsiColorRole.Accent))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("  ls, pwd, whoami, cat <file>, git status, git diff, pytest", AnsiColorRole.Default))),
                TerminalLine("$idPrefix-3", listOf(AnsiSegment("  fcc-server, fcc-claude, fcc-claude --continue, clear", AnsiColorRole.Green))),
            )
            bin == "pwd" -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment(cwd, AnsiColorRole.Blue))),
            )
            bin == "whoami" -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("codespace (github-codespaces • free-claude-code)", AnsiColorRole.Green))),
            )
            bin == "ls" -> listOf(
                TerminalLine(
                    "$idPrefix-1",
                    listOf(
                        AnsiSegment("src/  ", AnsiColorRole.Blue),
                        AnsiSegment("tests/  ", AnsiColorRole.Blue),
                        AnsiSegment("pyproject.toml  ", AnsiColorRole.Default, clickableFilePath = "pyproject.toml"),
                        AnsiSegment("README.md", AnsiColorRole.Default, clickableFilePath = "README.md"),
                    ),
                ),
            )
            bin == "cat" && parts.size > 1 -> {
                val target = parts[1]
                val flat = DemoDataFactory.flattenFiles(repoFiles)
                val match = flat.firstOrNull { it.path == target || it.name == target }
                if (match?.content != null) {
                    match.content.lines().take(14).mapIndexed { idx, line ->
                        TerminalLine("$idPrefix-$idx", listOf(AnsiSegment(line, AnsiColorRole.Default)))
                    }
                } else {
                    listOf(TerminalLine("$idPrefix-err", listOf(AnsiSegment("cat: $target: No such file or directory", AnsiColorRole.Red))))
                }
            }
            trimmed == "git status" -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("On branch ", AnsiColorRole.Default), AnsiSegment("main", AnsiColorRole.Accent))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("Changes not staged for commit:", AnsiColorRole.Muted))),
                TerminalLine("$idPrefix-3", listOf(AnsiSegment("  modified:   ", AnsiColorRole.Amber), AnsiSegment("src/fcc_server/router.py", AnsiColorRole.Default, clickableFilePath = "src/fcc_server/router.py"))),
                TerminalLine("$idPrefix-4", listOf(AnsiSegment("  modified:   ", AnsiColorRole.Amber), AnsiSegment("src/fcc_server/providers.py", AnsiColorRole.Default, clickableFilePath = "src/fcc_server/providers.py"))),
                TerminalLine("$idPrefix-5", listOf(AnsiSegment("  new file:   ", AnsiColorRole.Green), AnsiSegment("src/fcc_server/stream_adapter.py", AnsiColorRole.Default, clickableFilePath = "src/fcc_server/stream_adapter.py"))),
                TerminalLine("$idPrefix-6", listOf(AnsiSegment("  untracked:  ", AnsiColorRole.Blue), AnsiSegment("src/cli/bridge_agent.py", AnsiColorRole.Default, clickableFilePath = "src/cli/bridge_agent.py"))),
            )
            trimmed.startsWith("git diff") -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("diff --git a/src/fcc_server/router.py b/src/fcc_server/router.py", AnsiColorRole.Bold))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("-        raise HTTPException(status_code=503, detail=f\"Provider {provider.name} unavailable\")", AnsiColorRole.Red))),
                TerminalLine("$idPrefix-3", listOf(AnsiSegment("+        provider = ProviderRegistry.get_fallback(slot)", AnsiColorRole.Green))),
                TerminalLine("$idPrefix-4", listOf(AnsiSegment("+        if provider is None:", AnsiColorRole.Green))),
                TerminalLine("$idPrefix-5", listOf(AnsiSegment("+            raise HTTPException(status_code=503, detail=\"No healthy FCC providers configured\")", AnsiColorRole.Green))),
            )
            trimmed.startsWith("fcc-server") -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("[fcc-server] ", AnsiColorRole.Accent), AnsiSegment("Starting proxy & Admin UI on http://0.0.0.0:8082…", AnsiColorRole.Default))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("[fcc-server] ", AnsiColorRole.Accent), AnsiSegment("Providers ready: NVIDIA NIM, OpenRouter, Groq, Ollama", AnsiColorRole.Green))),
                TerminalLine("$idPrefix-3", listOf(AnsiSegment("[fcc-server] ", AnsiColorRole.Accent), AnsiSegment("Health endpoint OK • 200", AnsiColorRole.Green))),
            )
            trimmed.startsWith("fcc-claude") -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("✦ ", AnsiColorRole.Accent), AnsiSegment("Claude Code attached via fcc-server (http://127.0.0.1:8082)", AnsiColorRole.Default))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("  Session synced with Studio GUI — use visual controls for Model, Effort & Permissions.", AnsiColorRole.Muted))),
            )
            trimmed.startsWith("pytest") || trimmed.startsWith("npm test") -> listOf(
                TerminalLine("$idPrefix-1", listOf(AnsiSegment("collecting ... collected 4 items", AnsiColorRole.Muted))),
                TerminalLine("$idPrefix-2", listOf(AnsiSegment("tests/test_router.py ....                                       [100%]", AnsiColorRole.Green, clickableFilePath = "tests/test_router.py"))),
                TerminalLine("$idPrefix-3", listOf(AnsiSegment("4 passed in 0.18s", AnsiColorRole.Green))),
            )
            else -> listOf(
                TerminalLine(
                    "$idPrefix-1",
                    listOf(
                        AnsiSegment("bash: $bin: executed in demo sandbox. Type ", AnsiColorRole.Muted),
                        AnsiSegment("help", AnsiColorRole.Accent),
                        AnsiSegment(" for built-in commands.", AnsiColorRole.Muted),
                    ),
                ),
            )
        }
    }

    override fun sendSigInt(tabId: String): TerminalLine = TerminalLine(
        id = "sigint-${UUID.randomUUID().toString().take(6)}",
        segments = listOf(AnsiSegment("^C  (SIGINT sent to process)", AnsiColorRole.Amber)),
    )

    override suspend fun testConnection(config: BridgeConfig): BridgeTestResult {
        BridgeUrlValidator.validateWebSocketUrl(config.wsUrl)?.let { err ->
            return BridgeTestResult(false, null, null, err)
        }
        BridgeUrlValidator.validateHttpUrl(config.fccServerUrl)?.let { err ->
            return BridgeTestResult(false, null, null, err)
        }
        delay(320)
        return BridgeTestResult(
            success = true,
            wsLatencyMs = 28L,
            fccLatencyMs = 41L,
            diagnostics = "Demo bridge verified • WebSocket PTY ready (28 ms) • fcc-server :8082 healthy (41 ms).",
        )
    }

    override suspend fun fetchLiveFccModels(config: BridgeConfig): List<AiModelOption> = DemoDataFactory.defaultModels
}

/**
 * Live WebSocket + HTTP transport for connecting directly to the user's running
 * GitHub Codespace bridge (ws/wss) and forwarded fcc-server port (http/https).
 */
class LiveCodespaceBridgeService : CodespaceBridgeService {
    override val isDemo: Boolean = false

    private val _connectionState = MutableStateFlow(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _lastConnectionError = MutableStateFlow<String?>(null)
    override val lastConnectionError: StateFlow<String?> = _lastConnectionError.asStateFlow()

    private val _terminalOutputEvents = MutableSharedFlow<TerminalOutputEvent>(extraBufferCapacity = 128)
    override val terminalOutputEvents: SharedFlow<TerminalOutputEvent> = _terminalOutputEvents.asSharedFlow()

    private val ansiEscapeRegex = Regex("""\u001B\[[;?\d]*[ -/]*[@-~]""")

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Required for persistent WebSockets
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var activeConfig: BridgeConfig? = null

    @Volatile
    private var activeSocket: WebSocket? = null

    @Volatile
    private var isSocketOpen: Boolean = false

    @Volatile
    private var connectDeferred: CompletableDeferred<Result<Unit>>? = null

    private val streamListeners = ConcurrentHashMap<String, (String) -> Unit>()
    private val streamFailureListeners = ConcurrentHashMap<String, (String) -> Unit>()

    override fun connect(config: BridgeConfig) {
        disconnect()
        activeConfig = config
        val urlErr = BridgeUrlValidator.validateWebSocketUrl(config.wsUrl)
        if (urlErr != null) {
            _connectionState.value = ConnectionState.Disconnected
            _lastConnectionError.value = urlErr
            return
        }

        _connectionState.value = ConnectionState.Connecting
        _lastConnectionError.value = null
        isSocketOpen = false
        val deferred = CompletableDeferred<Result<Unit>>()
        connectDeferred = deferred

        val reqBuilder = Request.Builder().url(config.wsUrl.trim())
        if (config.bearerSecret.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer ${config.bearerSecret.trim()}")
        }
        val socketRef = client.newWebSocket(
            reqBuilder.build(),
            object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = true
                    _connectionState.value = ConnectionState.Connected
                    _lastConnectionError.value = null
                    deferred.complete(Result.success(Unit))
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (activeSocket !== webSocket) return
                    val handledAsPty = tryHandlePtyOutput(text)
                    if (!handledAsPty) {
                        streamListeners.values.forEach { it(text) }
                    }
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = false
                    activeSocket = null
                    _connectionState.value = ConnectionState.Disconnected
                    val msg = "Codespace bridge WebSocket closed (${reason.ifBlank { "code $code" }})."
                    _lastConnectionError.value = msg
                    if (!deferred.isCompleted) deferred.complete(Result.failure(IllegalStateException(msg)))
                    streamFailureListeners.values.forEach { it(msg) }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    if (activeSocket !== webSocket) return
                    isSocketOpen = false
                    activeSocket = null
                    _connectionState.value = ConnectionState.Disconnected
                    val codeHint = response?.code?.let { code ->
                        when (code) {
                            401, 403 -> "HTTP $code (Unauthorized — check your Bridge Bearer Secret or set port 8765 visibility to Public in GitHub Codespaces)."
                            404, 502, 503 -> "HTTP $code (Bridge server is not listening on port 8765 yet — run the bridge.js command from Settings → Bridge Setup)."
                            else -> "HTTP $code (${response.message})."
                        }
                    } ?: (t.localizedMessage ?: "Connection refused or timed out.")
                    val detail = "Unable to connect to Codespace Bridge (${config.wsUrl}): $codeHint"
                    _lastConnectionError.value = detail
                    if (!deferred.isCompleted) deferred.complete(Result.failure(IllegalStateException(detail)))
                    streamFailureListeners.values.forEach { it(detail) }
                }
            },
        )
        activeSocket = socketRef
    }

    private fun tryHandlePtyOutput(raw: String): Boolean {
        val trimmed = raw.trimStart()
        if (!trimmed.startsWith("{")) return false
        return runCatching {
            val json = JSONObject(trimmed)
            if (json.optString("type") != "pty_output") return false
            val tabId = json.optString("tabId").ifBlank { "term-bash-1" }
            val stream = json.optString("stream", "stdout")
            val rawData = json.optString("data")
            if (rawData.isEmpty()) return true

            val cleaned = ansiEscapeRegex.replace(rawData, "").replace("\r\n", "\n").replace("\r", "\n")
            val textLines = cleaned.split("\n").let { list ->
                if (list.lastOrNull()?.isEmpty() == true) list.dropLast(1) else list
            }
            val role = if (stream == "stderr") AnsiColorRole.Red else AnsiColorRole.Default
            val parsedLines = textLines.map { lineText ->
                TerminalLine(
                    id = "pty-${UUID.randomUUID().toString().take(8)}",
                    segments = listOf(AnsiSegment(lineText, role)),
                )
            }
            if (parsedLines.isNotEmpty()) {
                _terminalOutputEvents.tryEmit(TerminalOutputEvent(tabId, parsedLines))
            }
            true
        }.getOrDefault(false)
    }

    override fun disconnect() {
        isSocketOpen = false
        val previous = activeSocket
        activeSocket = null
        previous?.close(1000, "Client disconnected")
        connectDeferred?.cancel()
        connectDeferred = null
        _connectionState.value = ConnectionState.Disconnected
        streamListeners.clear()
        streamFailureListeners.clear()
    }

    override fun cancelPrompt() {
        sendJsonFrame(JSONObject().put("type", "cancel_prompt"))
    }

    private fun sendJsonFrame(payload: JSONObject): Boolean {
        val socket = activeSocket
        if (socket == null || !isSocketOpen) return false
        return socket.send(payload.toString())
    }

    private suspend fun ensureConnectedOrError(): String? {
        if (isSocketOpen && activeSocket != null) return null

        val cfg = activeConfig
            ?: return "No Codespace bridge is configured. Open Bridge Configuration to enter your wss://<codespace>-8765.app.github.dev URL."

        val existingDeferred = connectDeferred
        val waitTarget = if (_connectionState.value == ConnectionState.Connecting && existingDeferred != null) {
            existingDeferred
        } else {
            connect(cfg)
            connectDeferred
        }

        if (waitTarget == null) {
            return _lastConnectionError.value ?: "Bridge WebSocket URL is invalid."
        }

        val outcome = withTimeoutOrNull(6_000L) { waitTarget.await() }
        return when {
            outcome == null -> {
                val timeoutMsg = "Timed out connecting to ${cfg.wsUrl}. Start bridge.js from Settings → Bridge Setup and ensure Codespace port 8765 is forwarded and reachable."
                _lastConnectionError.value = timeoutMsg
                _connectionState.value = ConnectionState.Disconnected
                timeoutMsg
            }
            outcome.isFailure -> outcome.exceptionOrNull()?.message
                ?: _lastConnectionError.value
                ?: "WebSocket bridge connection failed."
            !isSocketOpen || activeSocket == null -> _lastConnectionError.value
                ?: "Codespace bridge socket is not open."
            else -> null
        }
    }

    override fun dispatchSilentCommand(command: String): String {
        sendJsonFrame(
            JSONObject()
                .put("type", "claude_cli_control")
                .put("command", command),
        )
        return command
    }

    override fun setModel(modelId: String): String = dispatchSilentCommand("/model $modelId")

    override fun setEffort(effort: EffortLevel, extendedThinking: Boolean): String {
        val flag = if (extendedThinking) " --thinking=on" else " --thinking=off"
        return dispatchSilentCommand("/effort ${effort.cliValue}$flag")
    }

    override fun setPermissionMode(mode: PermissionMode): String {
        sendJsonFrame(
            JSONObject()
                .put("type", "permission_policy")
                .put("mode", mode.cliFlag),
        )
        return "--permission-mode ${mode.cliFlag}"
    }

    override suspend fun compactContext(): String {
        dispatchSilentCommand("/compact")
        return "/compact"
    }

    override fun submitToolApproval(
        toolCallId: String,
        decision: ToolApprovalDecision,
        feedback: String?,
    ) {
        sendJsonFrame(
            JSONObject()
                .put("type", "tool_approval")
                .put("toolCallId", toolCallId)
                .put("decision", decision.name)
                .put("feedback", feedback ?: ""),
        )
    }

    override fun streamPrompt(
        prompt: String,
        attachments: List<ContextAttachment>,
        modelId: String,
        effort: EffortLevel,
        extendedThinking: Boolean,
        permissionMode: PermissionMode,
        sessionAutoAllowedTools: Set<ToolType>,
        repoFiles: List<FileNode>,
    ): Flow<BridgeStreamEvent> = callbackFlow {
        val connectError = ensureConnectedOrError()
        if (connectError != null) {
            trySend(
                BridgeStreamEvent.Error(
                    "> **Bridge Connection Failed**\n>\n> $connectError\n\nOpen **Settings → Bridge Setup** to copy and run the self-contained `bridge.js` server on port `8765` in your Codespace, then tap **Retry**.",
                ),
            )
            close()
            return@callbackFlow
        }

        val listenerId = UUID.randomUUID().toString()
        val startedAt = System.currentTimeMillis()

        streamFailureListeners[listenerId] = { errMsg ->
            trySend(
                BridgeStreamEvent.Error(
                    "> **Bridge Disconnected**\n>\n> $errMsg\n\nVerify `node bridge.js` is running on port `8765` in your Codespace and retry.",
                ),
            )
            close()
        }

        streamListeners[listenerId] = { raw ->
            runCatching {
                val json = JSONObject(raw)
                when (json.optString("type")) {
                    "pong" -> Unit
                    "thinking_delta" -> trySend(
                        BridgeStreamEvent.ThinkingDelta(
                            json.optString("delta"),
                            System.currentTimeMillis() - startedAt,
                        ),
                    )
                    "thinking_complete" -> trySend(
                        BridgeStreamEvent.ThinkingComplete(System.currentTimeMillis() - startedAt),
                    )
                    "text_delta" -> trySend(BridgeStreamEvent.TextDelta(json.optString("delta")))
                    "tool_call" -> {
                        val toolType = runCatching {
                            ToolType.valueOf(json.optString("toolType", "RunBash"))
                        }.getOrDefault(ToolType.RunBash)
                        trySend(
                            BridgeStreamEvent.ToolCallProposed(
                                ToolCallBlock(
                                    id = json.optString("id", UUID.randomUUID().toString()),
                                    toolType = toolType,
                                    actionLabel = json.optString("actionLabel", toolType.label),
                                    targetPathOrCommand = json.optString("target"),
                                    status = ToolCallStatus.PendingApproval,
                                ),
                            ),
                        )
                    }
                    "tool_result" -> trySend(
                        BridgeStreamEvent.ToolCallUpdated(
                            toolCallId = json.optString("id"),
                            status = ToolCallStatus.Executed,
                            stdoutOutput = json.optString("stdout"),
                        ),
                    )
                    "done" -> {
                        trySend(
                            BridgeStreamEvent.Completed(
                                inputTokens = json.optInt("inputTokens", 0),
                                outputTokens = json.optInt("outputTokens", 0),
                                latencyMs = System.currentTimeMillis() - startedAt,
                            ),
                        )
                        close()
                    }
                    "error" -> {
                        trySend(
                            BridgeStreamEvent.Error(
                                "> **Bridge / `fcc-claude` Error**\n>\n> ${json.optString("message", "Unknown bridge error")}",
                            ),
                        )
                        close()
                    }
                    else -> {
                        if (raw.isNotBlank() && !raw.trimStart().startsWith("{")) {
                            trySend(BridgeStreamEvent.TextDelta(raw))
                        }
                    }
                }
            }.onFailure {
                trySend(BridgeStreamEvent.TextDelta(raw))
            }
        }

        val payload = JSONObject()
            .put("type", "prompt")
            .put("prompt", prompt)
            .put("model", modelId)
            .put("effort", effort.cliValue)
            .put("extendedThinking", extendedThinking)
            .put("permissionMode", permissionMode.cliFlag)

        val sent = sendJsonFrame(payload)
        if (!sent) {
            trySend(
                BridgeStreamEvent.Error(
                    "> **Unable to Send Prompt**\n>\n> The Codespace bridge WebSocket is not open. Start `bridge.js` from **Settings → Bridge Setup** and try again.",
                ),
            )
            close()
            return@callbackFlow
        }

        awaitClose {
            streamListeners.remove(listenerId)
            streamFailureListeners.remove(listenerId)
        }
    }

    override suspend fun executeTerminalCommand(
        tabId: String,
        command: String,
        cwd: String,
        repoFiles: List<FileNode>,
    ): List<TerminalLine> {
        val connectError = ensureConnectedOrError()
        if (connectError != null) {
            return listOf(
                TerminalLine(
                    id = UUID.randomUUID().toString(),
                    segments = listOf(
                        AnsiSegment("✖ $connectError", AnsiColorRole.Red),
                    ),
                ),
                TerminalLine(
                    id = UUID.randomUUID().toString(),
                    segments = listOf(
                        AnsiSegment("Tip: Open Settings → Bridge Setup and paste the bridge.js command in your Codespace.", AnsiColorRole.Amber),
                    ),
                ),
            )
        }
        val sent = sendJsonFrame(
            JSONObject()
                .put("type", "pty_input")
                .put("tabId", tabId)
                .put("data", "$command\n"),
        )
        return if (sent) {
            emptyList()
        } else {
            listOf(
                TerminalLine(
                    id = UUID.randomUUID().toString(),
                    segments = listOf(
                        AnsiSegment("✖ Failed to send command — bridge socket closed.", AnsiColorRole.Red),
                    ),
                ),
            )
        }
    }

    override fun sendSigInt(tabId: String): TerminalLine {
        val sent = sendJsonFrame(
            JSONObject()
                .put("type", "pty_signal")
                .put("tabId", tabId)
                .put("signal", "SIGINT"),
        )
        return TerminalLine(
            id = UUID.randomUUID().toString(),
            segments = listOf(
                AnsiSegment(
                    if (sent) "^C (SIGINT sent to Codespace)" else "^C (Bridge disconnected)",
                    if (sent) AnsiColorRole.Amber else AnsiColorRole.Red,
                ),
            ),
        )
    }

    override suspend fun testConnection(config: BridgeConfig): BridgeTestResult = withContext(Dispatchers.IO) {
        BridgeUrlValidator.validateWebSocketUrl(config.wsUrl)?.let { err ->
            return@withContext BridgeTestResult(false, null, null, err)
        }
        BridgeUrlValidator.validateHttpUrl(config.fccServerUrl)?.let { err ->
            return@withContext BridgeTestResult(false, null, null, err)
        }

        // Measure fcc-server HTTP latency
        var fccLatency: Long? = null
        var fccMessage: String
        val fccStart = System.currentTimeMillis()
        try {
            val baseUrl = config.fccServerUrl.trim().trimEnd('/')
            val reqBuilder = Request.Builder().url("$baseUrl/v1/models").get()
            if (config.bearerSecret.isNotBlank()) {
                reqBuilder.header("Authorization", "Bearer ${config.bearerSecret.trim()}")
            }
            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                fccLatency = System.currentTimeMillis() - fccStart
                fccMessage = "fcc-server HTTP ${resp.code} (${fccLatency} ms)"
            }
        } catch (e: Exception) {
            fccMessage = "fcc-server unreachable: ${e.localizedMessage ?: "network error"}"
        }

        // Measure WebSocket handshake latency
        var wsLatency: Long? = null
        var wsMessage: String
        val wsStart = System.currentTimeMillis()
        val wsResult = CompletableDeferred<Pair<Boolean, String>>()
        try {
            val wsReq = Request.Builder().url(config.wsUrl.trim()).apply {
                if (config.bearerSecret.isNotBlank()) {
                    header("Authorization", "Bearer ${config.bearerSecret.trim()}")
                }
            }.build()
            val probe = httpClient.newWebSocket(
                wsReq,
                object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        wsLatency = System.currentTimeMillis() - wsStart
                        webSocket.close(1000, "Probe complete")
                        wsResult.complete(true to "Bridge WS connected (${wsLatency} ms)")
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        wsResult.complete(false to "Bridge WS failed: ${response?.code ?: t.localizedMessage ?: "unreachable"}")
                    }
                },
            )
            val (ok, msg) = wsResult.await()
            probe.cancel()
            wsMessage = msg
            BridgeTestResult(
                success = ok || fccLatency != null,
                wsLatencyMs = wsLatency,
                fccLatencyMs = fccLatency,
                diagnostics = "$wsMessage • $fccMessage",
            )
        } catch (e: Exception) {
            wsMessage = "Bridge WS error: ${e.localizedMessage ?: "invalid"}"
            BridgeTestResult(false, null, fccLatency, "$wsMessage • $fccMessage")
        }
    }

    override suspend fun fetchLiveFccModels(config: BridgeConfig): List<AiModelOption> = withContext(Dispatchers.IO) {
        if (BridgeUrlValidator.validateHttpUrl(config.fccServerUrl) != null) {
            return@withContext DemoDataFactory.defaultModels
        }
        runCatching {
            val baseUrl = config.fccServerUrl.trim().trimEnd('/')
            val req = Request.Builder().url("$baseUrl/v1/models").apply {
                if (config.bearerSecret.isNotBlank()) {
                    header("Authorization", "Bearer ${config.bearerSecret.trim()}")
                }
            }.build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching DemoDataFactory.defaultModels
                val body = resp.body?.string().orEmpty()
                val arr = JSONObject(body).optJSONArray("data") ?: return@runCatching DemoDataFactory.defaultModels
                val fetched = mutableListOf<AiModelOption>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val isClaude = id.contains("claude", ignoreCase = true)
                    fetched += AiModelOption(
                        id = id,
                        displayName = id.substringAfterLast("/"),
                        provider = if (isClaude) "Anthropic" else obj.optString("owned_by", "fcc-server"),
                        group = if (isClaude) ModelProviderGroup.Claude else ModelProviderGroup.FccCustom,
                        tags = if (isClaude) listOf("Claude") else listOf("Live via FCC"),
                        contextWindowK = obj.optInt("context_length", 128_000) / 1000,
                    )
                }
                if (fetched.isEmpty()) DemoDataFactory.defaultModels else fetched
            }
        }.getOrDefault(DemoDataFactory.defaultModels)
    }
}
